load dataHW2_1;
K = 2;
M = [mean(X1);mean(X2)];
S(:, :, 1) = cov(X1);
S(:, :, 2) = cov(X2);

smean = (cov(X1)+cov(X2))/2;
Dtrain = [X1;X2];
Etrain = zeros(2, 1);
N = size(X1, 1);

for k=1:K
  X=Dtrain((k-1)*100+1:k*100,:);
  for i=1:N
    for j=1:K
      d1(j,1)=(X(i,:)-M(j,:))*(X(i,:)-M(j,:))';
      d2(j,1)=(X(i,:)-M(j,:))*inv(smean)*(X(i,:)-M(j,:))';
    end
    [min1v, min1i]=min(d1);
    if (min1i~=k) Etrain(1,1) = Etrain(1,1)+1; end
    [min2v, min2i]=min(d2);
    if (min2i~=k) Etrain(2,1) = Etrain(2,1)+1; end
  end;
end;
Error_rate = Etrain/N;