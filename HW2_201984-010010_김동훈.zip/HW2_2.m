T = cell2mat(iris_data)
T2 = [str2double(iris(:,1:3)), str2double(iris(:,4:6)), str2double(iris(:,7:9)), str2double(iris(:,10:12))];
X1=T2(1:50,:);
X2=T2(51:100,:);
X3=T2(101:150,:);
X=[X1;X2;X3]
[x,y]=meshgrid([-2.5:0.1:5.5], [-2.5:0.1:5.5]);
XY=[x(:), y(:)];
figure(1);
hold on;
plot(X1(:,1), X1(:,2), '*');
plot(X2(:,1), X2(:,2), 'ro');
plot(X3(:,1), X3(:,2), 'kd');
for i=1:size(XY, 1)
  xt=XY(i,:);
  for j=1:size(X,1)
    d(j,1)=norm(xt-X(j,:));
  end
  [sx,si]=sort(d);
  K=1; c=zeros(3,1);
  for j=1:K
    if (si(j)<=100) c(1)=c(1)+1; end
    if (si(j)>200) c(3)=c(3)+1; end
    if ((si(j)>100) & (si(j)<=200)) c(2)=c(2)+1; end
  end
  [maxv, maxi]=max(c);
  rxy1(i,1)=maxi;
end
rxy1=reshape(rxy1, size(x));
contour(x, y, rxy1);
axis([-2.5 5.5 -2.5 5.5]);
grid on;