N = 100;
m1 = repmat([0,0],N,1);
m2 = repmat([5,3],N,1);

s1 = [4, 0;0, 4];
s2 = [3, 0;0, 5];

X1 = randn(N, 2)*sqrtm(s1)+m1;
X2 = randn(N, 2)*sqrtm(s2)+m2;

plot(X1(:,1), X1(:,2), 'o', 'color', 'red');
hold on;
plot(X2(:,1), X2(:,2), 's', 'color', 'blue');
legend('C1', 'C2')
save dataHW2_1 X1 X2;