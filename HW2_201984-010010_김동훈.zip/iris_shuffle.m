# Created by Octave 5.2.0, Wed Mar 25 17:58:32 2020 GMT <unknown@DESKTOP-9BHNLAP>
# name: iris_data
# type: cell
# rows: 150
# columns: 4
# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
7.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7



# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.1



# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
6.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
3.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
4.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
5.6



# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.7


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.9


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.4


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.0


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.1


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.5


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.6


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.8


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
1.3


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
0.2


# name: <cell-element>
# type: sq_string
# elements: 1
# length: 3
2.4





# name: iris_class
# type: cell
# rows: 150
# columns: 1
# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
3


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
2


# name: <cell-element>
# type: scalar
1


# name: <cell-element>
# type: scalar
3





