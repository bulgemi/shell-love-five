$a.page(function(){
	this.init = function(){
		//header navmenu
		var nav = $('.nav > li');
		var subnav = $('.apxtyped-submenu__wrap');
		$(nav).find(subnav).parent().addClass('expanded');

		//popup
		$('#pop-temp1').click( function() {
		    $a.popup({
		        url: "05-popup.html",
		        iframe: false,  // default 는 true
		        width: 700,
		        height: 400,
		        title : "일일 점검 수행 결과 상세"
		    });
		});
		$('#pop-temp2').click( function() {
		    $a.popup({
		        url: "05-popup.html",
		        iframe: false,  // default 는 true
		        width: 700,
		        height: 400,
		        title : "일일 점검 결과 이력조회 상세"
		    });
		});
		$('#pop-temp3').click( function() {
		    $a.popup({
		        url: "15-actionpopup.html",
		        iframe: false,  // default 는 true
		        width: 700,
		        height: 600,
		        title : "Action 수행[미들웨어 재기동]결과 보기",
		    });
		});
		//accordion
		$('.act-accord').expand(0);
		//tabs grid
		$('.Accordion >li').on('click', function(e, index){
    		$($(e.currentTarget).find('div:visible').find('.alopexgrid')).alopexGrid( "viewUpdate" ); 
    	 });

		var leftMenuMinWidth = 40;
		var leftMenuHideWidth = 120;
		var leftMenuInitWidth = 340;

		var $leftMenuSplitter = $("#left-menu__split");
		var $leftMenuBtn = $('#left-menu__btn');
		var $leftMenuContent = $(".left-contents");

		$(".left-footer").css("width", $('#frame1').css('width'));

		$("#left-menu__split").setOptions({
			onDrag : function(event){
				var frameWidth = parseInt($('#frame1').css('width'));
				if( frameWidth <= leftMenuHideWidth && $leftMenuBtn.hasClass("left-footer__close")){
					$leftMenuContent.hide();
					$leftMenuBtn.removeClass("left-footer__close").addClass("left-footer__open");
				} else if( frameWidth > leftMenuHideWidth && $leftMenuBtn.hasClass("left-footer__open")){
					$leftMenuContent.show();
					$leftMenuBtn.removeClass("left-footer__open").addClass("left-footer__close");
				}
				$(".left-footer").css("width", frameWidth + 'px');
			}
		});

		$("#left-menu__btn").on("click", function(){

			if($leftMenuBtn.hasClass("left-footer__close")){
				$leftMenuContent.hide();
				$leftMenuBtn.removeClass("left-footer__close").addClass("left-footer__open");
				$leftMenuSplitter.setOptions({position : leftMenuMinWidth});
			}else {
				$leftMenuContent.show();
				$leftMenuBtn.removeClass("left-footer__open").addClass("left-footer__close");
				$leftMenuSplitter.setOptions({position : leftMenuInitWidth});
			}
			$(".left-footer").css("width", $('#frame1').css('width'));
		});
	}
});
