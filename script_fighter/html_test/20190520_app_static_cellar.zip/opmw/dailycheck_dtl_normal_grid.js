function result_dtl_normal_gridInit(taskRunListDtl, params){
    $('#dailycheck_dtl_normal').alopexGrid({
        autoColumnIndex: true,
//        cellInlineEdit:true,
        filteringHeader: true,
        useClassHovering: true,
        numberingColumnFromZero: false,
//        cellSelectable: true,
        fitTableWidth: true,
//        rowSelectOption: {
//            clickSelect: true,
//            singleSelect: true
//        },
        rowOption: {
            defaultHeight: 'content'
        },
        message: {
            nodata: '일일점검 결과 상세 항목이 존재하지 않습니다',
        },
        defaultColumnMapping : {
            resizing: true
        },
        columnMapping : [
            {
                align : 'center',
                width : '45px',
                numberingColumn : true
            }, {
                key: 'Title',
                title: 'Title',
                width : '200px',
            }, {
                align : 'center',
                key: 'Result',
                title: 'Result',
                width : '50px',
                render : function (value, data, render, mapping, grid) {
                        if (value == "OK") {
                            return '<div class="Icon ok" align="center"></div>';
                        } else if (value == "CHECK"){
                            return '<div class="Icon check" align="center"></div>';
                        }
                    },
            }, {
                key: 'Value',
                title: 'Value',
                width : '500px',
                height: 'content',
                styleclass: function(value){
//						if(value.indexOf('\n')> -1)
						return 'wraptext';
					},
				render : function (value, data, render, mapping, grid) {
                        return value;
                    }
            }
        ],
        data: taskRunListDtl
    });
};

