function result_dtl_gridInit(taskRunListDtl, params){
    $('#dailycheck_history_dtl').alopexGrid({
        autoColumnIndex: true,
        height: 'content',
        cellInlineEdit:true,
        filteringHeader: true,
        numberingColumnFromZero: false,
//        cellSelectable: true,
        fitTableWidth: true,
        rowSelectOption: {
            clickSelect: true,
            singleSelect: true
        },
//        rowOption: { defaultHeight: 'content'},
        defaultSorting:{
            sortingColumn: 1,
            sortingDirection: 'asc'
        },
        message: {
            nodata: '일일점검 결과 상세 항목이 존재하지 않습니다',
        },
        defaultColumnMapping : {
            resizing: true
        },
        columnMapping : [
            {
                align : 'center',
                width : '45px',
                numberingColumn : true
            }
        ],
        data: taskRunListDtl
    });

    var sucess_list = ["Title", "Result", "Value"];
    var sucess_width= ["200px", "100px", "500px"];
    var fail_list = ["Error"];
    var fail_width = ["700px"];
    if(taskRunListDtl != "") {
        if(!taskRunListDtl[0]['Error']){
            for(var idx=0; idx < sucess_list.length; idx++) {
                var col = $('#dailycheck_history_dtl').alopexGrid('readOption').columnMapping;
                var add = { key: sucess_list[idx],
                            title: sucess_list[idx],
                            width :sucess_width[idx],
                            styleclass: function(value){
                                if(value.indexOf('\n')> -1)
                                return 'wraptext'
                            },
                            render : function (value, data, render, mapping, grid) {
                                    if (value == "OK") {
                                        return '<div class="Icon ok" align="center"></div>';
                                    } else if (value == "CHECK"){
                                        return '<div class="Icon check" align="center"></div>';
                                    } else {
                                        return value;
                                    }
                                }
                            };
                $('#dailycheck_history_dtl').alopexGrid('updateOption', {columnMapping: col.concat(add)});
                $('#dailycheck_history_dtl').alopexGrid('updateOption', {
                    rowOption: { defaultHeight: 'content'}
                });
            }
        }
        else {
            for(var idx=0; idx < fail_list.length; idx++) {
                var col = $('#dailycheck_history_dtl').alopexGrid('readOption').columnMapping;
                var add = {key: fail_list[idx], title: fail_list[idx], width: fail_width[idx]};
                $('#dailycheck_history_dtl').alopexGrid('updateOption', {columnMapping: col.concat(add)});
                $('#dailycheck_history_dtl').alopexGrid('updateOption', {
                    rowOption: { defaultHeight: 'content'}
                });
            }
        }
    }

};

