// dailycheck_result.js

// 2019.04.05 KKH modified.
// 조회버튼 선처리
function f_preSearchRunList() {
    document.getElementById("search_i_node_id").value       = $('#i_node_id').val();
    document.getElementById("search_i_task_id").value       = $('#i_task_id').val();
    document.getElementById("search_i_runner_id").value     = $('#i_runner_id').val();
    document.getElementById("search_i_fromStart_dt").value  = $('#i_fromStart_dt').val();
    document.getElementById("search_i_toStart_dt").value    = $('#i_toStart_dt').val();
    document.getElementById("search_i_result").value        = $('#i_result').val();
    document.getElementById("search_i_okyn").value          = $('#i_okyn').val();
    return true;
};

function f_searchRunList() {
//    f_preSearchRunList()

    var form = document.createElement('form');
    form.setAttribute('method', 'post');
    form.setAttribute('action', '/opmw/dailycheck')

    var node, task, fromStart_dt, toStart_dt, runner_id, result, run_result;

    node = document.createElement('input');
    node.setAttribute('type', 'hidden');
    node.setAttribute('name', 'search_i_node_id');
    node.setAttribute('value', $('#i_node_id').val());
    form.appendChild(node);

    task = document.createElement('input');
    task.setAttribute('type', 'hidden');
    task.setAttribute('name', 'search_i_task_id');
    task.setAttribute('value', $('#i_task_id').val());
    form.appendChild(task);

    fromStart_dt = document.createElement('input');
    fromStart_dt.setAttribute('type', 'hidden');
    fromStart_dt.setAttribute('name', 'search_i_fromStart_dt');
    fromStart_dt.setAttribute('value', $('#i_fromStart_dt').val());
    form.appendChild(fromStart_dt);

    toStart_dt = document.createElement('input');
    toStart_dt.setAttribute('type', 'hidden');
    toStart_dt.setAttribute('name', 'search_i_toStart_dt');
    toStart_dt.setAttribute('value', $('#i_toStart_dt').val());
    form.appendChild(toStart_dt);

    runner_id = document.createElement('input');
    runner_id.setAttribute('type', 'hidden');
    runner_id.setAttribute('name', 'search_i_runner_id');
    runner_id.setAttribute('value', $('#i_runner_id').val());
    form.appendChild(runner_id);

    result = document.createElement('input');
    result.setAttribute('type', 'hidden');
    result.setAttribute('name', 'search_i_result');
    result.setAttribute('value', $('#i_result').val());
    form.appendChild(result);

    run_result = document.createElement('input');
    run_result.setAttribute('type', 'hidden');
    run_result.setAttribute('name', 'search_i_okyn');
    run_result.setAttribute('value', $('#i_okyn').val());
    form.appendChild(run_result);


    document.body.appendChild(form);
    form.submit();
};

function f_reRunDo() {
    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", "/opmw/dashboard/do");

//    var chk_rows = document.getElementsByName("runlist_chk_row");
    var rerun_check_list = $('#dailycheck_result').alopexGrid('dataGet', {_state: {selected:true}});

    if (rerun_check_list.length == 0) {
        alert("재수행할 행을 체크해주세요.");
        return false;
    }
    else if (rerun_check_list.length > 0) {
        if (confirm("재수행 하시겠습니까?") == false) {
            return false;
        }

        $.map(rerun_check_list, function(d,idx){
            var instance_no = document.createElement("input");
            instance_no.setAttribute("type", "hidden");
            instance_no.setAttribute("name", "instance_no");
            instance_no.setAttribute("value", d.INSTANCE_NO);
            form.appendChild(instance_no);
            var node_id = document.createElement("input");
            node_id.setAttribute("type", "hidden");
            node_id.setAttribute("name", "node_id");
            node_id.setAttribute("value", d.NODE_ID);
            form.appendChild(node_id);
            var task_id = document.createElement("input");
            task_id.setAttribute("type", "hidden");
            task_id.setAttribute("name", "task_id");
            task_id.setAttribute("value", d.TASK_ID);
            form.appendChild(task_id);
        });
     }
    // 2018.12.11 KYM added
    var action_name = document.createElement("input");
    action_name.setAttribute("type", "hidden");
    action_name.setAttribute("name", "action");
    action_name.setAttribute("value", "rerun");
    form.appendChild(action_name);

    document.body.appendChild(form);
    form.submit();

    return;
};

function f_reRun() {
    f_reRunDo()
    setTimeout(f_refreshRunList(), 2000);
};

// 2018.12.11 KYM add.
function f_exportExcel() {

    var form = document.createElement("form");
    form.setAttribute("method", "post");
    form.setAttribute("action", "/opmw/dashboard/do");

    var search_i_mode         = "";
    var search_node_id        = $('#i_node_id').val();
    var search_task_id        = $('#i_task_id').val();
//    var search_i_runner_id      = $('#i_runner_id').val();
    var search_fromStart_dt   = $('#i_fromStart_dt').val();
    var search_toStart_dt     = $('#i_toStart_dt').val();
    var search_result         = $('#i_result').val();
    var search_okyn           = $('#i_okyn').val();

    var action_name = document.createElement("input");
    action_name.setAttribute("type", "hidden");
    action_name.setAttribute("name", "action");
    action_name.setAttribute("value", "exportexcel");
    form.appendChild(action_name);

    var node_id = document.createElement("input");
    node_id.setAttribute("type", "hidden");
    node_id.setAttribute("name", "search_i_node_id");
    node_id.setAttribute("value", search_node_id);
    form.appendChild(node_id);

    var task_id = document.createElement("input");
    task_id.setAttribute("type", "hidden");
    task_id.setAttribute("name", "search_i_task_id");
    task_id.setAttribute("value", search_task_id);
    form.appendChild(task_id);

    var fromStart_dt = document.createElement("input");
    fromStart_dt.setAttribute("type", "hidden");
    fromStart_dt.setAttribute("name", "search_i_fromStart_dt");
    fromStart_dt.setAttribute("value", search_fromStart_dt);
    form.appendChild(fromStart_dt);

    var toStart_dt = document.createElement("input");
    toStart_dt.setAttribute("type", "hidden");
    toStart_dt.setAttribute("name", "search_i_toStart_dt");
    toStart_dt.setAttribute("value", search_toStart_dt);
    form.appendChild(toStart_dt);

    var result = document.createElement("input");
    result.setAttribute("type", "hidden");
    result.setAttribute("name", "search_i_result");
    result.setAttribute("value", search_result);
    form.appendChild(result);

    var okyn = document.createElement("input");
    okyn.setAttribute("type", "hidden");
    okyn.setAttribute("name", "search_i_okyn");
    okyn.setAttribute("value", search_okyn);
    form.appendChild(okyn);

    document.body.appendChild(form);
    form.submit();

    return;
};

function f_newviewRunList() {
    $.getJSON('/opmw/dailycheck_new', {
        search_i_mode : "",
        search_i_node_id : $('#i_node_id').val(),
        search_i_task_id : $('#i_task_id').val(),
        search_i_runner_id : $('#i_runner_id').val(),
        search_i_fromStart_dt :$('#i_fromStart_dt').val(),
        search_i_toStart_dt : $('#i_toStart_dt').val(),
//        search_i_status : search_i_status,
        search_i_result : $('#i_result').val(),
        search_i_okyn : $('#i_okyn').val()
    }, function(ntaskRunList) {

        // filter 정보 유지
        if(filterInfo != null){
            $("#dailycheck_result").alopexGrid('filterSet', filterInfo );
        }

        // Grid 새로 그리기
        $('#dailycheck_result').alopexGrid('dataSet', ntaskRunList);

        // check box 정보 유지
        $.map(chk_list, function(d,idx){
            for( idx=0; idx < ntaskRunList.length; idx++) {
                var data = $('#dailycheck_result').alopexGrid("dataGetByIndex", {row:idx});
                if( data['TASK_RESULT_NO'] == d.TASK_RESULT_NO ) {
                    $('#dailycheck_result').alopexGrid('rowSelect', {_index: {row: idx}},{_state : {selected:false}}, true);
                }
            }
        });

        // page 정보 유지
        if (curr_page > 0){
             $('#dailycheck_result').alopexGrid('pageSet', curr_page);
        }

        // sorting 정보 유지
        if(sortingInfo != null){
            $("#dailycheck_result").alopexGrid('dataSort', sortingInfo );
        }
        else {
            $("#dailycheck_result").alopexGrid('dataSort', [ {sortingColumn : 'START_DT', sortingDirection: 'desc'}]);
        }

    });
    return;
};

function f_refreshRunList() {
    chk_list = $('#dailycheck_result').alopexGrid('dataGet', {_state: {selected:true}});
    // page 정보 저장
    curr_page = $('#dailycheck_result').alopexGrid('pageInfo')['current'];
    // sorting 정보 저장
    sortingInfo = $('#dailycheck_result').alopexGrid('sortingInfo');

    // filter 유지
    filterInfo = $('#dailycheck_result').alopexGrid('filterInfo').filterColumnMappingList;

    f_newviewRunList();
    return;
};

// onload 이벤트 처리
function onloadComplete() {
    var interval = 10; // 3600초 = 1시간,  20초에 한번씩 refresh
    var timeleft = interval;
    // 수행 날짜로 정렬
    $("#dailycheck_result").alopexGrid('dataSort', [ {sortingColumn : 'START_DT', sortingDirection: 'desc'}]);
    var refreshTimer = setInterval(function() {
        timeleft--;
        if (timeleft <= 0) {
            f_refreshRunList()
            // Reset
            timeleft = interval;
        }
    }, 1000 );
    return;
};