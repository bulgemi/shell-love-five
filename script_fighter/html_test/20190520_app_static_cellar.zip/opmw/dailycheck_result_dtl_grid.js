function result_dtl_gridInit(taskRunListDtl, params){
    $('#dailycheck_result_dtl').alopexGrid({
        height: 'content',
		cellInlineEdit:true,
        autoColumnIndex: true,
        filteringHeader: true,
        useClassHovering: true,
        numberingColumnFromZero: false,
        cellSelectable: true,
        fitTableWidth: true,
        rowSelectOption: {
            clickSelect: true,
            singleSelect: true
        },
        defaultSorting:{
            sortingColumn: 1,
            sortingDirection: 'asc'
        },
        defaultColumnMapping : {
            resizing: true
        },
        message: {
            nodata: '일일점검 결과 상세 항목이 존재하지 않습니다',
            filterNodata: 'No data',
            noFilteredData: '일일점검 결과 상세 항목이 존재하지 않습니다'
        },

        columnMapping : [
            {
                align : 'center',
                width : '45px',
                numberingColumn : true
            }
        ],
        data: taskRunListDtl
    });

    var sucess_list = ["Title", "Result", "Value"];
    var sucess_width= ["200px", "100px", "500px"];
    var fail_list = ["Error"];
    var fail_width = ["700px"];
//    alert("taskRunListDtl[0] : " + taskRunListDtl[0]['Error'] );
    if(taskRunListDtl != "") {
        if(!taskRunListDtl[0]['Error'] ){
             for(var idx=0; idx < sucess_list.length; idx++) {
                var col = $('#dailycheck_result_dtl').alopexGrid('readOption').columnMapping;
                var add = { key: sucess_list[idx],
                            title: sucess_list[idx],
                            width :sucess_width[idx],
                            styleclass: function(value){
//                                if(value.indexOf('\n')> -1)
                                return 'wraptext';
                            },
                            render : function (value, data, render, mapping, grid) {
                                    if (value == "OK") {
                                        return '<div class="Icon ok" align="center"></div>';
                                    } else if (value == "CHECK"){
                                        return '<div class="Icon check" align="center"></div>';
                                    } else {
                                        return value;
//                                        var strvalue = '<pre>'+ value + '</pre>';
//                                        return strvalue;
//                                        return value.replace(/\n/g, '<br>');

                                    }
                                }
                            };
                $('#dailycheck_result_dtl').alopexGrid('updateOption', {columnMapping: col.concat(add)});
                $('#dailycheck_result_dtl').alopexGrid('updateOption', {
                    rowOption: { defaultHeight: 'content'}
                });
            }
        }
        else {
            for(var idx=0; idx < fail_list.length; idx++) {
                var col = $('#dailycheck_result_dtl').alopexGrid('readOption').columnMapping;
                var add = {key: fail_list[idx], title: fail_list[idx], width: fail_width[idx]};
                $('#dailycheck_result_dtl').alopexGrid('updateOption', {columnMapping: col.concat(add)});
                $('#dailycheck_history_dtl').alopexGrid('updateOption', {
                    rowOption: { defaultHeight: 'content'}
                });
            }
        }
    }
};
