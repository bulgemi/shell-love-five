// dashboard_chart_dailycheck.js

//var linux_chart_dashboard = null;
var mw_chart_dashboard = null;
var db_chart_dashboard = null;
var windows_chart_dashboard = null;
var text_ctx = null;
var task_id_linux = null;
var task_id_mw = null;
var task_id_db = null;
var task_id_windows = null;

AlopexDash.define("pie", AlopexDash.chart({
    properties : {
        valueField : "value",
        titleField : "title",
        colorFiled : "color"
    },
    model : {
        dataList : { type : ["object"], default:[]}
    },
    lifecycle : {
        created : function(data){
            let props = this.getProperty();
            let chartOpt = this.chartOpt = {
                type: "pie",
                titleField : props.titleField,
                valueField : props.valueField,
                colorField : props.colorField,
                fontSize : 15,
                dataProvider : data.dataList,
                labelRadius : -40,
                pullOutRadius : 0,
                labelText: "[[title]] : [[value]]",  // % 대신 건수가 출력됨
                //innerRadius : '40%',  // 도넛 모양이 됨
                listeners : [{
                    "event": "clickSlice",
                    "method": myCustomClick
                }]
            };
        },
        updated : function(data){
            this.chart.dataProvider = data.dataList;
        }
    },
    events : {
        "resize" : function(){
        },
    }
}))


document.addEventListener("DOMContentLoaded", function (event) {

    let dash = AlopexDash.create({
        tagId: 'dashboard',
        showTime : false,
        columnLimit: 4,
        widgetSize : ['auto', 300],
        widgets : {
            linux_chart : {
                type: "pie",
                title: 'DailyCheck - Linux',
//                width: 2,
//                height : 2,
                properties : {
                    valueField: "count",
                    titleField: "status",
                    colorField: "color"
                },
                data: {
                    dataList: []
                }
            },
            windows_chart : {
                type: "pie",
                title: 'DailyCheck - Windows',
//                width: 2,
//                height : 2,
                properties : {
                    valueField: "count",
                    titleField: "status",
                    colorField: "color"
                },
                data: {
                    dataList: []
                }
            },
            mw_chart : {
                type: "pie",
                title: 'DailyCheck - MW',
//                width: 2,
//                height : 2,
                properties : {
                    valueField: "count",
                    titleField: "status",
                    colorField: "color"
                },
                data: {
                    dataList: []
                }
            },
            db_chart : {
                type: "pie",
                title: 'DailyCheck - DB',
//                width: 2,
//                height : 2,
                properties : {
                    valueField: "count",
                    titleField: "status",
                    colorField: "color"
                },
                data: {
                    dataList: []
                }
            },
            w04_chart : {
                type: "pie",
                title: 't06_test',
//                width: 2,
//                height : 2,
                properties : {
                    valueField: "count",
                    titleField: "status",
                    colorField: "color"
                },
                data: {
                    dataList: []
                }
            },
            w05_chart : {
                type: "pie",
                title: '보안점검',
//                width: 2,
//                height : 2,
                properties : {
                    valueField: "count",
                    titleField: "status",
                    colorField: "color"
                },
                data: {
                    dataList: []
                }
            },
            agent_status : {
                type: "pie",
                title: 'Agent 상태점검',
                properties : {
                    valueField: "count",
                    titleField: "status",
                    colorField: "color"
                },
                data: {
                dataList: [
//                        { status: "정상", count: 7, color: "#0099ff" },
//                        { status: "비활성화", count: 2 , color: "#ffff4d"},
//                        { status: "오류", count: 1, color: "#ff3333" }
                    ]
                }
            }
        }
    });

    var widget_linux = dash.getWidget("linux_chart");
    var widget_windows = dash.getWidget("windows_chart");
    var widget_mw = dash.getWidget("mw_chart");
    var widget_db = dash.getWidget("db_chart");
    var widget_agent = dash.getWidget("agent_status");

    // widget 추가 2019.05.08
    var widget_w04 = dash.getWidget("w04_chart");
    var widget_w05 = dash.getWidget("w05_chart");

    var req = AlopexDash.request({
        //url : 'http://127.0.0.1:5600/opmw/dashboard/count_dailycheck', // 통신 url
        url : './dashboard/count_dailycheck', // 통신 url
        method : 'GET', // 통신 method
        period: 5000 // [option.period=false] 통신을 주기적으로 수행하고자 할 경우, 주기(단위:초) 값을 넣는다
    }, function(){
        var newData = JSON.parse(this.responseText);

        var task_id_linux = newData.task_id_linux;
        var task_id_windows = newData.task_id_windows;
        var task_id_mw = newData.task_id_mw;
        var task_id_db = newData.task_id_db;

        // widget 추가 2019.05.08
        var task_id_w04 = newData.task_id_w04;
        var task_id_w05 = newData.task_id_w05;

        var data = new Array();

        sub = new Object();
        sub['status'] = '정상';
        sub['count'] = newData.linux[0];
        sub['color'] = '#0099ff';
        sub['id'] = task_id_linux;
        data[0] = sub;

        sub = new Object();
        sub['status'] = '체크';
        sub['count'] = newData.linux[1];
        sub['color'] = '#f9a836';
        sub['id'] = task_id_linux;
        data[1] = sub;

        sub = new Object();
        sub['status'] = '미수행';
        sub['count'] = newData.linux[2];
        sub['color'] = '#a658ef';
        sub['id'] = task_id_linux;
        data[2] = sub;

        sub = new Object();
        sub['status'] = '실패';
        sub['count'] = newData.linux[3];
        sub['color'] = '#ff3333';
        sub['id'] = task_id_linux;
        data[3] = sub;

        widget_linux.setData({dataList: data});

        var data = new Array();

        sub = new Object();
        sub['status'] = '정상';
        sub['count'] = newData.windows[0];
        sub['color'] = '#0099ff';
        sub['id'] = task_id_windows;
        data[0] = sub;

        sub = new Object();
        sub['status'] = '체크';
        sub['count'] = newData.windows[1];
        sub['color'] = '#f9a836';
        sub['id'] = task_id_windows;
        data[1] = sub;

        sub = new Object();
        sub['status'] = '미수행';
        sub['count'] = newData.windows[2];
        sub['color'] = '#a658ef';
        sub['id'] = task_id_windows;
        data[2] = sub;

        sub = new Object();
        sub['status'] = '실패';
        sub['count'] = newData.windows[3];
        sub['color'] = '#ff3333';
        sub['id'] = task_id_windows;
        data[3] = sub;

        widget_windows.setData({dataList: data});

        var data = new Array();

        sub = new Object();
        sub['status'] = '정상';
        sub['count'] = newData.mw[0];
        sub['color'] = '#0099ff';
        sub['id'] = task_id_mw;
        data[0] = sub;

        sub = new Object();
        sub['status'] = '체크';
        sub['count'] = newData.mw[1];
        sub['color'] = '#f9a836';
        sub['id'] = task_id_mw;
        data[1] = sub;

        sub = new Object();
        sub['status'] = '미수행';
        sub['count'] = newData.mw[2];
        sub['color'] = '#a658ef';
        sub['id'] = task_id_mw;
        data[2] = sub;

        sub = new Object();
        sub['status'] = '실패';
        sub['count'] = newData.mw[3];
        sub['color'] = '#ff3333';
        sub['id'] = task_id_mw;
        data[3] = sub;

        widget_mw.setData({dataList: data});

        var data = new Array();

        sub = new Object();
        sub['status'] = '정상';
        sub['count'] = newData.db[0];
        sub['color'] = '#0099ff';
        sub['id'] = task_id_db;
        data[0] = sub;

        sub = new Object();
        sub['status'] = '체크';
        sub['count'] = newData.db[1];
        sub['color'] = '#f9a836';
        sub['id'] = task_id_db;
        data[1] = sub;

        sub = new Object();
        sub['status'] = '미수행';
        sub['count'] = newData.db[2];
        sub['color'] = '#a658ef';
        sub['id'] = task_id_db;
        data[2] = sub;

        sub = new Object();
        sub['status'] = '실패';
        sub['count'] = newData.db[3];
        sub['color'] = '#ff3333';
        sub['id'] = task_id_db;
        data[3] = sub;

        widget_db.setData({dataList: data});

        var data = new Array();

        sub = new Object();
        sub['status'] = '정상';
        sub['count'] = newData.normal_cnt;
        sub['color'] = '#0099ff';
        data[0] = sub;

        sub = new Object();
        sub['status'] = '비활성화';
        sub['count'] = newData.disable_cnt;
        sub['color'] = '#ffff4d';
        data[1] = sub;

        sub = new Object();
        sub['status'] = '오류';
        sub['count'] = newData.err_cnt;
        sub['color'] = '#ff3333';
        data[2] = sub;

        widget_agent.setData({dataList: data});

        // widget 추가 2019.05.08
        var data = new Array();

        sub = new Object();
        sub['status'] = '정상';
        sub['count'] = newData.w04[0];
        sub['color'] = '#0099ff';
        sub['id'] = task_id_w04;
        data[0] = sub;

        sub = new Object();
        sub['status'] = '체크';
        sub['count'] = newData.w04[1];
        sub['color'] = '#f9a836';
        sub['id'] = task_id_w04;
        data[1] = sub;

        sub = new Object();
        sub['status'] = '미수행';
        sub['count'] = newData.w04[2];
        sub['color'] = '#a658ef';
        sub['id'] = task_id_w04;
        data[2] = sub;

        sub = new Object();
        sub['status'] = '실패';
        sub['count'] = newData.w04[3];
        sub['color'] = '#ff3333';
        sub['id'] = task_id_w04;
        data[3] = sub;

        widget_w04.setData({dataList: data});

        var data = new Array();

        sub = new Object();
        sub['status'] = '정상';
        sub['count'] = newData.w05[0];
        sub['color'] = '#0099ff';
        sub['id'] = task_id_w05;
        data[0] = sub;

        sub = new Object();
        sub['status'] = '체크';
        sub['count'] = newData.w05[1];
        sub['color'] = '#f9a836';
        sub['id'] = task_id_w05;
        data[1] = sub;

        sub = new Object();
        sub['status'] = '미수행';
        sub['count'] = newData.w05[2];
        sub['color'] = '#a658ef';
        sub['id'] = task_id_w05;
        data[2] = sub;

        sub = new Object();
        sub['status'] = '실패';
        sub['count'] = newData.w05[3];
        sub['color'] = '#ff3333';
        sub['id'] = task_id_w05;
        data[3] = sub;

        widget_w05.setData({dataList: data});

    });

    req.start(); // 주기적인 통신을 시작합니다.
//     req.stop(); // 주기적인 통신을 중지
//     req.updatePeriod(1000); // 통신 주기를 변경합니다.
//     req.once(); // 통신 일회만 수행

});

function myCustomClick(e) {
    var id = e.dataItem.dataContext.id;
    var status = e.dataItem.dataContext.status;

    if(typeof(id) == 'undefined'){
        return;
    }

    f_movePage(id, status);
}


function f_movePage(task_id, click_value) {
    var form = document.createElement('form');
    var task, result, run_result;

    task = document.createElement('input');
    task.setAttribute('type', 'hidden');
    task.setAttribute('name', 'search_i_task_id');
    task.setAttribute('value', task_id);

    result = document.createElement('input');
    result.setAttribute('type', 'hidden');
    result.setAttribute('name', 'search_i_result');

    run_result = document.createElement('input');
    run_result.setAttribute('type', 'hidden');
    run_result.setAttribute('name', 'search_i_okyn');

    if(click_value =='정상'){
        result.setAttribute('value', 'Success');
        run_result.setAttribute('value', 'OK');
    } else if(click_value =='체크'){
        result.setAttribute('value', 'Success');
        run_result.setAttribute('value', 'Check');
    } else if(click_value =='미수행'){
        result.setAttribute('value', '미수행');
        //run_result.setAttribute('value', '');
    } else {
        result.setAttribute('value', 'Fail');
        //run_result.setAttribute('value', '');
    }

    form.appendChild(task);
    form.appendChild(result);
    form.appendChild(run_result);
    form.setAttribute('method', 'post');
    form.setAttribute('action', '../opmw/dailycheck')
    document.body.appendChild(form);
    form.submit();
}