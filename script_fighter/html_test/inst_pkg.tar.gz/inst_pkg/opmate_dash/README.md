OpMate Dash
====================================

	OpMate Web Dashboard

기술요소
-----------------------------------

* Python 2.7
    * Flask
        * Flask-Bootstrap
        * Flask-Login
        * Flask-Script
        * Flask-SQLAlchemy
        * Flask-paginate
    * psutil
    * PyYAML
    * XlsxWriter
    * ORM
        * SQLAlchemy
            * mysqlconnector : Using from app(WebService)
                * 최신버전(2.2.3) 설치 오류 발생
                * pip install mysql-connector==2.1.4
            * PyMySQL : Using from migrations
* JavaScript + CSS
    * Chart.js
* HTML5
* MariaDB 10.2.9
