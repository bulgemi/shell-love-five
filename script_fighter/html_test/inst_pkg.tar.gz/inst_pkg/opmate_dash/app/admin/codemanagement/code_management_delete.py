# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import json
from flask import current_app, request, flash, redirect
from dao import delete_comm_cd_dtl, delete_comm_cd_lst


def delete_group():
    """
    공통코드 관리 그룹목록 삭제
    :return:
    """
    current_app.logger.debug("call delete_group")

    del_group = dict()
    json_group_list = request.form.get("save_group_list")

    del_group = json.loads(json_group_list)

    for idx in range(len(del_group)):
        if int(del_group[idx]['comm_cd_id']) < 14:
            flash("'%s'은 필수코드로 삭제할 수 없습니다." % del_group[idx]['comm_cd_id'])
            # return code_management_render.code_management_form()
            return redirect("/admin/code_management")
        else:
            if delete_comm_cd_lst.delete_data(del_group[idx]['comm_cd_id']) is False:
                flash(u"공통코드 상세정보 삭제에 실패하였습니다.")

    flash(u"공통코드 상세정보 삭제를 완료하였습니다.")

    # return code_management_render.code_management_form()
    return redirect("/admin/code_management", code=307)


def delete_detail():
    """
    공통코드 관리 상세정보 삭제
    :return:
    """
    current_app.logger.debug("call delete_detail")

    del_dtl = dict()
    comm_code_id = request.form.get("comm_cd_id")
    json_dtl_list = request.form.get("save_dtl_list")

    del_dtl = json.loads(json_dtl_list)

    # group_code_dtl_yn = request.form.getlist("group_code_dtl_yn")
    # group_code_dtl_id = request.form.getlist("group_code_dtl_id")
    #
    # current_app.logger.debug("comm_code_id=<%r>" % comm_code_id)
    # current_app.logger.debug("group_code_dtl_yn=<%r>" % group_code_dtl_yn)
    # current_app.logger.debug("group_code_dtl_id=<%r>" % group_code_dtl_id)

    for idx in range(len(del_dtl)):
        if delete_comm_cd_dtl.delete_data(comm_code_id, del_dtl[idx]['comm_cd_val']) is False:
            flash(u"공통코드 상세정보 삭제에 실패하였습니다.")

    flash(u"공통코드 상세정보 삭제를 완료하였습니다.")

    # return code_management_render.code_management_form()
    return redirect("/admin/code_management", code=307)
