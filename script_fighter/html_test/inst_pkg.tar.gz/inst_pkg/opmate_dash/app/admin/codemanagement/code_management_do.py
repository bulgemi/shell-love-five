# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, request, current_app
# Cellar
from app import get_login_session, login_required
import code_management_delete
import code_management_save
import code_management_search

do_admin_code_management = Blueprint('do_admin_code_management', __name__, template_folder='templates')


@do_admin_code_management.route('/do_code_management', methods=["POST"])
@login_required
def code_management_do():
    action_rule = {
        'delete_group': code_management_delete.delete_group,
        'delete_detail': code_management_delete.delete_detail,
        'save': code_management_save.save,
        'search': code_management_search.search,
    }

    btn = request.form.get('btn')  # 동작 유형.

    # 버튼 종류별 동작 제어.
    if btn in action_rule:
        return action_rule[btn]()
