# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import json
from flask import Blueprint, render_template, current_app, request, flash
from flask_sqlalchemy import Pagination
# Cellar
from app import get_login_session, login_required
from app.cellarerror.sqlerror import SqlBaseException
# dao
from dao import select_comm_cd_lst, select_comm_cd_dtl

code_management = Blueprint('code_management', __name__, template_folder='templates')


@code_management.route('/popup')
def code_management_pop():
    """
    팝업 처리
    :return:
    """
    current_app.logger.debug("load popup form.")

    return render_template("popup.html")


@code_management.route('/code_management', methods=["GET", "POST"])
@login_required
def code_management_form():
    current_app.logger.debug("call code_management")

    line_map = ['홈', '관리', '공통코드 관리']

    comm_cd_id = request.form.get('comm_cd_id')
    code_group_id = request.form.get('i_code_group_id')
    code_group_name = request.form.get('i_code_group_name')

    current_app.logger.debug("comm_cd_id=<%r>" % comm_cd_id)
    current_app.logger.debug("code_group_id=<%r>, code_group_name=<%r>" %(code_group_id, code_group_name))

    if code_group_id is None:
        code_group_id = ""

    if code_group_name is None:
        code_group_name = ""

    json_key_map = {
        0: "comm_cd_id",
        1: "comm_cd_nm",
        2: "comm_cd_desc",
    }

    rows_0 = list()
    rows_1 = list()

    try:
        result = select_comm_cd_lst.get_rows(code_group_id, code_group_name)

        for item in result:
            row = dict()

            for index, data in enumerate(item):
                current_app.logger.debug("data(%d)=<%r>" % (index, data))
                row[json_key_map[index]] = data

            json_val = json.dumps(row)
            current_app.logger.debug("json_val(%r)=<%r>" % (type(json_val), json_val))

            rows_0.append(json_val)
    except SqlBaseException:
        flash(u"공통코드 조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"공통코드 조회 중 오류가 발생했습니다.")

    if comm_cd_id != "" and comm_cd_id is not None:
        try:
            comm_cd_dtl_rows = select_comm_cd_dtl.get_rows(comm_cd_id)

            for row in comm_cd_dtl_rows:
                current_app.logger.debug("row[0]=<%r>" % row[0])
                current_app.logger.debug("row[1]=<%r>" % row[1])
                current_app.logger.debug("row[2]=<%r>" % row[2])
                current_app.logger.debug("row[3]=<%r>" % row[3])

                row_1 = dict()

                row_1['comm_cd_val'] = row[0]
                row_1['comm_cd_val_nm'] = row[1]
                row_1['comm_cd_val_eng_nm'] = row[2]
                row_1['comm_cd_val_desc'] = row[3]

                json_val = json.dumps(row_1)

                rows_1.append(json_val)
        except SqlBaseException:
            flash(u"상세 공통코드 조회 중 오류가 발생했습니다.")
            current_app.logger.error(u"상세 공통코드 조회 중 오류가 발생했습니다.")

    contents = dict()

    contents['code_group_id'] = code_group_id
    contents['code_group_name'] = code_group_name

    if len(rows_0) > 0:
        contents['rows_0'] = rows_0

    if len(rows_1) > 0:
        contents['rows_1'] = rows_1

    contents['comm_cd_id'] = comm_cd_id

    return render_template('admin/code_management.html', menu_active="management",
                           login_info=get_login_session(),
                           contents=contents, line_map=line_map)
