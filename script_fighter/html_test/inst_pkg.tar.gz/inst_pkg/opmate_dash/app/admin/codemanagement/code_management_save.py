# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import json
from flask import current_app, request, flash, redirect
import code_management_render
from dao import save_comm_cd_dtl, save_comm_cd_lst
from app.admin.util import input_validation

def save():
    """
    공통코드 관리 저장
    :return:
    """
    current_app.logger.debug("call save")

    save_group = dict()
    save_dtl = dict()

    comm_code_id = request.form.get("comm_cd_id")
    json_group_list = request.form.get("save_group_list")
    json_dtl_list = request.form.get("save_dtl_list")

    save_group = json.loads(json_group_list)
    save_dtl = json.loads(json_dtl_list)

    current_app.logger.debug("json_group_list=<%r>" % json_group_list)
    current_app.logger.debug("json_dtl_list=<%r>" % json_dtl_list)

    if save_group is not None and save_group != "":
        for idxl in range(len(save_group)):
            if not input_validation.do('comm_cd_nm', save_group[idxl]['comm_cd_nm']):
                flash(u"그룹ID[%s]의 그룹명을 확인하세요." % (save_group[idxl]['comm_cd_nm']))
                # return code_management_render.code_management_form()
                return redirect("/admin/code_management", code=307)

            if not input_validation.do('comm_cd_desc', save_group[idxl]['comm_cd_desc']):
                flash(u"그룹ID[%s]의 설명을 확인하세요." % (save_group[idxl]['comm_cd_desc']))
                # return code_management_render.code_management_form()
                return redirect("/admin/code_management", code=307)

            if not save_comm_cd_lst.save_data(save_group[idxl]['comm_cd_id'], save_group[idxl]['comm_cd_nm'],
                                              save_group[idxl]['comm_cd_desc']):
                flash(u"그룹ID[%s]의 변경내용 저장에 실패하였습니다." % (save_group[idxl]['comm_cd_id']))
                # return code_management_render.code_management_form()
                return redirect("/admin/code_management", code=307)

    for idxd in range(len(save_dtl)):
        if not input_validation.do('comm_cd_val_nm', save_dtl[idxd]['comm_cd_val_nm']):
            flash(u"코드ID[%s]의 코드한글명을 확인하세요." % (save_dtl[idxd]['comm_cd_val_nm']))
            # return code_management_render.code_management_form()
            return redirect("/admin/code_management", code=307)

        if not input_validation.do('comm_cd_val_eng', save_dtl[idxd]['comm_cd_val_eng_nm']):
            flash(u"코드ID[%s]의 코드영문명을 확인하세요." % (save_dtl[idxd]['comm_cd_val_eng_nm']))
            # return code_management_render.code_management_form()
            return redirect("/admin/code_management", code=307)

        if not input_validation.do('comm_cd_val_desc', save_dtl[idxd]['comm_cd_val_desc']):
            flash(u"코드ID[%s]의 설명을 확인하세요." % (save_dtl[idxd]['comm_cd_val_desc']))
            # return code_management_render.code_management_form()
            return redirect("/admin/code_management", code=307)

        if not save_comm_cd_dtl.save_data(comm_code_id, save_dtl[idxd]['comm_cd_val'], save_dtl[idxd]['comm_cd_val_nm'],
                                          save_dtl[idxd]['comm_cd_val_eng_nm'], save_dtl[idxd]['comm_cd_val_desc']):
            flash(u"그룹ID[%s]의 코드ID[%s] 변경내용 저장에 실패하였습니다." % (comm_code_id, save_dtl[idxd]['comm_cd_val']))
            # return code_management_render.code_management_form()
            return redirect("/admin/code_management", code=307)

    flash(u"공통코드 변경내용 저장에 완료하였습니다.")
    # return code_management_render.code_management_form()
    return redirect("/admin/code_management", code=307)
