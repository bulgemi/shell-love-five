# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app
import code_management_render


def search():
    """
    공통코드 관리 조회
    :return:
    """
    current_app.logger.debug("call search")

    return code_management_render.code_management_form()
