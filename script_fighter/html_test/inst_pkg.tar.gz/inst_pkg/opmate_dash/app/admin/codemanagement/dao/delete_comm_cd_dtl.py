# _*_ coding: utf-8 _*_

from flask import current_app, flash
from app import db
from sqlalchemy import and_
# Cellar
from app.models import CommCdDtl


def delete_data(comm_cd_id, comm_cd_val=None):
    """
    공통코드 상세 데이터[COMM_CD_DTL] ROW 삭제.

    :param comm_cd_id:
    :param comm_cd_val:
    :return:
        True or False
    """
    current_app.logger.debug("comm_cd_id=<%r>" % comm_cd_id)
    # current_app.logger.debug("comm_cd_val=<%r>" % comm_cd_val)

    query = CommCdDtl.query

    # Update Data to COMM_CD_DTL
    try:
        # 기존 정보 삭제.
        query = query.filter((CommCdDtl.COMM_CD_ID == comm_cd_id.encode('utf-8')))

        if comm_cd_val is not None and comm_cd_val != "":
            query = query.filter(CommCdDtl.COMM_CD_VAL == comm_cd_val.encode('utf-8'))

        query.delete()
        db.session.commit()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False

    return True
