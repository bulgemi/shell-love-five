# _*_ coding: utf-8 _*_

from flask import current_app, flash
from app import db
from sqlalchemy import and_
# Cellar
from app.models import CommCdLst
import delete_comm_cd_dtl


def delete_data(comm_cd_id):
    """
    공통코드 그룹 데이터[COMM_CD_LST] ROW 삭제.

    :param comm_cd_id:
    :return:
        True or False
    """
    current_app.logger.debug("comm_cd_id=<%r>" % comm_cd_id)

    # Update Data to COMM_CD_LST
    try:
        # 기존 정보 삭제.
        CommCdLst.query \
            .filter(and_(CommCdLst.COMM_CD_ID == comm_cd_id.encode('utf-8'))) \
            .delete()

        if delete_comm_cd_dtl.delete_data(comm_cd_id) is False:
            db.session.rollback()
            return False

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False
    return True
