# _*_ coding: utf-8 _*_

from flask import current_app, flash
from app import db
from sqlalchemy import and_
# Cellar
from app.models import CommCdDtl
import select_comm_cd_dtl


def save_data( group_code_id, group_code_dtl_id, group_code_dtl_kor, group_code_dtl_eng, group_code_dtl_desc ):
    """
    공통코드 그룹 데이터[COMM_CD_DTL] ROW Save.

    :param comm_cd_id:
    :return:
        True or False
    """
    current_app.logger.debug("group_code_id=<%r>" % group_code_id)
    current_app.logger.debug("group_code_dtl_id=<%r>" % group_code_dtl_id)
    current_app.logger.debug("group_code_dtl_kor=<%r>" % group_code_dtl_kor)
    current_app.logger.debug("group_code_dtl_eng=<%r>" % group_code_dtl_eng)
    current_app.logger.debug("group_code_dtl_desc=<%r>" % group_code_dtl_desc)

    try:
        if group_code_dtl_id == "new":
            save_data = CommCdDtl()
            save_data.COMM_CD_ID = group_code_id
            save_data.COMM_CD_VAL = select_comm_cd_dtl.get_max_comm_cd_dtl_id(group_code_id)
            save_data.COMM_CD_VAL_NM = group_code_dtl_kor.encode('utf-8')
            save_data.COMM_CD_VAL_ENG_NM = group_code_dtl_eng.encode('utf-8')
            save_data.COMM_CD_VAL_DESC = group_code_dtl_desc.encode('utf-8')
            db.session.add(save_data)
        else:
            update_result = CommCdDtl.query \
                .filter(and_(CommCdDtl.COMM_CD_ID == group_code_id),
                        (CommCdDtl.COMM_CD_VAL == group_code_dtl_id)) \
                .first()

            update_result.COMM_CD_VAL_NM = group_code_dtl_kor.encode('utf-8')
            update_result.COMM_CD_VAL_ENG_NM = group_code_dtl_eng.encode('utf-8')
            update_result.COMM_CD_VAL_DESC = group_code_dtl_desc.encode('utf-8')

        db.session.commit()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()

        return False

    return True
