# _*_ coding: utf-8 _*_

from flask import current_app, flash
from app import db
from sqlalchemy import and_
# Cellar
from app.models import CommCdLst
import select_comm_cd_lst


def save_data( group_code_id, group_code_name, group_code_desc ):
    """
    공통코드 그룹 데이터[COMM_CD_LST] ROW Save.

    :param comm_cd_id:
    :return:
        True or False
    """
    current_app.logger.debug("group_code_id=<%r>" % group_code_id)
    current_app.logger.debug("group_code_name=<%r>" % group_code_name.encode('utf-8'))
    current_app.logger.debug("group_code_desc=<%r>" % group_code_desc.encode('utf-8'))

    try:
        if group_code_id == "new":
            max_comm_cd_id = select_comm_cd_lst.get_max_comm_cd_id()
            save_data = CommCdLst()
            save_data.COMM_CD_ID = max_comm_cd_id
            save_data.COMM_CD_NM = group_code_name.encode('utf-8')
            save_data.COMM_CD_DESC = group_code_desc.encode('utf-8')
            db.session.add(save_data)
        else:
            update_result = CommCdLst.query \
                .filter(CommCdLst.COMM_CD_ID == group_code_id) \
                .first()

            update_result.COMM_CD_NM = group_code_name.encode('utf-8')
            update_result.COMM_CD_DESC = group_code_desc.encode('utf-8')

        db.session.commit()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()

        return False

    return True
