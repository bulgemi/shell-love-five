# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, flash
from sqlalchemy import or_
# Cellar
from app.models import CommCdDtl


def get_rows(comm_cd_id):
    """
    상세 공통코드 조회.
    :param comm_cd_id:
    :return rows:
    """
    current_app.logger.debug("comm_cd_id=<%r>" % comm_cd_id)

    try:
        stmt = CommCdDtl.query.with_entities(CommCdDtl.COMM_CD_VAL,
                                             CommCdDtl.COMM_CD_VAL_NM,
                                             CommCdDtl.COMM_CD_VAL_ENG_NM,
                                             CommCdDtl.COMM_CD_VAL_DESC)
        stmt = stmt.filter(CommCdDtl.COMM_CD_ID == comm_cd_id)
        stmt = stmt.order_by(CommCdDtl.COMM_CD_VAL.asc())
        result = stmt.all()

        return result
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_max_comm_cd_dtl_id(comm_cd_id):
    """
    COMMON_CD_LST 테이블에서 마지막 comm_cd_id 를 채번한다.

    :return:comm_cd_id
    """
    try:
        result = CommCdDtl.query \
            .filter(CommCdDtl.COMM_CD_ID == comm_cd_id) \
            .order_by(CommCdDtl.COMM_CD_VAL.desc()) \
            .first()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return False, 0

    # Max(COMM_CD_VAL) 에 +1 해서 COMM_CD_VAL 반환.
    if result is not None:
        # 기존 정의된 코드의 max 값
        max_code_dtl_id = get_max_comm_cd_val(result.COMM_CD_VAL[0:6] + '%')
    else:
        # 사용자 정의 코드 max 값
        max_code_dtl_id = get_max_comm_cd_val("USR_E_%")

    return max_code_dtl_id


def get_max_comm_cd_val(cd_val):
    """
    COMMON_CD_DTL 테이블에서 유저 정의 코드(comm_cd_val) 를 채번한다.

    :return:comm_cd_id
    """
    try:
        result = CommCdDtl.query \
            .filter(CommCdDtl.COMM_CD_VAL.like(cd_val)) \
            .order_by(CommCdDtl.COMM_CD_VAL.desc()) \
            .first()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return False, 0

    # Max(COMM_CD_VAL) 에 +1 해서 COMM_CD_VAL 반환.
    if result is not None:
        i_max = int(result.COMM_CD_VAL[-4:]) + 1
        zf_max = str(i_max).zfill(4)
        max_comm_cd_val = result.COMM_CD_VAL[0:6] + zf_max
    else:
        max_comm_cd_val = "USR_E_0000"

    return max_comm_cd_val
