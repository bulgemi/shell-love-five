# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, flash
from sqlalchemy import and_
# Cellar
from app.models import CommCdLst


# def get_rows(page, per_page, comm_cd_id="", comm_cd_nm=""):
def get_rows(comm_cd_id="", comm_cd_nm=""):
    """
    공통코드 조회.
    :param page:
    :param per_page:
    :param comm_cd_id:
    :param comm_cd_nm:
    :return pagination:
    """
    if comm_cd_id == "":
        comm_cd_id = "%"
    else:
        comm_cd_id = "%{}%".format(comm_cd_id)

    if comm_cd_nm == "":
        comm_cd_nm = "%"
    else:
        comm_cd_nm = "%{}%".format(comm_cd_nm)

    current_app.logger.debug("comm_cd_id=<%r>, comm_cd_nm=<%r>" % (comm_cd_id, comm_cd_nm))

    try:
        stmt = CommCdLst.query.with_entities(CommCdLst.COMM_CD_ID, CommCdLst.COMM_CD_NM, CommCdLst.COMM_CD_DESC)
        stmt = stmt.filter(and_(CommCdLst.COMM_CD_ID.like(comm_cd_id),
                                CommCdLst.COMM_CD_NM.like(comm_cd_nm)))
        stmt = stmt.order_by(CommCdLst.COMM_CD_ID.desc())

        return stmt.all()

    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_max_comm_cd_id():
    """
    COMMON_CD_LST 테이블에서 마지막 comm_cd_id 를 채번한다.

    :return:comm_cd_id
    """
    try:
        result = CommCdLst.query \
            .order_by(CommCdLst.COMM_CD_ID.desc()) \
            .first()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return False, 0

    # Max(COMM_CD_ID) 에 +1 해서 COMM_CD_ID 반환.
    if result is not None:
        max = int(result.COMM_CD_ID) + 1
        max_comm_cd_id = str(max).zfill(10)
        return max_comm_cd_id
    else:
        return False, 0
