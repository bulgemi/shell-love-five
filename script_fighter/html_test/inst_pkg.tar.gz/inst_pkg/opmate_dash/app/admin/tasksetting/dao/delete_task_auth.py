# _*_ coding: utf-8 _*_

from flask import current_app, flash
from app import db
from sqlalchemy import and_
# Cellar
from app.models import OpmwTaskAuth


def delete_task_id(task_id):
    """
    재수행 가능그룹 정보 삭제.
    :param task_id:
    :return:
    """
    try:
        # Delete Data to TASK_AUTH
        OpmwTaskAuth.query \
            .filter(OpmwTaskAuth.TASK_ID == task_id.encode('utf-8')) \
            .delete()

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False
    return True


def delete_group(task_id, group_cd_val):
    """
    재수행 가능그룹 정보 삭제.
    :param task_id:
    :param group_cd_val:
    :return:
    """
    try:
        # Delete Data to TASK_AUTH
        OpmwTaskAuth.query \
            .filter(and_(OpmwTaskAuth.TASK_ID == task_id.encode('utf-8'),
                         OpmwTaskAuth.GROUP_CD_VAL == group_cd_val.encode('utf-8'))) \
            .delete()

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False
    return True

