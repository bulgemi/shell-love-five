# _*_ coding: utf-8 _*_

from flask import current_app, flash
from app import db
# Cellar
from app.models import OpmwTaskMgmt


def delete(task_id):
    """
    태스크 정보 삭제.
    :param task_id:
    :return:
    """
    try:
        # Delete Data to TASK_MGMT
        OpmwTaskMgmt.query \
            .filter(OpmwTaskMgmt.TASK_ID == task_id.encode('utf-8')) \
            .delete()

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False
    return True

