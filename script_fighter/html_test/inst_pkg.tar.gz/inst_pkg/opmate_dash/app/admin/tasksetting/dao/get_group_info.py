# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, flash
# Cellar
from app.models import CommCdDtl, CommCdLst


def get_commcd_dtl_info(comm_cd_val):
    """
    상세 공통코드 조회.
    :param comm_cd_val:
    :return:
    """
    current_app.logger.debug("comm_cd_val=<%r>" % comm_cd_val)

    try:
        stmt = CommCdDtl.query.with_entities(CommCdDtl.COMM_CD_VAL,
                                             CommCdDtl.COMM_CD_VAL_NM,
                                             CommCdDtl.COMM_CD_VAL_ENG_NM,
                                             CommCdDtl.COMM_CD_VAL_DESC)
        stmt = stmt.filter(CommCdDtl.COMM_CD_VAL == comm_cd_val)
        result = stmt.first()

        return result
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_commcd_dtl_comm_cd_id(comm_cd_val):
    """
    상세 공통코드 COMM_CD_ID 조회.
    :param comm_cd_val:
    :return:
    """
    current_app.logger.debug("comm_cd_val=<%r>" % comm_cd_val)

    try:
        stmt = CommCdDtl.query.with_entities(CommCdDtl.COMM_CD_ID)
        stmt = stmt.filter(CommCdDtl.COMM_CD_VAL == comm_cd_val)
        result = stmt.first()

        return result
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_commcd_lst_info(comm_cd):
    """
    공통코드 조회.
    :param comm_cd:
    :return:
    """
    current_app.logger.debug("comm_cd=<%r>" % comm_cd)

    try:
        stmt = CommCdLst.query.with_entities(CommCdLst.COMM_CD_ID,
                                             CommCdLst.COMM_CD_NM)
        stmt = stmt.filter(CommCdLst.COMM_CD_ID == comm_cd)
        result = stmt.first()

        return result
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None

