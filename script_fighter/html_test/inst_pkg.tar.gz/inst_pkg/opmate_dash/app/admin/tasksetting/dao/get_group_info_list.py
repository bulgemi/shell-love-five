# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, flash
# from sqlalchemy import and_
# Cellar
from app.models import CommCdLst, CommCdDtl


def get_comm_cd_lst_info(comm_cd_id):
    """
    그룹 항목 조회
    :param comm_cd_id:
    :return:
    """
    if comm_cd_id is None or len(comm_cd_id) <= 0:
        flash(u"COMM_CD_ID 가 없습니다.")
        return None

    current_app.logger.debug("comm_cd_id=<%r>" % comm_cd_id)

    try:
        stmt = CommCdLst.query.with_entities(CommCdLst.COMM_CD_NM)
        stmt = stmt.filter(CommCdLst.COMM_CD_ID == comm_cd_id.encode('utf-8'))

        return stmt.first()
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_comm_cd_dtl_list(comm_cd_id):
    """
    그룹 상세 조회
    :param comm_cd_id:
    :return:
    """
    if comm_cd_id is None or len(comm_cd_id) <= 0:
        flash(u"COMM_CD_ID 가 없습니다.")
        return None

    current_app.logger.debug("comm_cd_id=<%r>" % comm_cd_id)

    try:
        stmt = CommCdDtl.query.with_entities(CommCdDtl.COMM_CD_VAL_NM,
                                             CommCdDtl.COMM_CD_VAL,
                                             CommCdDtl.COMM_CD_ID)
        stmt = stmt.filter(CommCdDtl.COMM_CD_ID == comm_cd_id.encode('utf-8'))
        stmt = stmt.order_by(CommCdDtl.COMM_CD_VAL.asc())

        return stmt.all()
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None

