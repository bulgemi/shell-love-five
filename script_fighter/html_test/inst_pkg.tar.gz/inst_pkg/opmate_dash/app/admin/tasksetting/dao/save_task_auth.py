# _*_ coding: utf-8 _*_
__author__ = 'kim dong-hun'

from flask import current_app, flash
from app import db
# Cellar
from app.models import OpmwTaskAuth


def add(task_id, group_cd_val, group_cd_id):
    """
    태스크 수정
    :param task_id:
    :param group_cd_val:
    :param group_cd_id:
    :return:
        True or False
    """
    current_app.logger.debug("task_id=<%r>" % task_id)
    current_app.logger.debug("group_cd_val=<%r>" % group_cd_val)
    current_app.logger.debug("group_cd_id=<%r>" % group_cd_id)

    try:
        save_data = OpmwTaskAuth()

        save_data.TASK_ID = task_id.encode('utf-8')
        save_data.GROUP_CD_VAL = group_cd_val.encode('utf-8')
        save_data.GROUP_CD_ID = group_cd_id.encode('utf-8')

        db.session.add(save_data)
        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()

        return False

    return True
