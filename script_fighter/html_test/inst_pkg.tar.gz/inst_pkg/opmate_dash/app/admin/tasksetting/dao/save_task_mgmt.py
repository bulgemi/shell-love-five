# _*_ coding: utf-8 _*_
__author__ = 'kim dong-hun'

from flask import current_app, flash
from app import db
# from sqlalchemy import and_
# Cellar
from app.models import OpmwTaskMgmt


def update_add(task_id, task_title, task_desc=None, view_yn='N', widget_id=None):
    """
    태스크 수정
    :param task_id:
    :param task_title:
    :param task_desc:
    :param view_yn:
    :param widget_id:
    :return:
        True or False
    """
    current_app.logger.debug("task_id=<%r>" % task_id)
    current_app.logger.debug("task_title=<%r>" % task_title)
    current_app.logger.debug("task_desc=<%r>" % task_desc)
    current_app.logger.debug("view_yn=<%r>" % view_yn)
    current_app.logger.debug("widget_id=<%r>" % widget_id)

    try:
        update_result = OpmwTaskMgmt.query \
            .filter(OpmwTaskMgmt.TASK_ID == task_id.encode('utf-8')) \
            .first()

        current_app.logger.debug("update_result=<%r>" % update_result)

        if update_result is not None:  # update
            update_result.TITLE = task_title.encode('utf-8')
            update_result.VIEW_YN = view_yn.encode('utf-8')

            if task_desc is not None:
                update_result.TASK_DESC = task_desc.encode('utf-8')
        else:  # add
            save_data = OpmwTaskMgmt()
            save_data.TASK_ID = task_id
            save_data.TITLE = task_title.encode('utf-8')
            save_data.VIEW_YN = view_yn.encode('utf-8')

            if task_desc is not None:
                save_data.TASK_DESC = task_desc.encode('utf-8')

            db.session.add(save_data)
        db.session.commit()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()

        return False

    return True
