# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, flash
from sqlalchemy import and_
# Cellar
from app.models import OpmwTaskMgmt, OpmwTaskAuth


def get_task_rows(task_id=None, title=None):
    """
    태스크 목록 조회
    :param task_id:
    :param title:
    :return:
    """
    if task_id is None:
        task_id = "%"
    else:
        task_id = "%{}%".format(task_id)

    if title is None:
        title = "%"
    else:
        title = "%{}%".format(title)

    current_app.logger.debug("task_id=<%r>, title=<%r>" % (task_id, title))

    try:
        stmt = OpmwTaskMgmt.query.with_entities(OpmwTaskMgmt.TASK_ID, OpmwTaskMgmt.TITLE, OpmwTaskMgmt.TASK_DESC)
        stmt = stmt.filter(and_(OpmwTaskMgmt.TASK_ID.like(task_id),
                                OpmwTaskMgmt.TITLE.like(title)))
        stmt = stmt.order_by(OpmwTaskMgmt.TASK_ID.asc())

        return stmt.all()
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_group_rows(task_id):
    """
    태스크 목록 조회
    :param task_id:
    :return:
    """
    if task_id is None or len(task_id) <= 0:
        flash(u"Task ID가 없습니다.")
        return None

    current_app.logger.debug("task_id=<%r>" % task_id)

    try:
        stmt = OpmwTaskAuth.query.with_entities(OpmwTaskAuth.GROUP_CD_VAL,
                                                OpmwTaskAuth.GROUP_CD_ID)
        stmt = stmt.filter(OpmwTaskAuth.TASK_ID == task_id.encode('utf-8'))
        stmt = stmt.order_by(OpmwTaskAuth.TASK_ID.asc())

        return stmt.all()
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None

