# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import json
from flask import current_app, request, flash, redirect
from app.cellarerror.sqlerror import SqlBaseException
from task_setting_save import get_group_cd
# dao
from dao import delete_task_mgmt, delete_task_auth


def delete_task_list():
    """
    태스크/재수행 가능그룹 삭제
    :return:
    """
    current_app.logger.debug("call delete_task_list")

    json_task_list = request.form.get("delete_task_list")

    del_tasks = json.loads(json_task_list)

    current_app.logger.debug("json_task_list(%d)" % len(del_tasks))
    current_app.logger.debug(json.dumps(json_task_list, indent=4, sort_keys=True))

    for del_task in del_tasks:
        if del_task['task_id'] != 'new':
            if not delete_task_mgmt.delete(del_task['task_id']):
                flash(u"TASK_MGMT, 태스크ID[%s] 삭제 실패하였습니다." % del_task['task_id'])
                return redirect("/admin/task_setting", code=307)
            else:
                # 재수행 가능 그룹 테이블도 삭제
                if not delete_task_auth.delete_task_id(del_task['task_id']):
                    flash(u"TASK_AUTH, 태스크ID[%s] 삭제 실패하였습니다." % del_task['task_id'])
                    return redirect("/admin/task_setting", code=307)

    flash(u"삭제 완료하였습니다.")

    return redirect("/admin/task_setting", code=307)


def delete_group_list():
    """
    재수행 가능그룹 삭제
    :return:
    """
    current_app.logger.debug("call delete_group_list")

    task_id = request.form.get("task_id")
    # selected_group_names = request.form.getlist("selected_group_name")
    json_delete_group_lists = request.form.get("delete_group_list")
    delete_group_lists = json.loads(json_delete_group_lists)

    current_app.logger.debug("delete_group_lists(%d)=<%r>" % (len(delete_group_lists), delete_group_lists))

    # 1.'재수행 가능그룹' selected_group_name 삭제.
    try:
        for selected_group in delete_group_lists:
            tmp = selected_group['group_name'].encode('utf-8')

            if tmp != 'new':
                group_cd = get_group_cd(tmp)

                current_app.logger.debug("group_cd=<%r>" % group_cd)

                delete_task_auth.delete_group(task_id, group_cd)
    except SqlBaseException:
        flash(u"'재수행 가능그룹' 삭제 중 오류가 발생했습니다.")
        current_app.logger.error(u"'재수행 가능그룹' 삭제 중 오류가 발생했습니다.")

    flash(u"삭제 완료하였습니다.")

    return redirect("/admin/task_setting", code=307)
