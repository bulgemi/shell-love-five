# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, request, current_app
# Cellar
from app import get_login_session, login_required
import task_setting_search
import task_setting_save
import task_setting_delete
import task_setting_sync

do_admin_task_setting = Blueprint('do_admin_task_setting', __name__, template_folder='templates')


@do_admin_task_setting.route('/do_task_setting', methods=["POST"])
@login_required
def task_setting_do():
    action_rule = {
        'delete_task_list': task_setting_delete.delete_task_list,
        'delete_group_list': task_setting_delete.delete_group_list,
        'sync': task_setting_sync.sync,
        'save': task_setting_save.save,
        'search': task_setting_search.search,
    }

    btn = request.form.get('btn')  # 동작 유형.

    current_app.logger.debug("btn=<%r>" % btn)

    # 버튼 종류별 동작 제어.
    if btn in action_rule:
        return action_rule[btn]()
