# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import json
from flask import Blueprint, render_template, current_app, request, flash
# Cellar
from app import get_login_session, login_required
from app.cellarerror.sqlerror import SqlBaseException
# dao
from dao import select_task_list, get_group_info
from dao import get_group_info_list

task_setting = Blueprint('task_setting', __name__, template_folder='templates')


@task_setting.route('/popup')
@task_setting.route('/task_setting/popup')
@task_setting.route('/do_task_setting/popup')
def task_setting_pop():
    """
    팝업 처리
    :return:
    """
    current_app.logger.debug("load popup form.")

    return render_template("popup.html")


@task_setting.route('/task_setting', methods=["GET", "POST"])
@login_required
def task_setting_form():
    """
    태스크 설정 화면로딩
    :return:
    """
    current_app.logger.debug("call task_setting")

    line_map = ['홈', '관리', '태스크 설정']

    contents = dict()

    task_id = request.form.get('task_id')
    s_task_id = request.form.get('i_task_id')
    s_task_name = request.form.get('i_task_name')

    if task_id is None:
        task_id = ""

    if s_task_id is None:
        s_task_id = ""

    if s_task_name is None:
        s_task_name = ""

    contents['task_id'] = task_id
    contents['s_task_id'] = s_task_id
    contents['s_task_name'] = s_task_name

    rows_0 = list()
    rows_1 = list()

    task_json_key_map = {
        0: "task_id",
        1: "task_nm",
        2: "task_desc"
    }

    group_json_key_map = {
        0: "group_name",
        1: "group_code",
        2: "group"
    }

    comm_cd_id_list = [
        "0000000001",  # 그룹1
        "0000000002",  # 그룹2
        "0000000003",  # 그룹3
        "0000000011"  # 그룹4
    ]

    comm_cd_list_dict = dict()

    try:
        for comm_cd_id in comm_cd_id_list:
            result = get_group_info_list.get_comm_cd_lst_info(comm_cd_id)
            comm_cd_list_dict[comm_cd_id] = result[0]

    except SqlBaseException:
        flash(u"그룹정보 조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"그룹정보 조회 중 오류가 발생했습니다.")

    current_app.logger.debug("comm_cd_list_dict=<%r>" % comm_cd_list_dict)

    comm_cd_dtl_list = list()

    try:
        for comm_cd_id in comm_cd_id_list:
            result = get_group_info_list.get_comm_cd_dtl_list(comm_cd_id)

            for group_info in result:
                # current_app.logger.debug("group_info(%d)=<%r>" % (len(group_info), group_info))
                row = list()
                row.append(group_info[0])
                row.append(group_info[1])
                comm_cd_dtl_list.append(row)

    except SqlBaseException:
        flash(u"상세 그룹정보 조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"상세 그룹정보 조회 중 오류가 발생했습니다.")

    current_app.logger.debug("comm_cd_dtl_list(%d)=<%r>" % (len(comm_cd_dtl_list), comm_cd_dtl_list))

    contents['comm_cd_dtl_list'] = comm_cd_dtl_list

    try:
        result = select_task_list.get_task_rows(s_task_id, s_task_name)

        for item in result:
            row = dict()

            for index, data in enumerate(item):
                current_app.logger.debug("data(%d)=<%r>" % (index, data))

                row[task_json_key_map[index]] = data
            json_val = json.dumps(row)
            rows_0.append(json_val)
    except SqlBaseException:
        flash(u"태스크 조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"태스크 조회 중 오류가 발생했습니다.")

    if task_id != "":
        try:
            result = select_task_list.get_group_rows(task_id)

            for item in result:
                row = dict()

                dtl_info = get_group_info.get_commcd_dtl_info(item[0])

                row[group_json_key_map[0]] = "{0}({1})".format(dtl_info[1], item[0])  # 그룹명, 그룹코드
                # row[group_json_key_map[0]] = dtl_info[1]  # 그룹명
                # row[group_json_key_map[1]] = item[0]  # 그룹코드
                lst_info = get_group_info.get_commcd_lst_info(item[1])
                row[group_json_key_map[2]] = lst_info[1]  # 그룹

                current_app.logger.debug("row=<%r>" % row)

                json_val = json.dumps(row)
                rows_1.append(json_val)
        except SqlBaseException:
            flash(u"재수행 가능그룹 조회 중 오류가 발생했습니다.")
            current_app.logger.error(u"재수행 가능그룹 조회 중 오류가 발생했습니다.")

    if len(rows_0) > 0:
        contents['rows_0'] = rows_0

    if len(rows_1) > 0:
        contents['rows_1'] = rows_1

    return render_template('admin/task_setting.html', menu_active="management",
                           login_info=get_login_session(),
                           contents=contents, line_map=line_map)
