# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import json
from flask import current_app, request, flash, redirect
from app.admin.util import input_validation
from app.cellarerror.sqlerror import SqlBaseException
# dao
from dao import save_task_mgmt, save_task_auth
from dao import get_group_info
from dao import delete_task_auth


def get_group_cd(group_name):
    """
    그룹코드 추출.
    :param group_name:
    :return:
    """
    tmp = group_name.split("(")
    return tmp[1].replace(")", "")


def save():
    """
    태스크/재수행 가능그룹 저장
    :return:
    """
    current_app.logger.debug("call save")

    task_id = request.form.get('task_id')
    json_task_list = request.form.get("save_task_list")
    json_group_list = request.form.get("save_group_list")
    selected_group_names = request.form.getlist("selected_group_name")

    save_tasks = json.loads(json_task_list)
    save_groups = json.loads(json_group_list)

    current_app.logger.debug("task_id=<%r>" % task_id)
    current_app.logger.debug("json_task_list(%d)" % len(save_tasks))
    current_app.logger.debug(json.dumps(json_task_list, indent=4, sort_keys=True))
    current_app.logger.debug("json_group_list(%d)" % len(save_groups))
    current_app.logger.debug(json.dumps(json_group_list, indent=4, sort_keys=True))
    current_app.logger.debug("selected_group_names=<%r>" % selected_group_names)

    for save_task in save_tasks:
        if save_task['task_id'] == 'new':
            flash(u"'new'는 '태스크ID'로 사용할 수 없습니다.")
            return redirect("/admin/task_setting", code=307)

        if not input_validation.do('task_id', save_task['task_id']):
            flash(u"'%s'는 '태스크ID'로 사용할 수 없습니다." % save_task['task_id'])
            return redirect("/admin/task_setting", code=307)

        if not input_validation.do('task_title', save_task['task_nm']):
            flash(u"'%s'는 '태스크명'으로 사용할 수 없습니다." % save_task['task_nm'])
            return redirect("/admin/task_setting", code=307)

        if not save_task_mgmt.update_add(save_task['task_id'], save_task['task_nm'], save_task['task_desc']):
            flash(u"테스크ID[%s] 저장 실패하였습니다." % save_task['task_id'])
            return redirect("/admin/task_setting", code=307)

    # 1.'재수행 가능그룹' selected_group_name 삭제.
    try:
        for selected_group in selected_group_names:
            if selected_group != 'new':
                group_cd = get_group_cd(selected_group)

                current_app.logger.debug("group_cd=<%r>" % group_cd)

                delete_task_auth.delete_group(task_id, group_cd)
    except SqlBaseException:
        flash(u"'재수행 가능그룹' 삭제 중 오류가 발생했습니다.")
        current_app.logger.error(u"'재수행 가능그룹' 삭제 중 오류가 발생했습니다.")

    # 2.'재수행 가능그룹' save_groups 저장.
    try:
        for save_group in save_groups:
            if save_group['group_name'] == 'new':
                flash(u"'new'는 '재수행 가능그룹'으로 사용할 수 없습니다.")
                return redirect("/admin/task_setting", code=307)

            group_cd = get_group_cd(save_group['group_name'])

            current_app.logger.debug("group_cd=<%r>" % group_cd)

            group_info = get_group_info.get_commcd_dtl_comm_cd_id(group_cd)
            comm_cd_id = group_info[0]
            save_task_auth.add(task_id, group_cd, comm_cd_id)
    except SqlBaseException:
        flash(u"'재수행 가능그룹' 저장 중 오류가 발생했습니다.")
        current_app.logger.error(u"'재수행 가능그룹' 저장 중 오류가 발생했습니다.")

    flash(u"저장 완료하였습니다.")

    return redirect("/admin/task_setting", code=307)
