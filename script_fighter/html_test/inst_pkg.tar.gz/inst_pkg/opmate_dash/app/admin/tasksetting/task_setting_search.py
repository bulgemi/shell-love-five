# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, redirect


def search():
    """
    사용자 정보 조회
    :return:
    """
    current_app.logger.debug("call search")

    return redirect("admin/task_setting", code=307)
