# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, request, flash, redirect
from app.opmw.api import call_api
from app.taskqueue.task_opmw_daily import save_result


def sync():
    """
    태스크 동기화
    :return:
    """
    current_app.logger.debug("call sync")

    selected_task_id = request.form.getlist("selected_task_id")

    current_app.logger.debug("selected_task_id=<%r>" % selected_task_id)

    for task_id in selected_task_id:
        if task_id != 'new':
            api_result, ins_node_list = call_api.opmate_task_viewrunall(task_id)

            if api_result is True:
                current_app.logger.debug("ins_node_list=<%r>" % ins_node_list)

                if save_result(task_id, ins_node_list) is False:
                    flash(u"동기화 결과 저장에 실패하였습니다.")
                    return redirect("/admin/task_setting", code=307)
    flash(u"동기화 완료하였습니다.")

    return redirect("/admin/task_setting", code=307)
