# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, flash
from sqlalchemy import and_
# Cellar
from app.models import CommCdDtl


def get_info(comm_cd_val):
    """
    상세 공통코드 조회.
    :param comm_cd_val:
    :return rows:
    """
    # current_app.logger.debug("comm_cd_val=<%r>" % comm_cd_val)

    try:
        stmt = CommCdDtl.query.with_entities(CommCdDtl.COMM_CD_VAL,
                                             CommCdDtl.COMM_CD_VAL_NM,
                                             CommCdDtl.COMM_CD_VAL_ENG_NM,
                                             CommCdDtl.COMM_CD_VAL_DESC)
        stmt = stmt.filter(CommCdDtl.COMM_CD_VAL == comm_cd_val)
        result = stmt.first()

        return result
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_info_by_name(comm_cd_name, pre_fix):
    """
    상세 공통코드 조회.
    :param comm_cd_name:
    :param pre_fix:
    :return rows:
    """
    # current_app.logger.debug("comm_cd_name=<%r>" % comm_cd_name)

    try:
        stmt = CommCdDtl.query.with_entities(CommCdDtl.COMM_CD_VAL,
                                             CommCdDtl.COMM_CD_VAL_NM,
                                             CommCdDtl.COMM_CD_VAL_ENG_NM,
                                             CommCdDtl.COMM_CD_VAL_DESC)
        stmt = stmt.filter(and_(CommCdDtl.COMM_CD_VAL_NM == comm_cd_name,
                                CommCdDtl.COMM_CD_VAL.like("{}%".format(pre_fix))))
        result = stmt.first()

        return result
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_group_info(pre_fix="TEM_U%"):
    """
    상세 공통코드 조회.
    :param pre_fix:
    :return rows:
    """
    # current_app.logger.debug("pre_fix=<%r>" % pre_fix)

    try:
        stmt = CommCdDtl.query.with_entities(CommCdDtl.COMM_CD_VAL,
                                             CommCdDtl.COMM_CD_VAL_NM,
                                             CommCdDtl.COMM_CD_VAL_ENG_NM,
                                             CommCdDtl.COMM_CD_VAL_DESC)
        stmt = stmt.filter(CommCdDtl.COMM_CD_VAL.like(pre_fix))
        stmt = stmt.order_by(CommCdDtl.COMM_CD_VAL.asc())
        result = stmt.all()

        return result
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None
