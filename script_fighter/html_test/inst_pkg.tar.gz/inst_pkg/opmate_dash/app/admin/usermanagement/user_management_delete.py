# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, flash, request, redirect
# import user_management_render
from dao import delete_user_data


def delete_user():
    """
    사용자 삭제
    :return:
    """
    current_app.logger.debug("call delete_user")

    # user_yn_lst = request.form.getlist("user_yn")
    user_id_lst = request.form.getlist("selected_usr_id")

    # current_app.logger.debug("user_yn_lst=<%r>" % user_yn_lst)
    current_app.logger.debug("user_id_lst=<%r>" % user_id_lst)

    # for idx in range(len(user_yn_lst)):
    #     if user_yn_lst[idx] == 'y':
    #         if delete_user_data.delete_user(user_id_lst[idx]) is False:
    #                 flash(u"사용자 정보 삭제에 실패하였습니다.")
    #         return user_management_render.user_management_form()

    for user_id in user_id_lst:
        if delete_user_data.delete_user(user_id) is False:
            flash(u"사용자 정보 삭제에 실패하였습니다.")
        # return user_management_render.user_management_form()
        return redirect("/admin/user_management")

    flash(u"사용자 정보 삭제를 완료하였습니다.")
    # return user_management_render.user_management_form()
    return redirect("/admin/user_management")
