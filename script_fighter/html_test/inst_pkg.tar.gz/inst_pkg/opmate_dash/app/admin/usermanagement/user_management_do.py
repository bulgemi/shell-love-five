# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, request, current_app
# Cellar
from app import get_login_session, login_required
import user_management_delete
import user_management_save
import user_management_edit
import user_management_search
import user_management_excel

do_admin_user_management = Blueprint('do_admin_user_management', __name__, template_folder='templates')


@do_admin_user_management.route('/do_user_management', methods=["POST"])
@login_required
def user_management_do():
    action_rule = {
        'delete': user_management_delete.delete_user,
        'import': user_management_excel.import_user,
        'export': user_management_excel.export_user,
        'save': user_management_save.save,
        'init': user_management_edit.init_password,
        'search': user_management_search.search,
    }

    btn = request.form.get('btn')  # 동작 유형.

    # 버튼 종류별 동작 제어.
    if btn in action_rule:
        return action_rule[btn]()
