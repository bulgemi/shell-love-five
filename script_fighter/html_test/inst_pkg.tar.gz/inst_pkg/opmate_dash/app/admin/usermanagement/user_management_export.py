# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app
from datetime import datetime
from openpyxl import Workbook
from openpyxl.utils import get_column_letter, units
from openpyxl.styles.borders import Border, Side
from openpyxl.styles.alignment import Alignment
from openpyxl.styles.fonts import Font
from openpyxl.styles.fills import PatternFill
from openpyxl.comments import Comment
# Cellar
from app.cellarerror.sqlerror import SqlBaseException
# dao
from dao.select_user_list import get_all
from dao.select_comm_cd_dtl import get_info, get_group_info


def get_comm_cd_val(comm_cd_id):
    """
    공통코드 조회
    :param comm_cd_id:
    :return:
    """
    comm_cd_dtl = get_info(comm_cd_id)
    return comm_cd_dtl[1]


def do():
    """
    사용자 목록 엑셀 생성.
    :return result, file_dir, file_name:
    """
    row_index = 1
    file_dir = current_app.config['EXCEL_EXPORT_HOME']
    file_name = "users_{}.xlsx".format(datetime.now().strftime('%Y%m%d'))
    full_path = "{}/{}".format(file_dir, file_name)

    subjects = [u'사용자ID', u'사용자명', u'그룹1', u'그룹2', u'그룹3', u'그룹4', u'역할', u'상태', u'메모']
    col_widths = [30, 10, 30, 30, 30, 30, 10, 10, 100]

    group_1_comment = None
    group_2_comment = None
    group_3_comment = None
    group_4_comment = None
    role_comment = None
    stat_comment = None

    try:
        group_1 = get_group_info(pre_fix="TEM_U%")

        for idx, group in enumerate(group_1):
            if idx == 0:
                group_1_comment = "{}".format(str(group[1]))
            else:
                group_1_comment += "\n{}".format(str(group[1]))

    except SqlBaseException:
        current_app.logger.error(u"그룹1 정보 조회 중 오류가 발생했습니다.")
        return False, None, None

    try:
        group_2 = get_group_info(pre_fix="SMR_U%")

        for idx, group in enumerate(group_2):
            if idx == 0:
                group_2_comment = "{}".format(str(group[1]))
            else:
                group_2_comment += "\n{}".format(str(group[1]))

    except SqlBaseException:
        current_app.logger.error(u"그룹2 정보 조회 중 오류가 발생했습니다.")
        return False, None, None

    try:
        group_3 = get_group_info(pre_fix="DMN_U%")

        for idx, group in enumerate(group_3):
            if idx == 0:
                group_3_comment = "{}".format(str(group[1]))
            else:
                group_3_comment += "\n{}".format(str(group[1]))

    except SqlBaseException:
        current_app.logger.error(u"그룹3 정보 조회 중 오류가 발생했습니다.")
        return False, None, None

    try:
        group_4 = get_group_info(pre_fix="FUC_U%")

        for idx, group in enumerate(group_4):
            if idx == 0:
                group_4_comment = "{}".format(str(group[1]))
            else:
                group_4_comment += "\n{}".format(str(group[1]))

    except SqlBaseException:
        current_app.logger.error(u"그룹4 정보 조회 중 오류가 발생했습니다.")
        return False, None, None

    try:
        role_info = get_group_info(pre_fix="ROL_U%")

        for idx, role in enumerate(role_info):
            if idx == 0:
                role_comment = "{}".format(str(role[1]))
            else:
                role_comment += "\n{}".format(str(role[1]))

    except SqlBaseException:
        current_app.logger.error(u"역할 정보 조회 중 오류가 발생했습니다.")
        return False, None, None

    try:
        status_info = get_group_info(pre_fix="USR_S%")

        for idx, status in enumerate(status_info):
            if idx == 0:
                stat_comment = "{}".format(str(status[1]))
            else:
                stat_comment += "\n{}".format(str(status[1]))

    except SqlBaseException:
        current_app.logger.error(u"역할 정보 조회 중 오류가 발생했습니다.")
        return False, None, None

    comment_list = [
        u'E-Mail\n(최대 30자)',
        u'사용자이름\n(최대 5자)',
        group_1_comment,
        group_2_comment,
        group_3_comment,
        group_4_comment,
        role_comment,
        stat_comment,
        u'사용자 정보 메모\n(최대 200자)'
    ]

    wb = Workbook()
    ws = wb.active
    ws.title = "User List"

    thin_border = Border(left=Side(style='thin'),
                         right=Side(style='thin'),
                         top=Side(style='thin'),
                         bottom=Side(style='thin'))

    align_center = Alignment(horizontal='center')
    gray_fill = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")

    # print subject
    for idx, subject in enumerate(subjects):
        i = get_column_letter(idx+1)
        ws.column_dimensions[i].width = col_widths[idx]
        ws_cell = ws.cell(row=row_index, column=(idx+1), value=subject)
        ws_cell.border = thin_border
        ws_cell.alignment = align_center
        ws_cell.fill = gray_fill
        ws_cell.font = Font(bold=True)

        comment = Comment(comment_list[idx], "admin")
        # Todo: comment 크기 변경, 2019.02.12. kim dong-hun
        comment.height = units.points_to_pixels(500)
        comment.width = units.points_to_pixels(500)

        ws_cell.comment = comment

    # print user list
    user_list = get_all()

    current_app.logger.debug(u"------------->user_list=<%r>" % user_list)

    for user_info in user_list:
        row_index += 1
        col_index = 1

        ws.cell(row=row_index, column=col_index, value=user_info[0]).border = thin_border
        col_index += 1
        ws.cell(row=row_index, column=col_index, value=user_info[1]).border = thin_border
        col_index += 1
        ws.cell(row=row_index, column=col_index, value=get_comm_cd_val(user_info[2])).border = thin_border
        col_index += 1
        ws.cell(row=row_index, column=col_index, value=get_comm_cd_val(user_info[3])).border = thin_border
        col_index += 1
        ws.cell(row=row_index, column=col_index, value=get_comm_cd_val(user_info[4])).border = thin_border
        col_index += 1
        ws.cell(row=row_index, column=col_index, value=get_comm_cd_val(user_info[5])).border = thin_border
        col_index += 1
        ws.cell(row=row_index, column=col_index, value=get_comm_cd_val(user_info[6])).border = thin_border
        col_index += 1
        ws.cell(row=row_index, column=col_index, value=get_comm_cd_val(user_info[7])).border = thin_border
        col_index += 1
        ws.cell(row=row_index, column=col_index, value=user_info[8]).border = thin_border

    # save
    wb.save(full_path)

    return True, file_dir, file_name
