# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, request, flash, redirect
from dao import save_user_data
from app.admin.util import input_validation
import user_management_render


def save():
    """
    사용자 추가/수정 저장
    :return:
    """
    current_app.logger.debug("call save")

    usr_id = request.form.get('detail_id')
    new_usr_id = request.form.get('user_id')
    usr_nm = request.form.get('user_name')
    memo = request.form.get('user_memo')
    dept_cl_cd = request.form.get('group1')
    sm_cl_cd = request.form.get('group2')
    domain_cl_cd = request.form.get('group3')
    func_cl_cd = request.form.get('group4')
    roll_cl_cd = request.form.get('user_role')
    usr_stat_cd = request.form.get('user_status')

    current_app.logger.debug("usr_id=<%r>" % usr_id)
    current_app.logger.debug("new_usr_id=<%r>" % new_usr_id)
    current_app.logger.debug("usr_id=<%r>" % usr_id)
    current_app.logger.debug("usr_nm=<%r>" % usr_nm)
    current_app.logger.debug("memo=<%r>" % memo)
    current_app.logger.debug("dept_cl_cd=<%r>" % dept_cl_cd)
    current_app.logger.debug("sm_cl_cd=<%r>" % sm_cl_cd)
    current_app.logger.debug("domain_cl_cd=<%r>" % domain_cl_cd)
    current_app.logger.debug("func_cl_cd=<%r>" % func_cl_cd)
    current_app.logger.debug("roll_cl_cd=<%r>" % roll_cl_cd)

    if usr_id == u"new":
        usr_id = new_usr_id

        current_app.logger.debug("usr_id=<%r>" % usr_id)
        current_app.logger.debug("new_usr_id=<%r>" % new_usr_id)

    detail_param ={
        0: usr_id,
        1: usr_nm,
        2: memo,
        3: dept_cl_cd,
        4: sm_cl_cd,
        5: domain_cl_cd,
        6: func_cl_cd,
        7: roll_cl_cd,
        8: usr_stat_cd,
    }

    if not input_validation.do('user_id', usr_id):
        flash(u"사용자 ID를 확인하세요.")
        flash(u"ID는 e-mail 형식입니다.")
        return user_management_render.user_management_form(detail_param=detail_param)

    if not input_validation.do('user_name', usr_nm):
        flash(u"사용자명을 확인하세요.")
        return user_management_render.user_management_form(detail_param=detail_param)

    if not input_validation.do('memo', memo):
        flash(u"메모 내용을 확인하세요.")
        return user_management_render.user_management_form(detail_param=detail_param)

    result = save_user_data.save_user(usr_id, usr_nm, memo, dept_cl_cd, sm_cl_cd,
                                      domain_cl_cd, func_cl_cd, roll_cl_cd, usr_stat_cd)

    if result is False:
        flash(u"사용자 저장에 실패하였습니다.(%{})".format(usr_id))
        return user_management_render.user_management_form(detail_param=detail_param)

    flash(u"사용자 저장을 완료하였습니다.")

    return redirect("admin/user_management", code=307)
