# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app
import user_management_render


def search():
    """
    사용자 정보 조회
    :return:
    """
    current_app.logger.debug("call search")

    return user_management_render.user_management_form()
