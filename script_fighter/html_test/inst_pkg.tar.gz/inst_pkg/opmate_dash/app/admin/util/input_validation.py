# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'


from cerberus import Validator


schema = {
    'user_id': {'type': 'string',
                'regex': '^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$',
                'minlength': 8, 'maxlength': 30},
    'user_name': {'type': 'string', 'minlength': 1, 'maxlength': 10},
    'memo': {'type': 'string', 'minlength': 0, 'maxlength': 200},
    'group1': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'group2': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'group3': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'group4': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'role': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'status': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'comm_cd_id': {'type': 'string', 'minlength': 0, 'maxlength': 10},
    'comm_cd_nm': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'comm_cd_desc': {'type': 'string', 'minlength': 0, 'maxlength': 500},
    'comm_cd_val': {'type': 'string', 'minlength': 0, 'maxlength': 10},
    'comm_cd_val_nm': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'comm_cd_val_eng': {'type': 'string', 'minlength': 0, 'maxlength': 30},
    'comm_cd_val_desc': {'type': 'string', 'minlength': 0, 'maxlength': 500},
    'cat_id': {'type': 'string', 'minlength': 1, 'maxlength': 50},
    'cat_nm': {'type': 'string', 'minlength': 1, 'maxlength': 100},
    'use_yn': {'type': 'string', 'minlength': 1, 'maxlength': 1},
    'task_id': {'type': 'string', 'minlength': 1, 'maxlength': 30},
    'task_title': {'type': 'string', 'minlength': 1, 'maxlength': 256},
    'node_id': {'type': 'string', 'minlength': 1, 'maxlength': 50},
}

v = Validator(schema)


def do(key, value):
    """입력 값 점검.

    :param key:
    :param value:
    :return: True or False
    """
    input_value = dict()
    input_value[key] = value

    return v.validate(input_value)
