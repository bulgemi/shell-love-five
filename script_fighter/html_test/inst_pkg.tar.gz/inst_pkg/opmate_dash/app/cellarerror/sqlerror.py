# _*_ coding: utf-8 _*_

from flask import current_app
from app import db


class SqlBaseException(Exception):
    def __init__(self, e):
        self.e = e
        current_app.logger.error(u"args=[%s], message=[%s]"
                                 % (e.args, e.message))
        db.session.rollback()

    def __str__(self):
        return self.e.message
