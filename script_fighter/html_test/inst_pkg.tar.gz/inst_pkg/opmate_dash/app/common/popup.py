# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, render_template, current_app, request, flash, session, redirect, url_for

popup = Blueprint('popup', __name__, template_folder='templates')


@popup.route('/popup')
def popup_form():
    """
    팝업 처리
    :return:
    """
    current_app.logger.debug("load popup form.")

    data = request.form.get('data')

    current_app.logger.debug("data=<%r>." % data)

    return render_template("popup.html")
