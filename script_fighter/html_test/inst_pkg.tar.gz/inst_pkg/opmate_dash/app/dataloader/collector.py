# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from cx_Oracle import connect, makedsn
import os

os.putenv('NLS_LANG', 'KOREAN_KOREA.KO16KSC5601')


class Collector(object):
    __viewer_name__ = "TOMS_MIG_DATA"
    __viewer_pk__ = "COMP_MGMT_NUM"
    conn = None
    query = None
    logger = None

    def __init__(self, address, port, db, user, password, logger):
        tns = makedsn(address, port, db)
        self.conn = connect(user, password, tns, encoding='utf-8', nencoding='utf-8')
        self.logger = logger

    def disconnect(self):
        self.conn.close()

    def make_query(self, column, condition):
        query_temp = "SELECT * FROM (SELECT ROWNUM AS RNUM, "

        for index, info in enumerate(column):
            if index != 0:
                query_temp += ", "
            query_temp += info['column']

        query_temp += " FROM {}".format(self.__viewer_name__)

        if condition is not None:
            for index, info in enumerate(condition):
                if index == 0:
                    query_temp += " WHERE "
                else:
                    query_temp += " AND "

                query_temp += "{} {} ".format(info['column'], info['operation'])

                if info['operation'] == 'IN' or info['operation'] == 'NOT IN':
                    for i, value in enumerate(info['value']):
                        if i != 0:
                            query_temp += ", "
                        query_temp += "'{}' ".format(value)
                else:
                    query_temp += "'{}' ".format(info['value'])

        query_temp += " ORDER BY {} ASC ".format(self.__viewer_pk__)
        query_temp += ") WHERE RNUM >= {0} AND RNUM < {1} "

        self.query = query_temp

        return True

    def dump_query(self):
        return self.query

    def select(self, start, end):
        cur = self.conn.cursor()

        statement = self.query.format(start, end)

        # self.logger.debug("statement=<%r>" % statement)

        cur.execute(statement)

        return cur.fetchall()
