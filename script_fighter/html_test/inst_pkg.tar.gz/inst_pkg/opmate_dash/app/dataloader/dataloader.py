# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import sys
import os
from sys import exit
import argparse
import yaml
import codecs
import logging
from concurrent.futures import ProcessPoolExecutor, wait
from multiprocessing import Manager
# DataLoader
from collector import Collector
from loader import Loader
from parallel_loader import parallel_loader

sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))))

from app.cipher.crypto_util import AESCipher


collector_object = None
loader_object = None


class ConfigInfo(object):
    database = None
    toms_column = None
    cellar_column = None
    key_column = list()
    query = None
    FetchSize = None
    ExecutePoolSize = None
    logger = logging.getLogger()

    def __init__(self, config_file):
        # self.logger.setLevel(logging.DEBUG)
        self.logger.setLevel(logging.ERROR)
        formatter = logging.Formatter("%(levelname)-8s (%(process)d)[%(asctime)s] %(module)s(%(lineno)d) %(message)s")
        # ch = logging.StreamHandler()

        condition_map = {
            0: 'EQUAL',
            1: 'NOT EQUAL',
            2: 'LIKE',
            3: 'NOT LIKE',
            4: 'IN',
            5: 'NOT IN'
        }

        config_info = yaml.load(codecs.open(config_file, "r", "euc-kr"))

        logging_info = config_info['Logging']

        ch = logging.FileHandler(logging_info['LogFile'])
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        parallel_info = config_info['Parallel']

        self.FetchSize = parallel_info['FetchSize']
        self.ExecutePoolSize = parallel_info['ExecutePoolSize']

        self.database = config_info['Database']

        column_info = config_info['Column']

        self.toms_column = [None for _ in column_info]
        self.cellar_column = [None for _ in column_info]

        for x in column_info:
            # print("column_info=<%r>" % x)
            toms_column_info = dict()
            cellar_column_info = dict()
            key_column_info = dict()

            toms_column_info['column'] = x['TomsColumn']
            toms_column_info['type'] = str(x['TomsType']).upper()

            if str(x['Key']).upper() == 'Y':
                key_column_info['column'] = x['CellarColumn']
                key_column_info['index'] = x['Index']-1
                self.key_column.append(key_column_info)

            cellar_column_info['column'] = x['CellarColumn']
            cellar_column_info['type'] = str(x['CellarType']).upper()

            self.toms_column[x['Index']-1] = toms_column_info
            self.cellar_column[x['Index']-1] = cellar_column_info

        self.logger.debug("toms_column(%r)=<%r>" % (len(self.toms_column), self.toms_column))
        self.logger.debug("cellar_column(%r)=<%r>" % (len(self.cellar_column), self.cellar_column))
        self.logger.debug("key_column(%r)=<%r>" % (len(self.key_column), self.key_column))

        query_info = config_info['Query']

        if len(query_info) > 0:
            self.query = [None for _ in query_info]

            for x in query_info:
                condition_info = dict()

                condition_info['operation'] = condition_map[x['Operation']]
                condition_info['column'] = x['Column']
                condition_info['value'] = x['Value']

                self.query[x['Index']-1] = condition_info
        else:
            self.query = None

        self.logger.debug("query(%r)=<%r>" % (len(self.query), self.query))


def init_data_loader(config_info):
    global collector_object
    global loader_object

    aes = AESCipher()

    config_info.logger.debug("config_info=<%r>" % config_info)

    db_info = config_info.database
    toms_db_info = db_info['From']
    cellar_db_info = db_info['To']

    # connect TOMS Oracle
    collector_object = Collector(toms_db_info['Host'], toms_db_info['Port'], toms_db_info['DB'],
                                 toms_db_info['User'], aes.decrypt(toms_db_info['Password']),
                                 config_info.logger)

    config_info.logger.debug("collector_object(%r).conn=<%r>" % (id(collector_object), collector_object.conn))

    collector_object.make_query(config_info.toms_column, config_info.query)

    config_info.logger.debug("collector query=<%r>" % collector_object.dump_query())

    loader_object = Loader(cellar_db_info['Host'], cellar_db_info['Port'], cellar_db_info['DB'],
                           cellar_db_info['User'], aes.decrypt(cellar_db_info['Password']),
                           config_info.ExecutePoolSize, config_info.logger)

    if loader_object.insert_toms_mig_hist() is False:
        config_info.logger.error("Failed loader_object.insert_toms_mig_hist()")
        return False

    loader_object.make_query(config_info.toms_column, config_info.cellar_column, config_info.key_column)

    config_info.logger.debug("dump_insert_query=<%r>" % loader_object.dump_insert_query())
    config_info.logger.debug("dump_update_query=<%r>" % loader_object.dump_update_query())

    return True


def done_data_loader(config_info, status):
    result_done_data_loader = True

    global collector_object
    global loader_object

    config_info.logger.debug("collector_object(%r)" % id(collector_object))
    config_info.logger.debug("loader_object(%r)" % id(loader_object))

    if loader_object.update_toms_mig_hist(status) is False:
        config_info.logger.error("Failed loader_object.update_toms_mig_hist({})".format(status))
        result_done_data_loader = False

    # disconnect TOMS Oracle
    collector_object.disconnect()
    loader_object.disconnect()

    return result_done_data_loader


def parallel_execute(config_info, q, cellar_db_info):
    result_parallel_loader = True

    aes = AESCipher()

    # 병렬 처리 영역, begin, 2018.02.09. kim dong-hun
    future_tasks = list()

    # config_info.logger.debug("q.qsize()=<%r>" % q.qsize())

    if q.qsize() <= config_info.ExecutePoolSize:
        with ProcessPoolExecutor(max_workers=config_info.ExecutePoolSize) as parallel_load:
            for i in range(q.qsize()):
                # def parallel_loader(config_info, address, port, db, user, password, data)
                future_tasks.append(parallel_load.submit(parallel_loader, config_info, cellar_db_info['Host'],
                                                         cellar_db_info['Port'], cellar_db_info['DB'],
                                                         cellar_db_info['User'],
                                                         aes.decrypt(cellar_db_info['Password']),
                                                         q.get(True, 0.05)))

            result_tasks = wait(future_tasks)

            for result_task in result_tasks:
                for i, r in enumerate(result_task):
                    if r.result() is False:
                        config_info.logger.error("Failed task(%r)=<%r>" % (i, r.result()))
                        result_parallel_loader = False
    # 병렬 처리 영역, end, 2018.02.09. kim dong-hun

    return result_parallel_loader


def main_data_loader(config_info):
    result_parallel_execute = True

    global collector_object
    global loader_object

    db_info = config_info.database
    cellar_db_info = db_info['To']

    start = 1
    end = config_info.FetchSize + 1

    # 병렬 처리 영역, begin, 2018.02.09. kim dong-hun
    manager = Manager()
    q = manager.Queue()
    # 병렬 처리 영역, end, 2018.02.09. kim dong-hun

    while True:
        result = collector_object.select(start, end)

        if len(result) <= 0:
            break

        # single process 처리.
        # loader_object.execute_query(result, config_info.key_column)

        start += config_info.FetchSize
        end += config_info.FetchSize

        # 병렬 처리 영역, begin, 2018.02.09. kim dong-hun
        config_info.logger.debug("q.qsize()=<%r>" % q.qsize())

        if q.qsize() == config_info.ExecutePoolSize:
            if parallel_execute(config_info, q, cellar_db_info) is False:
                config_info.logger.error("Failed parallel_execute.")
                result_parallel_execute = False
        else:
            q.put(result)
        # 병렬 처리 영역, end, 2018.02.09. kim dong-hun

    # 병렬 처리 영역, begin, 2018.02.09. kim dong-hun
    if q.qsize() > 0:
        if parallel_execute(config_info, q, cellar_db_info) is False:
            config_info.logger.error("Failed parallel_execute.")
            result_parallel_execute = False
    # 병렬 처리 영역, end, 2018.02.09. kim dong-hun

    config_info.logger.debug("- End. -")

    return result_parallel_execute


if __name__ == '__main__':
    reload(sys)
    sys.setdefaultencoding('utf-8')

    result = True
    parser = argparse.ArgumentParser(description='TOMS Data Migration Batch Program.')

    parser.add_argument('-c', help='config file(full path)', required=True)
    args = parser.parse_args()

    config = ConfigInfo(args.c)

    # print("parallel=<%r>" % config.parallel)
    # print("column=<%r>" % config.column)
    # print("database=<%r>" % config.database)
    # print("query=<%r>" % config.query)

    if init_data_loader(config) is False:
        config.logger.error("Failed init_data_loader.")
        result = False

    if result is True:
        if main_data_loader(config) is False:
            config.logger.error("Failed main_data_loader.")
            result = False

        if result is True:
            status = 'D'
        else:
            status = 'E'

        if done_data_loader(config, status) is False:
            config.logger.error("Failed done_data_loader.")
            result = False

    if result is True:
        exit(0)
    else:
        exit(1)
