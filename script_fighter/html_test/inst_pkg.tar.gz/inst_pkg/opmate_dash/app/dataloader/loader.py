# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from datetime import datetime
from sqlalchemy import create_engine, Column, String
from sqlalchemy.orm import sessionmaker, scoped_session
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.exc import IntegrityError

Base = declarative_base()


class TomsMigHist(Base):
    """
    TOMS_MIG_HIST (TOMS 연동 이력)
    PK : INIT_DTM

    No. 컬럼ID       컬럼명               컬럼타입     컬럼길이 설명
    01 	INIT_DTM    TOMS 연동 시작시간    VARCHAR 	14 	    PK
    02 	DONE_DTM    TOMS 연동 완료시간 	VARCHAR 	14
    03 	STATUS      처리결과 	            CHAR        1
    """
    __tablename__ = 'TOMS_MIG_HIST'

    INIT_DTM = Column(String(14), primary_key=True, unique=False, nullable=False)  # TOMS 연동 시작시간, PK
    DONE_DTM = Column(String(14), unique=False, nullable=False)  # TOMS 연동 완료시간
    STATUS = Column(String(1), unique=False, nullable=False)  # 처리결과


class Loader(object):
    __table_name__ = "TOMS_MIG_DATA_MOCK"
    engine = None
    session = None
    insert_query = None
    update_query = None
    init_dtm = None
    logger = None
    pool_size = None

    def __init__(self, address, port, db, user, password, pool_size, logger):
        db_uri = 'mysql+pymysql://{}:{}@{}:{}/{}'.format(user, password, address, port, db)

        self.engine = create_engine(db_uri, pool_size=pool_size, encoding='utf-8', convert_unicode=True)
        session = sessionmaker(bind=self.engine)
        self.session = session()
        self.logger = logger
        self.pool_size = pool_size

    def disconnect(self):
        self.session.close()

    def insert_toms_mig_hist(self):
        self.init_dtm = datetime.now().strftime("%Y%m%d%H%M%S")

        toms_mig_hist = TomsMigHist()

        toms_mig_hist.INIT_DTM = self.init_dtm
        toms_mig_hist.DONE_DTM = '00000000000000'
        toms_mig_hist.STATUS = 'I'

        try:
            self.session.add(toms_mig_hist)
            self.session.commit()

            return True
        except Exception as e:
            self.logger.error("Error args=[%s], message=[%s]" % (e.args, e.message))
            self.session.rollback()

            return False

    def update_toms_mig_hist(self, status):
        try:
            toms_mig_hist = self.session.query(TomsMigHist).filter_by(INIT_DTM=self.init_dtm).first()

            self.logger.debug("toms_mig_hist=<%r>" % toms_mig_hist)

            toms_mig_hist.DONE_DTM = datetime.now().strftime("%Y%m%d%H%M%S")
            toms_mig_hist.STATUS = status

            self.session.add(toms_mig_hist)
            self.session.commit()

            return True
        except Exception as e:
            self.logger.error("Error args=[%s], message=[%s]" % (e.args, e.message))
            self.session.rollback()

            return False

    def make_query(self, toms_column, cellar_column, key_column):
        insert_query = "INSERT INTO {} ( RPT_ID, ".format(self.__table_name__)

        for index, column in enumerate(cellar_column):
            if index != 0:
                insert_query += ", "

            insert_query += column['column']

        insert_query += ") VALUES ( 'MASTER0000', "

        for index, column in enumerate(cellar_column):
            if index != 0:
                insert_query += ", "

            toms_column_info = toms_column[index]

            if column['type'] == 'STRING' and toms_column_info['type'] == 'STRING':
                insert_query += "'{%d}'" % index
            elif column['type'] == 'INT' and toms_column_info['type'] == 'STRING':
                insert_query += "{%d}" % index
            elif column['type'] == 'STRING' and toms_column_info['type'] == 'INT':
                insert_query += "'{%d}'" % index
            else:
                insert_query += "{%d}" % index

        insert_query += ")"

        self.insert_query = insert_query

        update_index = 0
        update_query = "UPDATE {} SET ".format(self.__table_name__)

        for index, column in enumerate(cellar_column):
            skip = False

            for key in key_column:
                if key['index'] == index:
                    skip = True

            if skip is False:
                if index != 0:
                    update_query += ", "

                update_query += "{} = ".format(column['column'])

                toms_column_info = toms_column[index]

                if column['type'] == 'STRING' and toms_column_info['type'] == 'STRING':
                    update_query += "'{%d}'" % update_index
                elif column['type'] == 'INT' and toms_column_info['type'] == 'STRING':
                    update_query += "{%d}" % update_index
                elif column['type'] == 'STRING' and toms_column_info['type'] == 'INT':
                    update_query += "'{%d}'" % update_index
                else:
                    update_query += "{%d}" % update_index
                update_index += 1

        update_query += " WHERE RPT_ID = 'MASTER0000' "

        if len(key_column) > 0:
            for key_index, key in enumerate(key_column):
                update_query += " AND "

                key_value = cellar_column[key['index']]

                update_query += "{} = ".format(key_value['column'])

                if key_value['type'] == 'STRING':
                    update_query += "'{%d}'" % update_index
                else:
                    update_query += "{%d}" % update_index
                update_index += 1

        self.update_query = update_query

    def dump_insert_query(self):
        return self.insert_query

    def dump_update_query(self):
        return self.update_query

    def insert_update(self, insert_data, update_data, use_scoped_session=False):
        self.logger.debug("begin insert/update")

        if use_scoped_session is False:
            try:
                self.session.execute(self.insert_query.format(*insert_data))
                self.session.commit()
            except IntegrityError as e:
                if e.message.find("(pymysql.err.IntegrityError) (1062,") != -1:
                    try:
                        self.session.execute(self.update_query.format(*update_data))
                        self.session.commit()
                    except IntegrityError as e:
                        self.logger.error("Failed UPDATE, args=<%r>, message=<%r>" % (e.args, e.message))
                        self.session.rollback()

                        return False
                else:
                    self.logger.error("Failed INSERT, args=<%r>, message=<%r>" % (e.args, e.message))
                    self.session.rollback()

                    return False
        else:
            s_session = scoped_session(self.session)

            try:
                s_session.execute(self.insert_query.format(*insert_data))
                s_session.commit()
            except IntegrityError as e:
                if e.message.find("(pymysql.err.IntegrityError) (1062,") != -1:
                    try:
                        s_session.execute(self.update_query.format(*update_data))
                        s_session.commit()
                    except IntegrityError as e:
                        self.logger.error("Failed UPDATE, args=<%r>, message=<%r>" % (e.args, e.message))
                        s_session.rollback()

                        s_session.remove()
                        return False
                else:
                    self.logger.error("Failed INSERT, args=<%r>, message=<%r>" % (e.args, e.message))
                    s_session.rollback()

                    s_session.remove()
                    return False

            s_session.remove()

        return True

    def execute_query(self, data, key_column, cellar_column, toms_column):
        # self.logger.debug("key_column=<%r>" % key_column)

        for temp_row in data:
            insert_temp = list()

            # self.logger.debug("temp_row(%r)=<%r>" % (len(temp_row), temp_row))

            for index, col in enumerate(temp_row[1:]):
                self.logger.debug("col(%r)=<%r>" % (index, col))

                cellar_column_info = cellar_column[index]

                if col is None:
                    if cellar_column_info['type'] == 'STRING':
                        insert_temp.append('')
                    else:
                        insert_temp.append('0')
                else:
                    toms_column_info = toms_column[index]

                    if isinstance(col, str) is True:
                        # Todo: encoding 문제 있음, 2018.02.07. kim dong-hun
                        col_data = col.decode('iso-8859-1').encode('utf8')
                        # col_data = col.encode('latin-1', 'ignore')  # Todo: 한글 테스트 필요, 2017.02.07. kim dong-hun

                        col_data = col_data.strip()

                        if toms_column_info['type'] == 'INT':
                            col_data = str(int(float(col_data)))

                        self.logger.debug("col_data=<%r>" % col_data)

                        if toms_column_info['type'] == 'INT':
                            insert_temp.append(filter(str.isdigit(), col_data))
                        else:
                            col_data = col_data.replace("'", "\\'")
                            col_data = col_data.replace('"', '\\"')
                            col_data = col_data.replace("%", "\%")
                            col_data = col_data.replace(":", "\:")

                            insert_temp.append(col_data)
                    else:
                        col_data = col

                        self.logger.debug("col_data=<%r> > <%r>" % (col_data, str(int(float(col_data)))))

                        try:
                            if col_data != '':
                                insert_temp.append(str(int(float(col_data))))
                            else:
                                insert_temp.append('0')
                        except ValueError:
                            self.logger.error("ValueError error: <%r>" % col_data)
                            insert_temp.append('0')

            insert_data = tuple(insert_temp)

            update_temp = list()

            for index, col in enumerate(insert_data):
                skip = False

                for key in key_column:
                    if key['index'] == index:
                        skip = True

                if skip is False:
                    update_temp.append(col)

            for key in key_column:
                update_temp.append(insert_data[key['index']])

            update_data = tuple(update_temp)

            if self.insert_update(insert_data, update_data) is False:
                return False

        return True
