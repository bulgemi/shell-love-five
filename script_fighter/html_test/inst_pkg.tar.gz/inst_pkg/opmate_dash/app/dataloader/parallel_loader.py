# _*_ coding: utf-8 _*_
__author__ = 'kim dong-hun'

from loader import Loader


def parallel_loader(config_info, address, port, db, user, password, data):
    loader_object = Loader(address, port, db, user, password, config_info.ExecutePoolSize, config_info.logger)
    loader_object.make_query(config_info.toms_column, config_info.cellar_column, config_info.key_column)

    # config_info.logger.debug("dump_insert_query=<%r>" % loader_object.dump_insert_query())
    # config_info.logger.debug("dump_update_query=<%r>" % loader_object.dump_update_query())
    config_info.logger.debug("running process....<%r>" % len(data))

    result = loader_object.execute_query(data, config_info.key_column,
                                         config_info.cellar_column, config_info.toms_column)

    loader_object.disconnect()

    return result
