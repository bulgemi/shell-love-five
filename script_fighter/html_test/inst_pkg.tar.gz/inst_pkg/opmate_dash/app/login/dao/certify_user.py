# _*_ coding: utf-8 _*_

from flask import current_app
from sqlalchemy import and_
# Cellar Data
from app.models import CellarUser
from app.cipher.crypto_util import AESCipher


def certify_user(user_id, password):
    """
    CellarUser 테이블 이용한 사용자 인증 처리.
    :param user_id:
    :param password:
    :return: True or False
    """
    # current_app.logger.debug("user_id=<%r>, password=<%r>" % (user_id, password))
    aes = AESCipher()

    try:
        result = CellarUser.query.with_entities(CellarUser.USR_PW)\
            .filter(and_(CellarUser.USR_ID == user_id.decode('utf-8'),
                         CellarUser.USR_STAT_CD == 'USR_S_0000'))\
            .first()

        if result is None:
            return False

        # current_app.logger.debug("result(%r)=<%r>, password(%r)=<%r>" % (type(result[0]), result[0],
        #                                                                  type(password), password))

        if aes.decrypt(result[0]) != password:
            return False

        return True

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]" % (e.args, e.message))

        return False


def load_user_info(user_id):
    """
    CellarUser 테이블에서 사용자 정보 조회.
    :param user_id:
    :return: None or 사용자 정보
    """
    # current_app.logger.debug("user_id=<%r>" % user_id)

    try:
        result = CellarUser.query.with_entities(CellarUser.USR_NM,
                                                CellarUser.USR_CORP_NUM,
                                                CellarUser.DEPT_CL_CD,
                                                CellarUser.SM_CL_CD,
                                                CellarUser.DOMAIN_CL_CD,
                                                CellarUser.FUNC_CL_CD,
                                                CellarUser.BOOK_MARK_QTY,
                                                CellarUser.ROLL_CL_CD)\
            .filter(CellarUser.USR_ID == user_id.decode('utf-8'))\
            .first()

        if result is None:
            return None

        certify_info = dict()

        certify_info['USR_ID'] = user_id.decode('utf-8')
        certify_info['USR_NM'] = result[0]
        certify_info['USR_CORP_NUM'] = result[1]
        certify_info['DEPT_CL_CD'] = result[2]
        certify_info['SM_CL_CD'] = result[3]
        certify_info['DOMAIN_CL_CD'] = result[4]
        certify_info['FUNC_CL_CD'] = result[5]
        certify_info['BOOK_MARK_QTY'] = result[6]
        certify_info['ROLL_CL_CD'] = result[7]

        return certify_info

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]" % (e.args, e.message))

        return None
