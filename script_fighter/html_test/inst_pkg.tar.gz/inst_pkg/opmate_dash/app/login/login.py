# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, render_template, current_app, request, flash, session, redirect, url_for
from login_validation import login_validation
# Cellar
from app import get_login_session
# Cellar DAO
from dao.certify_user import certify_user, load_user_info


login = Blueprint('login', __name__, template_folder='templates')
logout = Blueprint('logout', __name__, template_folder='templates')
auth = Blueprint('auth', __name__, template_folder='templates')


@login.route('/popup')
def logout_pop():
    """
    팝업 처리
    :return:
    """
    current_app.logger.debug("load popup form.")

    return render_template("popup.html")


@login.route('/logout')
def logout_form():
    """
    로그아웃 처리.
    :return:
    """
    current_app.logger.debug("load logout form.")

    session.pop('logged_in', None)
    flash(u'You have been logged out.')

    return render_template('login.html', menu_active="login", login_info=get_login_session())


@login.route('/form')
def login_form():
    """
    로그인 화면을 로딩한다.
    :return:
    """
    # current_app.logger.debug("load login form.")
    current_app.logger.debug("request.endpoint=<%r>" % request.endpoint)

    return render_template('login.html', menu_active="login", login_info=get_login_session())


@auth.route('/auth', methods=["POST"])
def login_auth():
    """
    로그인 처리.
    :return:
    """
    # current_app.logger.debug("request.form=<%r>" % request.form)
    current_app.logger.debug("request.endpoint=<%r>" % request.endpoint)

    user_id = request.form.get('login_email')
    user_pw = request.form.get('login_pw')
    next_url = request.form.get('next_url')
    survey_id = request.form.get('survey_id')

    current_app.logger.debug("next_url(%r)=<%r>, survey_id=<%r>" % (len(next_url), next_url, survey_id))

    if request.form.get('remember_yn') is None:
        remember_me = False
    else:
        remember_me = True

    if not login_validation('login_email', user_id):
        flash(u"Invalid Email or Password.")
        return render_template('login.html', menu_active="login", login_info=get_login_session())

    if not login_validation('login_pw', user_pw):
        flash(u"Invalid Email or Password.")
        return render_template('login.html', menu_active="login", login_info=get_login_session())

    # current_app.logger.debug("user_id=<%r>, user_pw=<%r>, remember_me=<%r>" % (user_id, user_pw, remember_me))

    if certify_user(user_id, user_pw) is False:
        flash(u"Invalid Email or Password.")
        return render_template('login.html', menu_active="login", login_info=get_login_session())
    else:
        certify_info = load_user_info(user_id)
        session['logged_in'] = certify_info

        # current_app.logger.debug("certify_info=<%r>" % certify_info)

    if next_url == 'login.login_form':
        # return render_template('opmw/dashboard.html', menu_active="dashboard", login_info=get_login_session())
        return redirect("/opmw/")
    elif len(next_url) == 0:
        # return render_template('opmw/dashboard.html', menu_active="dashboard", login_info=get_login_session())
        return redirect("/opmw/")
    else:
        if survey_id is None or survey_id == '':
            return redirect(url_for(next_url))
        else:
            if next_url == 'edit_new_task.edit_task':
                return redirect(url_for(next_url, report_id=survey_id))
            else:
                return redirect(url_for(next_url, survey_id=survey_id))
