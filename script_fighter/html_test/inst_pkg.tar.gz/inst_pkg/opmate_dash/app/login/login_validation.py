# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'


from cerberus import Validator


schema = {
    'login_email': {'type': 'string',
                    'regex': '^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$',
                    'minlength': 8,
                    'maxlength': 30},
    'login_pw': {'type': 'string', 'minlength': 8, 'maxlength': 30},
}

v = Validator(schema)


def login_validation(key, value):
    """입력 값 점검.

    :param key:
    :param value:
    :return: True or False
    """
    input_value = dict()
    input_value[key] = value

    return v.validate(input_value)
