# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, render_template, current_app

manual = Blueprint('manual', __name__, template_folder='manual')


@manual.route('/index', methods=["GET"])
def manual_form():
    current_app.logger.debug("call manual")

    return render_template('html/index.html')
