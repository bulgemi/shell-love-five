# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, render_template, current_app, request, flash, session
# Cellar
from app import get_login_session, login_required

bookmark_new_item = Blueprint('bookmark_new_item', __name__, template_folder='templates')


@bookmark_new_item.route('/bookmark_new_item')
@login_required
def bookmark_new_item_from():
    """
    즐겨찾기 된 신규항목 화면을 로딩한다.
    :return:
    """
    current_app.logger.debug("load bookmark new item.")

    return render_template('bookmark_new_item.html', login_info=get_login_session())
