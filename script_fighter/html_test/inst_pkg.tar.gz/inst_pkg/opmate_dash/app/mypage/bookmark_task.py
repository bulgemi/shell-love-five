# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from os import access, R_OK
import datetime
from flask import Blueprint, render_template, current_app, flash, redirect, url_for, request
from flask_sqlalchemy import Pagination
# Cellar
from app import get_login_session, login_required
from app.tasks.task_validation import task_validation
from app.cellarerror.sqlerror import SqlBaseException
# DAO
from dao.check_bookmark import insert_bookmark_task, delete_bookmark_task
from dao.get_bookmark_task_list import get_bookmark_task_list, get_bookmark_task_list_total_count
from app.tasks.dao.get_comm_cd_val_nm import get_common_code_value
from app.tasks.dao.get_user_name import get_user_name
from app.tasks.dao.get_report_history_worker_count import get_rpt_hist_wrkr_complete_count
from app.tasks.dao.get_report_history_worker_count import get_rpt_hist_wrkr_total_count

bookmark_task = Blueprint('bookmark_task', __name__, template_folder='templates')
add_bookmark_task = Blueprint('add_bookmark_task', __name__, template_folder='templates')
del_bookmark_task = Blueprint('del_bookmark_task', __name__, template_folder='templates')


def convert_datetime_format(datetime_data):
    datetime_temp = datetime.datetime.strptime(datetime_data, '%Y%m%d%H%M%S')
    return datetime_temp.strftime('%Y-%m-%d')


@bookmark_task.route('/bookmark_task', methods=["GET", "POST"])
@login_required
def bookmark_task_from():
    """
    즐겨찾기 된 현황조사 화면을 로딩한다.
    :return:
    """
    current_app.logger.debug("load bookmark task.")
    page = request.form.get('page_num', 1, type=int)
    search_status = request.form.get('search_status')
    search_option = request.form.get('search_option')
    search_word = request.form.get('search_word')
    btn = request.form.get('btn')

    current_app.logger.debug("page=<%r>" % page)
    current_app.logger.debug("search_status=<%r>" % search_status)
    current_app.logger.debug("search_option=<%r>" % search_option)
    current_app.logger.debug("search_word=<%r>" % search_word)
    current_app.logger.debug("btn=<%r>" % btn)

    # 입력값 유효성 체크
    if search_word is not None and search_word != '':
        search_word = search_word.strip()  # 앞/뒤 공백제거

        if not task_validation('search_word', search_word):
            flash(u"검색어가 유효하지 않습니다.")
            return redirect(url_for("my_task.my_task_form"))

    row_map = {
        0: 'RPT_ID',
        1: 'RPT_NM',
        2: 'RPT_CRE_DTM',
        3: 'RPT_UPD_DTM',
        4: 'RPT_DUE_DTM',
        5: 'RPT_STAT_CD',
        6: 'OWNR_ID',
        7: 'RPT_FILE_DIR',
        8: 'RPT_FILE_NM'
    }

    search_condition_map = {
        'search_status': 0,
        'search_option': 1,
        'search_word': 2
    }

    search_status_value_map = {
        'all': '0',
        'save': '1',
        'ongoing': '2',
        'complete': '3',
        'delay': '4',
        'reported': '5'
    }

    search_option_value_map = {
        'all': '0',
        'task_name': '1',
        'rpt_cre_dtm': '2',
        'rpt_upd_dtm': '3',
        'final_writer': '4',
        'reporter': '5',
        'me': '6'
    }

    row_list = list()
    contents = dict()

    if search_status != '' and search_status is not None:
        contents['search_status'] = search_status

    if search_option != '' and search_option is not None:
        contents['search_option'] = search_option

    if search_word != '' and search_word is not None:
        contents['search_word'] = search_word

    per_page = 10

    search_condition = dict()

    try:
        if btn == 'search' and (search_status != 'all' or search_option != 'all' or search_word != ''):
            search_condition[search_condition_map['search_status']] = search_status
            search_condition[search_condition_map['search_option']] = search_option
            search_condition[search_condition_map['search_word']] = search_word
            search_condition['map'] = search_condition_map
            search_condition['option_1'] = search_status_value_map
            search_condition['option_2'] = search_option_value_map

            result = get_bookmark_task_list(search_condition, page, per_page)
            total_count = get_bookmark_task_list_total_count(search_condition)
            pagination = Pagination(query=None, page=page, per_page=per_page, total=total_count[0], items=result)
        else:
            result = get_bookmark_task_list(None, page, per_page)
            total_count = get_bookmark_task_list_total_count(None)
            pagination = Pagination(query=None, page=page, per_page=per_page, total=total_count[0], items=result)

    except SqlBaseException:
        flash(u"조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"조회 중 오류가 발생했습니다.")

    today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

    # html 렌더링이 쉽게 데이터 가공
    for row in result:
        row_contents = dict()

        for index, data in enumerate(row):
            row_contents[row_map[index]] = data.encode('utf-8')

        due_date = datetime.datetime.strptime(row_contents['RPT_DUE_DTM'], '%Y%m%d%H%M%S')

        # current_app.logger.error(u"today(%r)=<%r>, due_date(%r)=<%r>"
        #                          % (type(today), today, type(due_date), due_date))

        if today > due_date and row_contents['RPT_STAT_CD'] != 'RPT_S_0003':
            row_contents['RPT_STAT'] = u'{0}[지연]'.format(get_common_code_value(row_contents['RPT_STAT_CD']))
        else:
            row_contents['RPT_STAT'] = get_common_code_value(row_contents['RPT_STAT_CD'])

        row_contents['REPORTER'] = get_user_name(row_contents['OWNR_ID']).encode('utf-8')
        row_contents['RPT_CRE_DTM'] = convert_datetime_format(row_contents['RPT_CRE_DTM'])
        row_contents['RPT_UPD_DTM'] = convert_datetime_format(row_contents['RPT_UPD_DTM'])
        row_contents['RPT_DUE_DTM'] = convert_datetime_format(row_contents['RPT_DUE_DTM'])
        row_contents['TOTAL'] = get_rpt_hist_wrkr_total_count(row_contents['RPT_ID'])
        row_contents['COMPLETE'] = get_rpt_hist_wrkr_complete_count(row_contents['RPT_ID'])
        # download link 생석, 존재하면 File Path, 없으면 None
        full_path = current_app.config['EXCEL_EXPORT_HOME'] + "/" + \
                    row_contents['RPT_FILE_DIR'] + '/' + \
                    row_contents['RPT_FILE_NM']

        if access(full_path, R_OK) is True:
            row_contents['DOWNLOAD'] = full_path
        else:
            row_contents['DOWNLOAD'] = None

        row_list.append(row_contents)

    current_app.logger.debug("row_list=<%r>" % row_list)

    contents['row'] = row_list

    return render_template('bookmark_task.html', login_info=get_login_session(),
                           contents=contents, pagination=pagination)


@add_bookmark_task.route('/add_bookmark_task/<report_id>', methods=["GET"])
@login_required
def add_bookmark_task_from(report_id):
    """
    현황조사 즐겨찾기 추가.
    :return:
    """
    current_app.logger.debug("add bookmark task=<%r>" % report_id)

    if insert_bookmark_task(report_id) is False:
        flash(u'즐겨찾기 추가 실패하였습니다.')

        return redirect(url_for("task_list.list_view"))

    flash(u'즐겨찾기 추가하였습니다.')

    return redirect(url_for("bookmark_task.bookmark_task_from"))


@del_bookmark_task.route('/del_bookmark_task/<report_id>', methods=["GET"])
@login_required
def del_bookmark_task_from(report_id):
    """
    현황조사 즐겨찾기 삭제.
    :return:
    """
    current_app.logger.debug("del bookmark task=<%r>" % report_id)

    if delete_bookmark_task(report_id) is False:
        flash(u'즐겨찾기 삭제 실패하였습니다.')

        return redirect(url_for("task_list.list_view"))

    flash(u'즐겨찾기 삭제하였습니다.')

    return redirect(url_for("bookmark_task.bookmark_task_from"))
