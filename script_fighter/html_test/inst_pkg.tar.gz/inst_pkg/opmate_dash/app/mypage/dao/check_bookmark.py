# _*_ coding: utf-8 _*_

from flask import g, current_app, flash
from app import db
from sqlalchemy import and_
# Cellar
from app import get_login_session_info
# DAO
from app.models import CellarUserBookMark
from app.models import GeneralSurveyBookMark


def insert_bookmark_task(report_id):
    # Insert Data to CELLAR_USER_BOOK_MARK
    bookmark_info = CellarUserBookMark()

    bookmark_cnt = CellarUserBookMark.query\
        .filter(CellarUserBookMark.USR_ID == get_login_session_info('USR_ID'))\
        .count()

    bookmark_info.USR_ID = get_login_session_info('USR_ID')
    bookmark_info.BOOK_MARK_SEQ = bookmark_cnt + 1
    bookmark_info.RPT_ID = report_id

    try:
        db.session.add(bookmark_info)  # insert

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False
    return True


def insert_bookmark_general_survey(survey_id):
    # Insert Data to GENERAL_SURVEY_MARK
    bookmark_info = GeneralSurveyBookMark()

    bookmark_cnt = GeneralSurveyBookMark.query\
        .filter(GeneralSurveyBookMark.USR_ID == get_login_session_info('USR_ID'))\
        .count()

    bookmark_info.USR_ID = get_login_session_info('USR_ID')
    bookmark_info.BOOK_MARK_SEQ = bookmark_cnt + 1
    bookmark_info.SURVEY_ID = survey_id

    try:
        db.session.add(bookmark_info)  # insert

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False
    return True


def delete_bookmark_task(report_id):
    # Delete Data to CELLAR_USER_BOOK_MARK
    try:
        CellarUserBookMark.query\
            .filter(and_(CellarUserBookMark.USR_ID == get_login_session_info('USR_ID'),
                         CellarUserBookMark.RPT_ID == report_id))\
            .delete()

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False
    return True


def delete_bookmark_general_survey(survey_id):
    # Delete Data to GENERAL_SURVEY_BOOK_MARK
    try:
        GeneralSurveyBookMark.query\
            .filter(and_(GeneralSurveyBookMark.USR_ID == get_login_session_info('USR_ID'),
                         GeneralSurveyBookMark.SURVEY_ID == survey_id))\
            .delete()

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False
    return True


def check_bookmark_task(report_id):
    # Check Data to CELLAR_USER_BOOK_MARK
    bookmark_cnt = CellarUserBookMark.query \
        .filter(and_(CellarUserBookMark.USR_ID == get_login_session_info('USR_ID'),
                     CellarUserBookMark.RPT_ID == report_id)) \
        .count()

    if bookmark_cnt > 0:
        return True
    else:
        return False


def check_bookmark_general_survey(survey_id):
    # Check Data to GENERAL_SURVEY_BOOK_MARK
    bookmark_cnt = GeneralSurveyBookMark.query \
        .filter(and_(GeneralSurveyBookMark.USR_ID == get_login_session_info('USR_ID'),
                     GeneralSurveyBookMark.SURVEY_ID == survey_id)) \
        .count()

    if bookmark_cnt > 0:
        return True
    else:
        return False
