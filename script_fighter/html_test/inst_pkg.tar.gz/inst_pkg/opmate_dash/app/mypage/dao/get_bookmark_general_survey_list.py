# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import datetime
from flask import current_app
# Cellar Data
from app import db
from app import get_login_session_info
# Cellar DAO
from app.tasks.dao.get_user_id import get_user_id


def get_bookmark_list(search_condition, page, per_page):
    current_app.logger.debug("search_condition=<%r>, page=<%r>, per_page=<%r>"
                             % (search_condition, page, per_page))

    stat_cd_map = {
        '1': 'RPT_S_0000',
        '2': 'RPT_S_0001',
        '3': 'RPT_S_0002',
        '5': 'RPT_S_0003'
    }

    stat_cd = '1'
    search_mode = '--'
    search_word = '%'

    if search_condition is not None:
        search_map = search_condition['map']

        option_1 = search_condition['option_1']
        option_2 = search_condition['option_2']

        search_mode = option_1[search_condition[search_map['search_status']]] +\
                      option_2[search_condition[search_map['search_option']]]

        stat_cd = option_1[search_condition[search_map['search_status']]]

        if search_condition[search_map['search_word']] != '':
            if option_2[search_condition[search_map['search_option']]] == '2' or\
                    option_2[search_condition[search_map['search_option']]] == '3':  # 일자 비교
                search_word = search_condition[search_map['search_word']].encode('utf-8') + '%'
                search_word = search_word.replace("-", "")  # '-' 제거
                search_word = search_word.replace(":", "")  # ':' 제거
            elif option_2[search_condition[search_map['search_option']]] == '5' or\
                    option_2[search_condition[search_map['search_option']]] == '4':
                search_word = get_user_id(search_condition[search_map['search_word']].encode('utf-8')).encode('utf-8')
            else:
                search_word = '%' + search_condition[search_map['search_word']].encode('utf-8') + '%'

    current_app.logger.debug("search_mode=<%r>" % search_mode)
    current_app.logger.debug("search_word=<%r>" % search_word)

    session = db.session

    temp_query = list()

    temp_query.append(""" SELECT """)
    temp_query.append("""  r.SURVEY_ID AS SURVEY_ID, """)
    temp_query.append("""  r.SURVEY_NM AS SURVEY_NM, """)
    temp_query.append("""  r.SURVEY_CRE_DTM AS SURVEY_CRE_DTM, """)
    temp_query.append("""  r.SURVEY_UPD_DTM AS SURVEY_UPD_DTM, """)
    temp_query.append("""  r.SURVEY_DUE_DTM AS SURVEY_DUE_DTM, """)
    temp_query.append("""  r.SURVEY_STAT_CD AS SURVEY_STAT_CD, """)
    temp_query.append("""  r.OWNR_ID AS OWNR_ID, """)
    temp_query.append("""  r.SURVEY_FILE_DIR AS SURVEY_FILE_DIR, """)
    temp_query.append("""  r.SURVEY_FILE_NM AS SURVEY_FILE_NM """)
    temp_query.append(""" FROM GENERAL_SURVEY_HIST r, GENERAL_SURVEY_BOOK_MARK c """)
    temp_query.append(""" WHERE r.SURVEY_ID = c.SURVEY_ID """)
    temp_query.append(""" AND c.USR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0005' """)

    if search_mode == '00':  # ALL, ALL
        pass
    elif search_mode == '01':  # ALL, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '02':  # ALL, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '03':  # ALL, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '04':  # ALL, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        pass
    elif search_mode == '05':  # ALL, REPORTER
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '06':  # ALL, ME
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '10':  # SAVE, ALL
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '11':  # SAVE, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '12':  # SAVE, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '13':  # SAVE, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '14':  # SAVE, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '15':  # SAVE, REPORTER
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '16':  # SAVE, ME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '20':  # ONGOING, ALL
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '21':  # ONGOING, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '22':  # ONGOING, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '23':  # ONGOING, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '24':  # ONGOING, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '25':  # ONGOING, REPORTER
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '26':  # ONGOING, ME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '30':  # COMPLETE, ALL
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '31':  # COMPLETE, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '32':  # COMPLETE, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '33':  # COMPLETE, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '34':  # COMPLETE, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '35':  # COMPLETE, REPORTER
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '36':  # COMPLETE, ME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '40':  # DELAY, ALL
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
    elif search_mode == '41':  # DELAY, GENERAL_SURVEY_NAME
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '42':  # DELAY, RPT_CRE_DTM
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '43':  # DELAY, RPT_UPD_DTM
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '44':  # DELAY, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
    elif search_mode == '45':  # DELAY, REPORTER
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '46':  # DELAY, ME
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '50':  # REPORTED, ALL
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '51':  # REPORTED, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '52':  # REPORTED, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '53':  # REPORTED, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '54':  # REPORTED, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '55':  # REPORTED, REPORTER
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '56':  # REPORTED, ME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    else:
        pass

    temp_query.append(""" ORDER BY r.SURVEY_UPD_DTM DESC """)

    if per_page is not None and page is not None:
        temp_query.append(" LIMIT {0}, {1}".format((page - 1) * per_page, per_page))

    query = ''.join(temp_query)

    current_app.logger.debug('query=<%r>' % query)

    statement = session.query(
        'SURVEY_ID',
        'SURVEY_NM',
        'SURVEY_CRE_DTM',
        'SURVEY_UPD_DTM',
        'SURVEY_DUE_DTM',
        'SURVEY_STAT_CD',
        'OWNR_ID',
        'SURVEY_FILE_DIR',
        'SURVEY_FILE_NM'
    ).from_statement(query)

    current_app.logger.debug('statement=<%r>' % str(statement))

    result = statement.all()

    current_app.logger.debug('result=<%r>' % result)

    return result


def get_bookmark_list_total_count(search_condition):
    current_app.logger.debug("search_condition=<%r>" % search_condition)

    stat_cd_map = {
        '1': 'RPT_S_0000',
        '2': 'RPT_S_0001',
        '3': 'RPT_S_0002',
        '5': 'RPT_S_0003'
    }

    stat_cd = '1'
    search_mode = '--'
    search_word = '%'

    if search_condition is not None:
        search_map = search_condition['map']

        option_1 = search_condition['option_1']
        option_2 = search_condition['option_2']

        search_mode = option_1[search_condition[search_map['search_status']]] +\
                      option_2[search_condition[search_map['search_option']]]

        stat_cd = option_1[search_condition[search_map['search_status']]]

        if search_condition[search_map['search_word']] != '':
            if option_2[search_condition[search_map['search_option']]] == '2' or\
                    option_2[search_condition[search_map['search_option']]] == '3':  # 일자 비교
                search_word = search_condition[search_map['search_word']].encode('utf-8') + '%'
                search_word = search_word.replace("-", "")  # '-' 제거
                search_word = search_word.replace(":", "")  # ':' 제거
            elif option_2[search_condition[search_map['search_option']]] == '5' or\
                    option_2[search_condition[search_map['search_option']]] == '4':
                search_word = get_user_id(search_condition[search_map['search_word']].encode('utf-8')).encode('utf-8')
            else:
                search_word = '%' + search_condition[search_map['search_word']].encode('utf-8') + '%'

    current_app.logger.debug("search_mode=<%r>" % search_mode)
    current_app.logger.debug("search_word=<%r>" % search_word)

    session = db.session

    temp_query = list()

    temp_query.append(""" SELECT """)
    temp_query.append("""  COUNT(r.SURVEY_ID) AS TOTAL_COUNT """)
    temp_query.append(""" FROM GENERAL_SURVEY_HIST r, GENERAL_SURVEY_BOOK_MARK c """)
    temp_query.append(""" WHERE r.SURVEY_ID = c.SURVEY_ID """)
    temp_query.append(""" AND c.USR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0005' """)

    if search_mode == '00':  # ALL, ALL
        pass
    elif search_mode == '01':  # ALL, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '02':  # ALL, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '03':  # ALL, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '04':  # ALL, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        pass
    elif search_mode == '05':  # ALL, REPORTER
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '06':  # ALL, ME
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '10':  # SAVE, ALL
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '11':  # SAVE, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '12':  # SAVE, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '13':  # SAVE, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '14':  # SAVE, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '15':  # SAVE, REPORTER
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '16':  # SAVE, ME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '20':  # ONGOING, ALL
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '21':  # ONGOING, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '22':  # ONGOING, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '23':  # ONGOING, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '24':  # ONGOING, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '25':  # ONGOING, REPORTER
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '26':  # ONGOING, ME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '30':  # COMPLETE, ALL
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '31':  # COMPLETE, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '32':  # COMPLETE, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '33':  # COMPLETE, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '34':  # COMPLETE, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '35':  # COMPLETE, REPORTER
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '36':  # COMPLETE, ME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '40':  # DELAY, ALL
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
    elif search_mode == '41':  # DELAY, GENERAL_SURVEY_NAME
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '42':  # DELAY, RPT_CRE_DTM
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '43':  # DELAY, RPT_UPD_DTM
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '44':  # DELAY, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
    elif search_mode == '45':  # DELAY, REPORTER
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '46':  # DELAY, ME
        today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

        temp_query.append(""" AND r.SURVEY_STAT_CD != 'RPT_S_0003' """)
        temp_query.append(""" AND r.SURVEY_DUE_DTM < {} """.format(today))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    elif search_mode == '50':  # REPORTED, ALL
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '51':  # REPORTED, GENERAL_SURVEY_NAME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '52':  # REPORTED, RPT_CRE_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '53':  # REPORTED, RPT_UPD_DTM
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.SURVEY_UPD_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '54':  # REPORTED, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
    elif search_mode == '55':  # REPORTED, REPORTER
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(search_word))
    elif search_mode == '56':  # REPORTED, ME
        temp_query.append(""" AND r.SURVEY_STAT_CD = '{}' """.format(stat_cd_map[stat_cd]))
        temp_query.append(""" AND r.OWNR_ID = '{}' """.format(get_login_session_info('USR_ID')))
    else:
        pass

    temp_query.append(""" ORDER BY r.SURVEY_UPD_DTM DESC """)

    query = ''.join(temp_query)

    current_app.logger.debug('query=<%r>' % query)

    statement = session.query(
        'TOTAL_COUNT'
    ).from_statement(query)

    current_app.logger.debug('statement=<%r>' % str(statement))

    result = statement.first()

    current_app.logger.debug('result=<%r>' % result)

    return result
