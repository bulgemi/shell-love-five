# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import datetime
from flask import current_app
from sqlalchemy import and_, or_
# Cellar
from app import get_login_session_info
from app.cellarerror.sqlerror import SqlBaseException
from app.models import GeneralSurveyHist
# Cellar DAO
from app.tasks.dao.get_user_id import get_user_id


def get_list(search_condition, page, per_page):
    """
    검색 조건에 맞는 현황조사 리스트 항목 조회
    :param search_condition:
    :param page:
    :param per_page:
    :return:
    """
    current_app.logger.debug("search_condition=<%r>, page=<%r>, per_page=<%r>"
                             % (search_condition, page, per_page))

    stat_cd_map = {
        '1': 'RPT_S_0000',
        '2': 'RPT_S_0001',
        '3': 'RPT_S_0002',
        '5': 'RPT_S_0003'
    }

    stat_cd = '1'
    search_mode = '--'
    search_word = '%'

    if search_condition is not None:
        search_map = search_condition['map']

        option_1 = search_condition['option_1']
        option_2 = search_condition['option_2']

        search_mode = option_1[search_condition[search_map['search_status']]] +\
                      option_2[search_condition[search_map['search_option']]]

        stat_cd = option_1[search_condition[search_map['search_status']]]

        if search_condition[search_map['search_word']] != '':
            if option_2[search_condition[search_map['search_option']]] == '2' or\
                    option_2[search_condition[search_map['search_option']]] == '3':  # 일자 비교
                search_word = search_condition[search_map['search_word']].encode('utf-8') + '%'
                search_word = search_word.replace("-", "")  # '-' 제거
                search_word = search_word.replace(":", "")  # ':' 제거
            elif option_2[search_condition[search_map['search_option']]] == '5' or\
                    option_2[search_condition[search_map['search_option']]] == '4':
                search_word = get_user_id(search_condition[search_map['search_word']].encode('utf-8')).encode('utf-8')
            else:
                search_word = '%' + search_condition[search_map['search_word']].encode('utf-8') + '%'

    current_app.logger.debug("search_mode=<%r>" % search_mode)
    current_app.logger.debug("search_word=<%r>" % search_word)

    try:
        stmt = GeneralSurveyHist.query.with_entities(
            GeneralSurveyHist.SURVEY_ID, GeneralSurveyHist.SURVEY_NM,
            GeneralSurveyHist.SURVEY_CRE_DTM, GeneralSurveyHist.SURVEY_UPD_DTM,
            GeneralSurveyHist.SURVEY_DUE_DTM, GeneralSurveyHist.SURVEY_STAT_CD,
            GeneralSurveyHist.OWNR_ID, GeneralSurveyHist.SURVEY_FILE_DIR,
            GeneralSurveyHist.SURVEY_FILE_NM
            )\
            .filter(and_(GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0005',
                         GeneralSurveyHist.OWNR_ID == get_login_session_info('USR_ID')))

        if search_mode == '00':  # ALL, ALL
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_NM.like(search_word))
        elif search_mode == '01':  # ALL, SURVEY_NAME
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_NM.like(search_word))
        elif search_mode == '02':  # ALL, SURVEY_CRE_DTM
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_CRE_DTM.like(search_word))
        elif search_mode == '03':  # ALL, SURVEY_UPD_DTM
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_UPD_DTM.like(search_word))
        elif search_mode == '04':  # ALL, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
            pass
        elif search_mode == '05':  # ALL, REPORTER
            stmt = stmt.filter(GeneralSurveyHist.OWNR_ID == search_word)
        elif search_mode == '06':  # ALL, ME
            stmt = stmt.filter(GeneralSurveyHist.OWNR_ID == get_login_session_info('USR_ID'))
        elif search_mode == '10':  # SAVE, ALL
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd])
        elif search_mode == '11':  # SAVE, SURVEY_NAME
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_NM.like(search_word)))
        elif search_mode == '12':  # SAVE, SURVEY_CRE_DTM
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_CRE_DTM.like(search_word)))
        elif search_mode == '13':  # SAVE, SURVEY_UPD_DTM
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_UPD_DTM.like(search_word)))
        elif search_mode == '14':  # SAVE, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd])
        elif search_mode == '15':  # SAVE, REPORTER
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.OWNR_ID == search_word))
        elif search_mode == '16':  # SAVE, ME
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.OWNR_ID == get_login_session_info('USR_ID')))
        elif search_mode == '20':  # ONGOING, ALL
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd])
        elif search_mode == '21':  # ONGOING, SURVEY_NAME
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_NM.like(search_word)))
        elif search_mode == '22':  # ONGOING, SURVEY_CRE_DTM
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_CRE_DTM.like(search_word)))
        elif search_mode == '23':  # ONGOING, SURVEY_UPD_DTM
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_UPD_DTM.like(search_word)))
        elif search_mode == '24':  # ONGOING, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd])
        elif search_mode == '25':  # ONGOING, REPORTER
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.OWNR_ID == search_word))
        elif search_mode == '26':  # ONGOING, ME
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.OWNR_ID == get_login_session_info('USR_ID')))
        elif search_mode == '30':  # COMPLETE, ALL
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd])
        elif search_mode == '31':  # COMPLETE, SURVEY_NAME
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_NM.like(search_word)))
        elif search_mode == '32':  # COMPLETE, SURVEY_CRE_DTM
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_CRE_DTM.like(search_word)))
        elif search_mode == '33':  # COMPLETE, SURVEY_UPD_DTM
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_UPD_DTM.like(search_word)))
        elif search_mode == '34':  # COMPLETE, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd])
        elif search_mode == '35':  # COMPLETE, REPORTER
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.OWNR_ID == search_word))
        elif search_mode == '36':  # COMPLETE, ME
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.OWNR_ID == get_login_session_info('USR_ID')))
        elif search_mode == '40':  # DELAY, ALL
            today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0003',
                                    GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0005',
                                    GeneralSurveyHist.SURVEY_DUE_DTM < today))
        elif search_mode == '41':  # DELAY, SURVEY_NAME
            today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0003',
                                    GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0005',
                                    GeneralSurveyHist.SURVEY_DUE_DTM < today,
                                    GeneralSurveyHist.SURVEY_NM.like(search_word)))
        elif search_mode == '42':  # DELAY, SURVEY_CRE_DTM
            today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0003',
                                    GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0005',
                                    GeneralSurveyHist.SURVEY_DUE_DTM < today,
                                    GeneralSurveyHist.SURVEY_CRE_DTM.like(search_word)))
        elif search_mode == '43':  # DELAY, SURVEY_UPD_DTM
            today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0003',
                                    GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0005',
                                    GeneralSurveyHist.SURVEY_DUE_DTM < today,
                                    GeneralSurveyHist.SURVEY_UPD_DTM.like(search_word)))
        elif search_mode == '44':  # DELAY, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
            today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0003',
                                    GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0005',
                                    GeneralSurveyHist.SURVEY_DUE_DTM < today))
        elif search_mode == '45':  # DELAY, REPORTER
            today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0003',
                                    GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0005',
                                    GeneralSurveyHist.SURVEY_DUE_DTM < today,
                                    GeneralSurveyHist.OWNR_ID == search_word))
        elif search_mode == '46':  # DELAY, ME
            today = datetime.datetime.strptime(datetime.datetime.now().strftime('%Y%m%d%H%M%S'), '%Y%m%d%H%M%S')

            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0003',
                                    GeneralSurveyHist.SURVEY_STAT_CD != 'RPT_S_0005',
                                    GeneralSurveyHist.SURVEY_DUE_DTM < today,
                                    GeneralSurveyHist.OWNR_ID == get_login_session_info('USR_ID')))
        elif search_mode == '50':  # REPORTED, ALL
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd])
        elif search_mode == '51':  # REPORTED, SURVEY_NAME
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_NM.like(search_word)))
        elif search_mode == '52':  # REPORTED, SURVEY_CRE_DTM
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_CRE_DTM.like(search_word)))
        elif search_mode == '53':  # REPORTED, SURVEY_UPD_DTM
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.SURVEY_UPD_DTM.like(search_word)))
        elif search_mode == '54':  # REPORTED, FINAL_WRITER, Todo: 최종수정자 처리. 2017.12.29. kim dong-hun
            stmt = stmt.filter(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd])
        elif search_mode == '55':  # REPORTED, REPORTER
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.OWNR_ID == search_word))
        elif search_mode == '56':  # REPORTED, ME
            stmt = stmt.filter(and_(GeneralSurveyHist.SURVEY_STAT_CD == stat_cd_map[stat_cd],
                                    GeneralSurveyHist.OWNR_ID == get_login_session_info('USR_ID')))
        else:
            pass

        stmt = stmt.order_by(GeneralSurveyHist.SURVEY_UPD_DTM.desc())

        current_app.logger.debug("stmt=<%r>" % str(stmt))

        pagination = stmt.paginate(page, per_page=per_page, error_out=False)

        current_app.logger.debug("pagination=<%r>" % pagination.items)

    except Exception as e:
        raise SqlBaseException(e)

    return pagination

