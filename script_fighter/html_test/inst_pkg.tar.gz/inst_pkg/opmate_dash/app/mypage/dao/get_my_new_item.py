# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app
# Cellar Data
from app import db
from app import get_login_session_info


def get_my_new_item(search_condition, page, per_page):
    current_app.logger.debug("search_condition=<%r>, page=<%r>, per_page=<%r>"
                             % (search_condition, page, per_page))

    type_cd = '1'
    search_mode = '--'
    search_word = '%'

    if search_condition is not None:
        search_map = search_condition['map']

        option_1 = search_condition['option_1']
        option_2 = search_condition['option_2']

        search_mode = option_1[search_condition[search_map['search_type']]] +\
                      option_2[search_condition[search_map['search_option']]]

        type_cd = option_1[search_condition[search_map['search_type']]]

        if search_condition[search_map['search_word']] != '':
            if option_2[search_condition[search_map['search_option']]] == '2':  # 날자
                search_word = search_condition[search_map['search_word']].encode('utf-8') + '%'
                search_word = search_word.replace("-", "")  # '-' 제거
                search_word = search_word.replace(":", "")  # ':' 제거
            else:
                search_word = '%' + search_condition[search_map['search_word']].encode('utf-8') + '%'

    current_app.logger.debug("search_mode=<%r>" % search_mode)
    current_app.logger.debug("search_word=<%r>" % search_word)

    session = db.session

    temp_query = list()

    temp_query.append(""" SELECT """)
    temp_query.append("""  udi.ITM_ID AS ITM_ID, """)
    temp_query.append("""  im.ITM_NM AS ITM_NM, """)
    temp_query.append("""  ( """)
    temp_query.append("""    SELECT """)
    temp_query.append("""     COMM_CD_VAL_NM """)
    temp_query.append("""    FROM COMM_CD_DTL """)
    temp_query.append("""    WHERE COMM_CD_ID = '0000000005' """)
    temp_query.append("""    AND COMM_CD_VAL = udi.ITM_TYP_CL_CD """)
    temp_query.append("""  ) AS ITM_TYP_CL_CD_NM, """)
    temp_query.append("""  ( """)
    temp_query.append("""    SELECT """)
    temp_query.append("""     USR_NM """)
    temp_query.append("""    FROM CELLAR_USER """)
    temp_query.append("""    WHERE USR_ID = udi.CRE_USR """)
    temp_query.append("""  ) AS CRE_USR_NM, """)
    temp_query.append("""  ( """)
    temp_query.append("""    SELECT """)
    temp_query.append("""     USR_NM """)
    temp_query.append("""    FROM CELLAR_USER """)
    temp_query.append("""    WHERE USR_ID = udi.UPD_USR """)
    temp_query.append("""  ) AS UPD_USR_NM, """)
    temp_query.append("""  udi.CRE_DTM AS CRE_DTM, """)
    temp_query.append("""  udi.UPD_DTM AS UPD_DTM """)
    temp_query.append(""" FROM USR_DEF_ITM udi, ITM_MGMT im """)
    temp_query.append(""" WHERE udi.ITM_ID = im.ITM_ID """)
    temp_query.append(""" AND udi.CRE_USR = '{}' """.format(get_login_session_info('USR_ID')))
    temp_query.append(""" AND im.ITM_STAT_CD != 'ITM_S_0001' """)

    if search_mode == '00':  # ALL, ALL
        pass
    elif search_mode == '01':  # ALL, ITM_NM
        temp_query.append(""" AND im.ITM_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '02':  # ALL, CRE_DTM
        temp_query.append(""" AND udi.CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '10':  # SELECT_BOX, ALL
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0001' """)
    elif search_mode == '11':  # SELECT_BOX, ITM_NM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0001' """)
        temp_query.append(""" AND im.ITM_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '12':  # SELECT_BOX, CRE_DTM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0001' """)
        temp_query.append(""" AND udi.CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '20':  # INPUT_BOX, ALL
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0000' """)
    elif search_mode == '21':  # INPUT_BOX, ITM_NM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0000' """)
        temp_query.append(""" AND im.ITM_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '22':  # INPUT_BOX, CRE_DTM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0000' """)
        temp_query.append(""" AND udi.CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '30':  # CALENDAR_YYYYMMDD, ALL
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0002' """)
    elif search_mode == '31':  # CALENDAR_YYYYMMDD, ITM_NM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0002' """)
        temp_query.append(""" AND im.ITM_NM like '%{}%' """.format(search_word))
    elif search_mode == '32':  # CALENDAR_YYYYMMDD, CRE_DTM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0002' """)
        temp_query.append(""" AND udi.CRE_DTM LIKE '%{}%' """.format(search_word))

    temp_query.append(""" ORDER BY udi.CRE_DTM DESC """)

    if per_page is not None and page is not None:
        temp_query.append(" LIMIT {0}, {1}".format((page - 1) * per_page, per_page))

    query = ''.join(temp_query)

    current_app.logger.debug('query=<%r>' % query)

    statement = session.query(
        'ITM_ID',
        'ITM_NM',
        'ITM_TYP_CL_CD_NM',
        'CRE_USR_NM',
        'UPD_USR_NM',
        'CRE_DTM',
        'UPD_DTM'
    ).from_statement(query)

    current_app.logger.debug('statement=<%r>' % str(statement))

    result = statement.all()

    current_app.logger.debug('result=<%r>' % result)

    return result


def get_my_new_item_total_count(search_condition):
    current_app.logger.debug("search_condition=<%r>" % search_condition)

    type_cd = '1'
    search_mode = '--'
    search_word = '%'

    if search_condition is not None:
        search_map = search_condition['map']

        option_1 = search_condition['option_1']
        option_2 = search_condition['option_2']

        search_mode = option_1[search_condition[search_map['search_type']]] +\
                      option_2[search_condition[search_map['search_option']]]

        type_cd = option_1[search_condition[search_map['search_type']]]

        if search_condition[search_map['search_word']] != '':
            if option_2[search_condition[search_map['search_option']]] == '2':  # 날자
                search_word = search_condition[search_map['search_word']].encode('utf-8') + '%'
                search_word = search_word.replace("-", "")  # '-' 제거
                search_word = search_word.replace(":", "")  # ':' 제거
            else:
                search_word = '%' + search_condition[search_map['search_word']].encode('utf-8') + '%'

    current_app.logger.debug("search_mode=<%r>" % search_mode)
    current_app.logger.debug("search_word=<%r>" % search_word)

    session = db.session

    temp_query = list()

    temp_query.append(""" SELECT """)
    temp_query.append("""  count(udi.ITM_ID) AS TOTAL_COUNT """)
    temp_query.append(""" FROM USR_DEF_ITM udi, ITM_MGMT im """)
    temp_query.append(""" WHERE udi.ITM_ID = im.ITM_ID """)
    temp_query.append(""" AND udi.CRE_USR = '{}' """.format(get_login_session_info('USR_ID')))
    temp_query.append(""" AND im.ITM_STAT_CD != 'ITM_S_0001' """)

    if search_mode == '00':  # ALL, ALL
        pass
    elif search_mode == '01':  # ALL, ITM_NM
        temp_query.append(""" AND im.ITM_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '02':  # ALL, CRE_DTM
        temp_query.append(""" AND udi.CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '10':  # SELECT_BOX, ALL
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0001' """)
    elif search_mode == '11':  # SELECT_BOX, ITM_NM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0001' """)
        temp_query.append(""" AND im.ITM_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '12':  # SELECT_BOX, CRE_DTM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0001' """)
        temp_query.append(""" AND udi.CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '20':  # INPUT_BOX, ALL
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0000' """)
    elif search_mode == '21':  # INPUT_BOX, ITM_NM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0000' """)
        temp_query.append(""" AND im.ITM_NM LIKE '%{}%' """.format(search_word))
    elif search_mode == '22':  # INPUT_BOX, CRE_DTM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0000' """)
        temp_query.append(""" AND udi.CRE_DTM LIKE '%{}%' """.format(search_word))
    elif search_mode == '30':  # CALENDAR_YYYYMMDD, ALL
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0002' """)
    elif search_mode == '31':  # CALENDAR_YYYYMMDD, ITM_NM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0002' """)
        temp_query.append(""" AND im.ITM_NM like '%{}%' """.format(search_word))
    elif search_mode == '32':  # CALENDAR_YYYYMMDD, CRE_DTM
        temp_query.append(""" AND udi.ITM_TYP_CL_CD = 'TYP_D_0002' """)
        temp_query.append(""" AND udi.CRE_DTM LIKE '%{}%' """.format(search_word))

    temp_query.append(""" ORDER BY udi.CRE_DTM DESC """)

    query = ''.join(temp_query)

    current_app.logger.debug('query=<%r>' % query)

    statement = session.query(
        'TOTAL_COUNT'
    ).from_statement(query)

    current_app.logger.debug('statement=<%r>' % str(statement))

    result = statement.first()

    current_app.logger.debug('result=<%r>' % result)

    return result
