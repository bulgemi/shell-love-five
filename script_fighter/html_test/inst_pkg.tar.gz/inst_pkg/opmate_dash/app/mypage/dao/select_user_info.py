# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app, flash
# Cellar
from app.models import CellarUser


def get_detail(user_id):
    """
    사용자 정보[메모] 조회.
    :param user_id:
    :return result:
    """
    # current_app.logger.debug("user_id=<%r>" % user_id)

    try:
        stmt = CellarUser.query.with_entities(CellarUser.MEMO)
        stmt = stmt.filter(CellarUser.USR_ID == user_id.strip())
        result = stmt.first()

        return result
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None
