# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app
# Cellar Data
from app import db
from app import get_login_session_info
from app.models import CellarUser


def update_memo(memo):
    """
    메모를 변경한다.
    :param memo:
    :return:
    """
    try:
        user_info = CellarUser.query\
            .filter(CellarUser.USR_ID == get_login_session_info('USR_ID'))\
            .first()

        user_info.MEMO = memo

        current_app.logger.debug("user_info=<%r>" % user_info)

        db.session.commit()
    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()
        return False

    return True
