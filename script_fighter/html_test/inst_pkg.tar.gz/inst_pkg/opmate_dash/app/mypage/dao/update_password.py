# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import current_app
# Cellar Data
from app import db
from app import get_login_session_info
from app.models import CellarUser
from app.cipher.crypto_util import AESCipher


def check_password(current_pw):
    """
    비밀번호를 체크한다.
    :param current_pw:
    :return:
    """
    result = None
    aes = AESCipher()

    try:
        result = CellarUser.query.with_entities(CellarUser.USR_PW)\
            .filter(CellarUser.USR_ID == get_login_session_info('USR_ID'))\
            .first()

        current_app.logger.debug("result=<%r>" % result)

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]" % (e.args, e.message))
        return False

    if aes.decrypt(result[0]) == current_pw:
        return True
    else:
        return False


def update_password(new_pw):
    """
    비밀번호를 변경한다.
    :param new_pw:
    :return:
    """
    aes = AESCipher()

    try:
        user_info = CellarUser.query\
            .filter(CellarUser.USR_ID == get_login_session_info('USR_ID'))\
            .first()

        user_info.USR_PW = aes.encrypt(new_pw)

        current_app.logger.debug("user_info=<%r>" % user_info)

        db.session.commit()
    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()
        return False

    return True
