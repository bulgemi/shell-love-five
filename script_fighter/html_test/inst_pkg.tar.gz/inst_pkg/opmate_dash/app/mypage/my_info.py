# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, render_template, current_app, request, flash, session
# Cellar
from app import get_login_session, login_required, get_login_session_info
from mypage_validation import mypage_validation
# DAO
from dao.update_password import check_password, update_password
from dao.select_user_info import get_detail
from dao.update_memo import update_memo

my_info = Blueprint('my_info', __name__, template_folder='templates')
edit_my_info = Blueprint('edit_my_info', __name__, template_folder='templates')


@my_info.route('/popup')
@my_info.route('/my_info/popup')
@my_info.route('/edit_my_info/popup')
def my_info_pop():
    """
    팝업 처리
    :return:
    """
    current_app.logger.debug("load popup form.")

    return render_template("popup.html")


@my_info.route('/my_info', methods=["GET", "POST"])
@login_required
def my_info_from():
    """
    나의 정보 화면을 로딩한다.
    :return:
    """
    current_app.logger.debug("load my info.")

    memo = get_detail(get_login_session_info('USR_ID'))

    contents = dict()
    line_map = ['홈', '나의 정보']
    contents['memo'] = memo[0]

    return render_template('my_info.html', login_info=get_login_session(),
                           contents=contents, line_map=line_map)


@edit_my_info.route('/edit_my_info', methods=["POST"])
@login_required
def edit_my_info_from():
    """
    나의 정보를 수정한다.
    :return:
    """
    current_app.logger.debug("edit my info.")

    current_pw = request.form.get('current_pw')
    new_pw = request.form.get('new_pw')
    confirm_new_pw = request.form.get('confirm_new_pw')
    memo = request.form.get('memo')
    btn = request.form.get('btn')

    contents = dict()
    contents['current_pw'] = current_pw
    contents['new_pw'] = new_pw
    contents['memo'] = memo

    if not mypage_validation('memo', new_pw):
        flash(u"메모는 '최대 25자' 입니다.")
    else:
        update_memo(memo)

    current_app.logger.debug("current_pw=<%r>" % current_pw)

    if current_pw is None or len(current_pw) == 0:
        flash(u"변경 완료되었습니다.")

        return render_template('my_info.html', login_info=get_login_session(), contents=contents)

    if not mypage_validation('password', current_pw):
        flash(u"[Current Password]가 유효하지 않습니다.")
        return render_template('my_info.html', login_info=get_login_session(), contents=contents)

    if check_password(current_pw) is False:
        flash(u"[Current Password]가 유효하지 않습니다.")
        return render_template('my_info.html', login_info=get_login_session(), contents=contents)

    if not mypage_validation('new_password', new_pw):
        flash(u"비밀번호는 '최소 8 자, 최소 하나의 문자, 하나의 숫자 및 하나의 특수 문자' 입니다.")
        return render_template('my_info.html', login_info=get_login_session(), contents=contents)

    if current_pw == new_pw:
        flash(u"[Current Password]와 [New Password]가 동일합니다.")
        return render_template('my_info.html', login_info=get_login_session(), contents=contents)

    if new_pw != confirm_new_pw:
        flash(u"[New Password]와 [Confirm New Password]가 동일하지 않습니다.")
        return render_template('my_info.html', login_info=get_login_session(), contents=contents)

    if update_password(new_pw) is False:
        flash(u"비밀번호 갱신에 실패하였습니다.")
        return render_template('my_info.html', login_info=get_login_session(), contents=contents)

    flash(u"변경 완료되었습니다.")

    return render_template('my_info.html', login_info=get_login_session(), contents=contents)
