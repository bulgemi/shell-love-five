# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import datetime
from flask import Blueprint, render_template, current_app, request, flash, redirect, url_for, session
from flask_sqlalchemy import Pagination
# Cellar
from app.cellarerror.sqlerror import SqlBaseException
from app import get_login_session, login_required
from app.tasks.task_validation import task_validation
# Cellar DAO
from dao.get_my_new_item import get_my_new_item, get_my_new_item_total_count

my_new_item = Blueprint('my_new_item', __name__, template_folder='templates')


def convert_datetime_format(datetime_data):
    datetime_temp = datetime.datetime.strptime(datetime_data, '%Y%m%d%H%M%S')
    return datetime_temp.strftime('%Y-%m-%d')


@my_new_item.route('/my_new_item', methods=["GET", "POST"])
@login_required
def my_new_item_from():
    """
    나의 신규항목 화면을 로딩한다.
    :return:
    """
    page = request.form.get('page_num', 1, type=int)
    search_type = request.form.get('search_type')
    search_option = request.form.get('search_option')
    search_word = request.form.get('search_word')
    btn = request.form.get('btn')

    current_app.logger.debug("page=<%r>" % page)
    current_app.logger.debug("search_type=<%r>" % search_type)
    current_app.logger.debug("search_option=<%r>" % search_option)
    current_app.logger.debug("search_word=<%r>" % search_word)
    current_app.logger.debug("btn=<%r>" % btn)

    # 입력값 유효성 체크
    if search_word is not None and search_word != '':
        search_word = search_word.strip()  # 앞/뒤 공백제거

        if not task_validation('search_word', search_word):
            flash(u"검색어가 유효하지 않습니다.")
            return redirect(url_for("my_new_item.my_new_item_form"))

    row_map = {
        0: 'ITM_ID',
        1: 'ITM_NM',
        2: 'ITM_TYP_CL_CD_NM',
        3: 'CRE_USR_NM',
        4: 'UPD_USR_NM',
        5: 'CRE_DTM',
        6: 'UPD_DTM'
    }

    search_condition_map = {
        'search_type': 0,
        'search_option': 1,
        'search_word': 2
    }

    search_type_value_map = {
        'all': '0',
        'select_box': '1',
        'input_box': '2',
        'calendar_yyyymmdd': '3'
    }

    search_option_value_map = {
        'all': '0',
        'new_item_name': '1',
        'cre_dtm': '2',
    }

    row_list = list()
    contents = dict()

    if search_type != '' and search_type is not None:
        contents['search_type'] = search_type

    if search_option != '' and search_option is not None:
        contents['search_option'] = search_option

    if search_word != '' and search_word is not None:
        contents['search_word'] = search_word

    per_page = 10

    search_condition = dict()

    try:
        if btn == 'search' and (search_type != 'all' or search_option != 'all' or search_word != ''):
            search_condition[search_condition_map['search_type']] = search_type
            search_condition[search_condition_map['search_option']] = search_option
            search_condition[search_condition_map['search_word']] = search_word
            search_condition['map'] = search_condition_map
            search_condition['option_1'] = search_type_value_map
            search_condition['option_2'] = search_option_value_map

            result = get_my_new_item(search_condition, page, per_page)
            total_count = get_my_new_item_total_count(search_condition)

            current_app.logger.debug("total_count(%r)=<%r>" % (type(total_count), total_count))

            pagination = Pagination(query=None, page=page, per_page=per_page, total=total_count[0], items=result)
        else:
            result = get_my_new_item(None, page, per_page)
            total_count = get_my_new_item_total_count(None)

            current_app.logger.debug("total_count(%r)=<%r>" % (type(total_count), total_count))

            pagination = Pagination(query=None, page=page, per_page=per_page, total=total_count[0], items=result)

    except SqlBaseException:
        flash(u"조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"조회 중 오류가 발생했습니다.")

    # html 렌더링이 쉽게 데이터 가공
    for row in result:
        row_contents = dict()

        for index, data in enumerate(row):
            row_contents[row_map[index]] = data.encode('utf-8')

        row_contents['ITM_ID'] = row_contents['ITM_ID']
        row_contents['ITM_NM'] = row_contents['ITM_NM']
        row_contents['ITM_TYP_CL_CD_NM'] = row_contents['ITM_TYP_CL_CD_NM']
        row_contents['CRE_USR_NM'] = row_contents['CRE_USR_NM']
        row_contents['UPD_USR_NM'] = row_contents['UPD_USR_NM']
        row_contents['CRE_DTM'] = convert_datetime_format(row_contents['CRE_DTM'])
        row_contents['UPD_DTM'] = convert_datetime_format(row_contents['UPD_DTM'])

        row_list.append(row_contents)

    current_app.logger.debug("row_list=<%r>" % row_list)

    contents['row'] = row_list

    return render_template('my_new_item.html', login_info=get_login_session(), contents=contents, pagination=pagination)
