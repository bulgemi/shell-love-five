# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'


from cerberus import Validator

# 최소 8 자, 최소 하나의 문자, 하나의 숫자 및 하나의 특수 문자
schema = {
    'password': {
        'type': 'string',
        'minlength': 8,
        'maxlength': 30
    },
    'new_password': {
        'type': 'string',
        'minlength': 8,
        'maxlength': 30,
        'regex': "^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&()_+-=~`])[A-Za-z\d$@$!%*#?&()_+-=~`]{8,}$"
    },
    'memo': {
        'type': 'string',
        'minlength': 0,
        'maxlength': 250
    },
}

v = Validator(schema)


def mypage_validation(key, value):
    """입력 값 점검.

    :param key:
    :param value:
    :return: True or False
    """
    input_value = dict()
    input_value[key] = value

    return v.validate(input_value)
