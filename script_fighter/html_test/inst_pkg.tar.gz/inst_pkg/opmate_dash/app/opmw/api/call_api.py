# _*_ coding: utf-8 _*_
import requests
import json
import handle_auth_file
from flask import current_app

# disable InsecureRequestWarning
requests.packages.urllib3.disable_warnings()


def opmate_login():
    user_id = str(current_app.config['API_CALL_USER'])
    base_url = str(current_app.config['API_CALL_BASEURL'])
    url = base_url + '/user/' + user_id + '/login'
    password = str(current_app.config['API_CALL_PASSWORD'])
    data = '{"password":\"' +password + '\"' + '}'  # 추후 config로 분리

    # opmate user login API Call
    response = requests.post(url, data=data, verify=False)

    result = json.loads(response.text)
    # current_app.logger.debug("opmate_login result <%r>" % result)
    auth = result['uuid']

    handle_auth_file.write_auth_file(auth)


# 2018.11.21 KYM modified. (remove task_id)
def opmate_task_rerun(instance_no, node_id):
    base_url = str(current_app.config['API_CALL_BASEURL'])
    url = base_url + '/taskinstance/' + str(instance_no) + '/node/' + node_id
    auth = handle_auth_file.read_auth_file()
    params = {'auth': auth}

    response = requests.put(url, params=params, verify=False)
    result = json.loads(response.text)

    # 로그인 정보가 없거나 만료되었을 때
    # if result['resultCode'] == 'EM1999':
    #     if result['resultMsg'] == 'Login timed out. Please log in again.' \
    #             or result['resultMsg'] == 'You are not logged in.':
    #         opmate_login()
    #         rerun_ret, rerun_result = opmate_task_rerun(instance_no, node_id)
    #         if rerun_result['resultCode'] == 'EM1000':
    #             return True, rerun_result
    #         else:
    #             return False, rerun_result
    #     else:
    #         current_app.logger.error(result['resultMsg'])

    # 2019.03.13 로그인 오류체크 수정
    if result['resultCode'] != 'EM1000':
        if result['resultCode'] == 'EM1001':  # 인증오류
            opmate_login()
            rerun_ret, rerun_result = opmate_task_rerun(instance_no, node_id)
            if rerun_result['resultCode'] == 'EM1000':
                return True, rerun_result
            else:
                return False, rerun_result
        else:
            current_app.logger.error(result['resultMsg'])
            return False, result

    # current_app.logger.debug("opmate_task_rerun task_id <%r>" % task_id)
    current_app.logger.debug("opmate_task_rerun instance_no <%r>" % instance_no)
    current_app.logger.debug("opmate_task_rerun node_id <%r>" % node_id)
    # print(result)

    # if result['resultCode'] == 'EM1000':
    #     return True, result
    # else:
    #     return False, result

    return True, result


# 2018.11.21 KYM modified. (remove task_id)
def opmate_task_viewrun(instance_no, node_id):
    base_url = str(current_app.config['API_CALL_BASEURL'])
    url = base_url + '/taskinstance/' + str(instance_no) + '/node/' + node_id
    auth = handle_auth_file.read_auth_file()
    params = {'auth': auth}

    response = requests.get(url, params=params, verify=False)
    result = json.loads(response.text)

    # print(result)

    if result['resultCode'] == 'EM1000':
        return True, result
    else:
        return False, None


def opmate_task_listrun(task_id):
    base_url = str(current_app.config['API_CALL_BASEURL'])
    url = base_url + '/task/' + task_id + '/instance'
    auth = handle_auth_file.read_auth_file()
    params = {'auth': auth, 'limit': 500}

    # opmate task listrun API Call
    response = requests.get(url, params=params, verify=False)
    result = json.loads(response.text)

    # 로그인 정보가 없거나 만료되었을 때
    # if result['resultCode'] == 'EM1999':
    #     if result['resultMsg'] == 'Login timed out. Please log in again.' \
    #             or result['resultMsg'] == 'You are not logged in.':
    #         current_app.logger.debug(result['resultMsg'])
    #         opmate_login()
    #         return opmate_task_listrun(task_id)
    #     else:
    #         current_app.logger.debug(result['resultMsg'])
    #         return result['resultCode'], result['resultMsg']

    # 2019.03.13 로그인 오류체크 수정
    if result['resultCode'] != 'EM1000':
        if result['resultCode'] == 'EM1001':  # 인증오류
            current_app.logger.debug(result['resultMsg'])
            opmate_login()
            return opmate_task_listrun(task_id)
        else:
            current_app.logget.debug(result['resultMsg'])
            return result['resultCode'], result['resultMsg']

    current_app.logger.debug(result)
    return result['resultCode'], result['instanceList']


def opmate_task_viewrunall(task_id):
    base_url = str(current_app.config['API_CALL_BASEURL'])
    f_result_cd, f_result_msg = opmate_task_listrun(task_id)

    if f_result_cd != 'EM1000':
        current_app.logger.error(f_result_msg)
        return False, None

    instance_no = f_result_msg[0]['taskInstanceNo']

    url = base_url + '/taskinstance/' + str(instance_no) + '/node'
    auth = handle_auth_file.read_auth_file()
    params = {'stdoutYn': 'Y', 'stderrYn': 'Y',
              'auth': auth, 'limit': 500}  # 2019.03.12 modified (stdoutyn->stdoutYn, stderryn -> stderrYn)

    # task의 전체 수행결과 조회 API 호출
    response = requests.get(url, params=params, verify=False)
    result = json.loads(response.text)
    # ins_node_list = result['insNodeList']

    # for ins in ins_node_list:
    #     current_app.logger.debug(ins)

    if result['resultCode'] == 'EM1000':
        # return True, ins_node_list
        return True, result
    else:
        return False, None
