# _*_ coding: utf-8 _*_

# flask
from flask import current_app, flash
# Cellar
from app import db


def insert_ondemand_run_hist_data(ondemand_data):
    """
    ONDEMAND_RUN_HIST(OnDemand 수행이력) 테이블 insert 처리

    :param ondemand_data:
    :return:
        True or False
    """
    try:
        db.session.add(ondemand_data)
        db.session.commit()
        db.session.refresh(ondemand_data)

        current_app.logger.debug('return value : %s\n' % ondemand_data)
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()
        return False, None

    return True, ondemand_data
