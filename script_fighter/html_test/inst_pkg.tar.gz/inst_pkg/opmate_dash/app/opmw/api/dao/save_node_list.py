# _*_ coding: utf-8 _*_

from flask import current_app, flash
from app import db
from sqlalchemy import and_

# Cellar
from app.models import OpmwNodeList


def save_node(node_id, agent_guid, agent_ver, os_name, ip, hostname, status, heartbeat_dt, crt_dt):
    """
    Node 데이터[COMM_CD_LST] ROW Save.

    :param node_id:
    :param agent_guid:
    :param agent_ver:
    :param os_name:
    :param ip:
    :param hostname:
    :param status:
    :param heartbeat_dt
    :param crt_dt
    :return:
        True or False
    """
    current_app.logger.debug("node_id=<%r>" % node_id.encode('utf-8'))
    # current_app.logger.debug("cat_nm=<%r>" % cat_nm.encode('utf-8'))
    # current_app.logger.debug("depth=<%r>" % depth)
    # current_app.logger.debug("seq=<%r>" % seq)

    try:
        sel_query = OpmwNodeList.query.filter(OpmwNodeList.NODE_ID == node_id.strip()).first()

        if sel_query is not None:  # update
            sel_query.AGENT_GUID = agent_guid.encode('utf-8')
            sel_query.AGENT_VER = agent_ver.encode('utf-8')
            sel_query.OS_NAME = os_name.encode('utf-8')
            sel_query.IP = ip.encode('utf-8')
            sel_query.HOSTNAME = hostname.encode('utf-8')
            sel_query.STATUS = status.encode('utf-8')
            sel_query.HEARTBEAT_DT = heartbeat_dt.encode('utf-8')
            sel_query.CRT_DT = crt_dt.encode('utf-8')

            db.session.commit()

        else:  # insert
            save_data = OpmwNodeList()

            save_data.NODE_ID = node_id.encode('utf-8')
            save_data.AGENT_GUID = agent_guid.encode('utf-8')
            save_data.AGENT_VER = agent_ver.encode('utf-8')
            save_data.OS_NAME = os_name.encode('utf-8')
            save_data.IP = ip.encode('utf-8')
            save_data.HOSTNAME = hostname.encode('utf-8')
            save_data.STATUS = status.encode('utf-8')
            save_data.HEARTBEAT_DT = heartbeat_dt.encode('utf-8')
            save_data.CRT_DT = crt_dt.encode('utf-8')

            db.session.add(save_data)
            db.session.commit()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()

        return False

    return True
