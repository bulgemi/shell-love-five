# _*_ coding: utf-8 _*_

# flask
from flask import current_app, flash
# Cellar
from app import db
# DAO
from app.models import OpmwOndemandRunHist


#def update_ondemand_run_hist_data(ondemand_no, task_result_no):
def update_ondemand_run_hist_data(ondemand_no):
    """
    ONDEMAND_RUN_HIST(OnDemand 수행이력) 테이블 Update 처리

    :param ondemand_no:
    :param task_result_no:
    :return:0
        True or False
    """
    try:
        result = OpmwOndemandRunHist.query \
            .filter(OpmwOndemandRunHist.ONDEMAND_NO == ondemand_no)\
            .first()

        # result.TASK_RESULT_NO = task_result_no
        result.STATUS = 'C'  # 수행상태 'C'(Complete)로 변경

        # current_app.logger.debug("result.TASK_RESULT_NO=<%r>" % result.TASK_RESULT_NO)
        current_app.logger.debug("result.STATUS=<%r>" % result.STATUS)

        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()
        return False

    return True
