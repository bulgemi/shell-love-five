# _*_ coding: utf-8 _*_
import os
import call_api
from flask import current_app

# 홈디렉토리 경로 얻기
auth_file_dir = os.path.expanduser('~') + '/.opm'
auth_file_name = 'auth'
full_path = auth_file_dir + '/' + auth_file_name


def read_auth_file():
    if not os.path.isfile(full_path):
        call_api.opmate_login()

    # 'with' is safer to open a file
    with open(full_path, 'r') as auth_file:
        data = auth_file.read()
        return data


def write_auth_file(auth):
    if not os.path.isdir(auth_file_dir):
        os.mkdir(auth_file_dir)

    auth_file = open(full_path, 'w')
    auth_file.write(auth)
    auth_file.close()
