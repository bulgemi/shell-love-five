# _*_ coding: utf-8 _*_
import requests
import json
import handle_auth_file
from flask import current_app
from call_api import opmate_login

# disable InsecureRequestWarning
requests.packages.urllib3.disable_warnings()


def opmate_node_list():
    base_url = str(current_app.config['API_CALL_BASEURL'])
    url = base_url + '/node'
    auth = handle_auth_file.read_auth_file()
    params = {'auth': auth, 'limit': 5000}

    response = requests.get(url, params=params, verify=False)
    result = json.loads(response.text)

    if result['resultCode'] != 'EM1000':
        if result['resultCode'] == 'EM1001':  # 인증오류
            opmate_login()
            return opmate_node_list()
        else:
            current_app.logger.error(result['resultMsg'])
            return False, result

    current_app.logger.debug("opmate_node_list result : <%r>" % result)

    return True, result
