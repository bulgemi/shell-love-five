# _*_ coding: utf-8 _*_

from dao.update_ondemand_run_hist import update_ondemand_run_hist_data
from flask import current_app, flash


# def update_ondemand_run_hist(ondemand_no, task_result_no):
def update_ondemand_run_hist(ondemand_no):
    """
    Ondemand 수행이력 수정
    :param ondemand_no:
    :return:
    """

    # result = update_ondemand_run_hist_data(ondemand_no, task_result_no)
    result = update_ondemand_run_hist_data(ondemand_no)

    if result:
        current_app.logger.debug('Update success ^^b')
        return True
    else:
        current_app.logger.debug('Update fail!!!! ㅠㅠ')
        return False
