# _*_ coding: utf-8 _*_

from datetime import datetime
from dao.insert_ondemand_run_hist import insert_ondemand_run_hist_data
from app.models import OpmwOndemandRunHist
from flask import current_app


def save_ondemand_run_hist(instance_no, node_id, runner_id, task_result_no):
    """
    Ondemand 수행이력 저장
    :param instance_no:
    :param node_id:
    :param runner_id:
    :param task_result_no
    :return:
        True or False
        ONDEMAND_NO
    """
    ondemand_run_hist_data = OpmwOndemandRunHist()

    ondemand_run_hist_data.INSTANCE_NO = instance_no
    ondemand_run_hist_data.NODE_ID = node_id
    ondemand_run_hist_data.RUNNER_ID = runner_id
    ondemand_run_hist_data.REQ_DT = datetime.now().strftime("%Y%m%d%H%M%S")
    ondemand_run_hist_data.TASK_RESULT_NO = task_result_no
    ondemand_run_hist_data.STATUS = 'R'  # 최초 Ondemand 수행상태는 R(Running)

    current_app.logger.debug(ondemand_run_hist_data)

    result, return_data = insert_ondemand_run_hist_data(ondemand_run_hist_data)

    if result:
        current_app.logger.debug('Insert success ^^b')
        current_app.logger.debug('return_data=[%d]' % return_data.ONDEMAND_NO)
        return True, return_data.ONDEMAND_NO
    else:
        current_app.logger.error('Insert fail!!!! ㅠㅠ')
        current_app.logger.error('return_data.ONDEMAND_NO=[%s]' % return_data.ONDEMAND_NO)
        return False, None
