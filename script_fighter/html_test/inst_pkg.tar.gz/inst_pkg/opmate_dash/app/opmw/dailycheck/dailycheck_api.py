# _*_ coding: utf-8 _*_
from app.opmw.dao.get_task_run_list import get_result_okyn
from app.opmw.dao.update_task_run_list import update_dailycheck_result_okyn


def check_dailycheck_result_okyn(task_result_no, viewrun_result_list):
    result_okyn = get_result_okyn(task_result_no)

    if result_okyn == 'check':
        return update_dailycheck_result_okyn(task_result_no, 'N', viewrun_result_list)
    else:
        return update_dailycheck_result_okyn(task_result_no, 'Y', viewrun_result_list)

