# _*_ coding: utf-8 _*_

from flask import current_app, Blueprint, request, redirect
from app import login_required
from app.taskqueue import task_opmw_ondemand
from app import get_login_session_info
from dailycheck_render import result_list
from dailycheck_excel import dailycheck_export_excel
from time import sleep
from app.opmw.api import call_api

opmw_dashboard_do = Blueprint('opmw_dashboard_do', __name__, template_folder='templates')


def dailycheck_ondemand():
    """
    On-demand 수행 처리.
    :return:
    """
    instance_no_list = request.form.getlist('instance_no')
    node_id_list = request.form.getlist('node_id')
    task_id_list = request.form.getlist('task_id')
    runner_id = str(get_login_session_info('USR_ID'))


    for idx in range(0, len(instance_no_list)):
        current_app.logger.debug("get_login_session_info <USER_ID:%r>" % (runner_id))
        ret = task_opmw_ondemand.run_job(task_id_list[idx], instance_no_list[idx], node_id_list[idx], runner_id)
        current_app.logger.debug("call run_job queue = <%r><%r><%r><%r><%r>" % (ret,task_id_list[idx], instance_no_list[idx], node_id_list[idx], runner_id))

    sleep(1)
    return redirect("opmw/dailycheck", code=307)

def dailycheck_daily():
    pass


action_rule = {
    'rerun': dailycheck_ondemand,
    'exportexcel': dailycheck_export_excel
}


@opmw_dashboard_do.route('/dashboard/do', methods=["GET", "POST"])
@login_required
def do_dailycheck():
    """
    On-demand 수행 처리.
    :return:
    """
    call_api.opmate_login()
    action = request.form.get('action')
    print("**** action : [%r]" % action)

    return action_rule[action]()
