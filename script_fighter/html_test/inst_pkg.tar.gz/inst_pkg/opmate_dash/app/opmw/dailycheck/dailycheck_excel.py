# _*_ coding: utf-8 _*_

from flask import request, current_app, flash, send_from_directory
from app.opmw.dao import get_task_run_list
from app.cellarerror.sqlerror import SqlBaseException
from app.opmw.dailycheck.dailycheck_search_obj import NewRunListSearch
from excel_generator import generate_excel


def dailycheck_export_excel(send_yn=True):
    """
    '일일점검 결과조회' 정의 처리
    :param send_yn:
    :return:
    """

    search_condition = NewRunListSearch()

    if search_condition.isFormAll(request) is True:
        search_condition.search_mode = "all"
    elif search_condition.form_request_handler(request) is False:
        flash(u"search_condition 조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"search_condition 조회 중 오류가 발생했습니다.")
        return False

    # for Debug
    search_condition.check_validate()
    search_condition.print_console()
    search_condition.print_log()

    try:
        task_run_list = get_task_run_list.get_new_task_run_list(search_condition)
        # current_app.logger.debug("@@@@@@@ task_run_list @@@@@@ : %r" % task_run_list)

        inquiry_data = list()

        for list_item in task_run_list:
            task_run_list_result_dtl = get_task_run_list.get_task_run_list_dtl(list_item['TASK_RESULT_NO'])
            # current_app.logger.debug("@@@@@@@ task_run_list_result_dtl @@@@@@ : %r" % task_run_list_result_dtl)
            for dtl_item in task_run_list_result_dtl:
                # current_app.logger.debug("@@@ dtl_item @@@ : %r" % dtl_item)
                inquiry_data.append({"TASK_RESULT_NO": list_item['TASK_RESULT_NO']
                                   , "INSTANCE_NO": list_item['INSTANCE_NO']
                                   , "NODE_ID": list_item['NODE_ID']
                                   , "EXEC_NO": list_item['EXEC_NO']
                                   , "TASK_ID": list_item['TASK_ID']
                                   , "STATUS": list_item['STATUS']
                                   , "START_DT": list_item['START_DT']
                                   , "END_DT": list_item['END_DT']
                                   , "RUN_RESULT": list_item['RUN_RESULT']
                                   , "TITLE": dtl_item.get('Title')
                                   , "RESULT": dtl_item.get('Result')
                                   , "VALUE": dtl_item.get('Value')
                                   })

        current_app.logger.debug("@@@@ inquiry_data : <%r>" % inquiry_data)

    except SqlBaseException:
        flash(u"일일점검 수행결과 조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"일일점검 수행결과 조회 중 오류가 발생했습니다.")
        return 'FAIL'

    generate_result, excel_dir, excel_name = generate_excel(inquiry_data)

    if generate_result is not True:
        flash(u'엑셀 생성 실패!')
        if send_yn is False:
            return False

    if send_yn is True:
        return send_from_directory(excel_dir, excel_name.encode('utf-8'), as_attachment=True)
    else:
        return True
