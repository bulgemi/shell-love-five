# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, render_template, flash, current_app, request, jsonify
from flask_sqlalchemy import Pagination
from app import get_login_session, login_required
from app.opmw.dao import get_task_run_list, get_tree_node_list
from app.cellarerror.sqlerror import SqlBaseException
from app.opmw.dailycheck.dailycheck_search_obj import NewRunListSearch
from app.taskqueue import task_opmw_ondemand
from app import get_login_session_info
from datetime import datetime, timedelta
# Cellar
import json

# physical 구성도 및 인터페이스 구성도
opmw_dailycheck_history_list = Blueprint('opmw_dailycheck_history_list', __name__, template_folder='templates')


@opmw_dailycheck_history_list.route('/popup')
def dailycheck_history_pop():
    """
    팝업 처리
    :return:
    """
    current_app.logger.debug("load popup form.")

    return render_template("popup.html")


@opmw_dailycheck_history_list.route('/dailycheck_history_dtl_popup', methods=["GET", "POST"])
@login_required
def dailycheck_dtl_popup():
    """
    일일점검 수행 결과목록 상세
    :return:
    """
    result_no = request.args.get('result_no')
    task_id = request.args.get('task_id')
    node_id = request.args.get('node_id')
    runner_id = request.args.get('runner_id')
    status = request.args.get('status')
    result = request.args.get('result')

    current_app.logger.debug("result_no=<%r>, task_id=<%r>, node_id=<%r>, runner_id=<%r>, status=<%r>,  result=<%r>" % (result_no,task_id,node_id,runner_id,status, result))

    try:
        task_run_list_result_dtl = get_task_run_list.get_task_run_list_dtl(result_no)

    except SqlBaseException:
        if(status == "C" or status == "R"):
            flash(u"진행중....")
        else:
            flash(u"일일점검 결과 상세 항목이 존재하지 않습니다.")
            # alert("일일점검 결과 상세 항목이 존재하지 않습니다.")
            current_app.logger.error(u"일일점검 결과 상세 항목이 존재하지 않습니다.")
            return render_template('opmw/dailycheck_history_dtl_popup.html', menu_active="opmw", login_info=get_login_session(),
                                  result_dtl=None, task_id=task_id, node_id=node_id, runner_id=runner_id, status=status, result=result)

    current_app.logger.debug("result_list_dtl=<%r>" % task_run_list_result_dtl)

    return render_template('opmw/dailycheck_history_dtl_popup.html', menu_active="opmw", login_info=get_login_session(),
                           result_dtl=task_run_list_result_dtl, task_id=task_id, node_id=node_id, runner_id=runner_id, status=status, result=result )


@opmw_dailycheck_history_list.route('/dailycheck_history_list', methods=["GET", "POST"])
@login_required
def result_history_list():
    """
    일일점검 이력
    :return:
    # """
    # page = request.form.get('page_num', 1, type=int)
    # per_page = 15
    # pagination = Pagination("", page, per_page, 0, None)
    # def __init__(self, query, page, per_page, total, items):
    line_map = ['홈', '운영자동화현황', '일일점검 결과 이력조회']
    search_condition = NewRunListSearch()

    sel_status_dic = {"C": current_app.config['OPMATE_STATUS_C'],
                      "F": current_app.config['OPMATE_STATUS_F'],
                      "S": current_app.config['OPMATE_STATUS_S'],
                      "R": current_app.config['OPMATE_STATUS_R']}
    sel_result_dic = {"N": "미수행",
                      "F": current_app.config['OPMATE_RESULT_F'],
                      "S": current_app.config['OPMATE_RESULT_S']}
    sel_okyn_dic = {"N": current_app.config['OPMATE_OKYN_N'],
                    "Y": current_app.config['OPMATE_OKYN_Y']}

    if search_condition.isFormAll(request) is True:
        search_condition.search_mode = "all"
    elif search_condition.form_request_handler(request) is False:
        flash(u"신규항목 조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"신규항목 조회 중 오류가 발생했습니다.")
        return render_template('opmw/dailycheck_history_list.html', menu_active="opmw", login_info=get_login_session(),
                               form=request.form, pagination=None, task_run_list_result=None,
                               sel_status=None, sel_result=None, sel_okyn=None, page=None, per_page=None,
                               search_condition=search_condition, runList_total_cnt=None)

    # for Debug
    search_condition.check_validate()
    search_condition.print_console()
    search_condition.print_log()

    taskRunList = None
    try:
        taskRunList = get_task_run_list.get_task_run_list_hts(search_condition)
        taskRunList_total_cnt = get_task_run_list.get_task_run_list_hts_total_count(search_condition)
    except SqlBaseException:
        current_app.logger.error(u"조회 중 오류가 발생했습니다.")
        return render_template('opmw/dailycheck_history_list.html', menu_active="opmw", login_info=get_login_session(),
                               form=request.form, pagination=None, task_run_list_result=None,
                               sel_status=None, sel_result=None, sel_okyn=None, page=None, per_page=None,
                               search_condition=search_condition, runList_total_cnt=None)
    seq = 0
    result_list = list()
    # pagination = Pagination("", page, per_page, taskRunList_total_cnt, taskRunList)
    for idx in range(0, len(taskRunList)):
        taskRun_dict = dict()
        taskRun_dict["TASK_RESULT_NO"] = taskRunList[idx]['TASK_RESULT_NO']
        taskRun_dict["INSTANCE_NO"] = taskRunList[idx]['INSTANCE_NO']
        taskRun_dict["NODE_ID"] = taskRunList[idx]['NODE_ID']
        taskRun_dict["TASK_ID"] = taskRunList[idx]['TASK_ID']
        taskRun_dict["EXEC_NO"] = taskRunList[idx]['EXEC_NO']
        taskRun_dict["STATUS"] = taskRunList[idx]['STATUS']
        if taskRunList[idx]['START_DT'] != "":
            start_tmp = datetime.strptime(taskRunList[idx]['START_DT'], '%Y%m%d%H%M%S')  # 20181113155801
            taskRun_dict["START_DT"] = start_tmp.strftime('%Y-%m-%d %H:%M:%S')
        else:
            taskRun_dict["START_DT"] = taskRunList[idx]['START_DT']

        # if taskRunList[idx]['END_DT'] != "":
        #     end_tmp = datetime.strptime(taskRunList[idx]['END_DT'], '%Y%m%d%H%M%S')  # 20181113155801
        #     taskRun_dict["END_DT"] = end_tmp.strftime('%Y-%m-%d %H:%M:%S')
        # else:
        taskRun_dict["END_DT"] = taskRunList[idx]['END_DT']
        taskRun_dict["RUNNER_ID"] = taskRunList[idx]['RUNNER_ID']
        taskRun_dict["RESULT"] = taskRunList[idx]['RESULT']
        taskRun_dict["RUN_RESULT"] = taskRunList[idx]['RUN_RESULT']
        json_val = json.dumps(taskRun_dict)
        result_list.append(json_val)

    current_app.logger.debug("result_list=<%r>" % result_list)

    treeListResult = get_tree_node_list.get_tree_node_list()
    current_app.logger.debug("tree_cat_mgmt result: <%r>" % treeListResult)
    tree_list = list()

    for item in range(0, len(treeListResult)):
        treeList_dict = dict()
        treeList_dict["CAT_ID"] = treeListResult[item]['CAT_ID']
        treeList_dict["UPPER_CAT_ID"] = treeListResult[item]['UPPER_CAT_ID']
        treeList_dict["CAT_NM"] = treeListResult[item]['CAT_NM']
        treeList_dict["CAT_EXPANDED"] = 'false'
        treeList_dict["DEPTH"] = treeListResult[item]['DEPTH']
        json_val = json.dumps(treeList_dict)
        tree_list.append(json_val)

    return render_template('opmw/dailycheck_history_list.html', menu_active="opmw", login_info=get_login_session(),
                           form=request.form, pagination=None,
                           task_run_list_result=result_list, sel_status=sel_status_dic, sel_result=sel_result_dic,
                           sel_okyn=sel_okyn_dic, page=None, per_page=None, searchOn=False,
                           search_condition=search_condition, tree_list=tree_list, runList_total_cnt=None, line_map=line_map)



@opmw_dailycheck_history_list.route('/dailycheck_hts_new', methods=["GET", "POST"])
@login_required
def dailycheck_hts_new():
    """
    일일점검 수행 결과목록 reLoad
    :return:
    """
    # page = request.args.get('ipage', type=int)
    # per_page = request.args.get('iper_page', type=int)

    # current_app.logger.debug("dailycheck_new <page=%r><type=%r>" % (str(page), type(page)))
    # current_app.logger.debug("dailycheck_new <per_page=%r><type=%r>" % (str(per_page), type(per_page)))

    search_condition = NewRunListSearch()

    # request type is GET, Not defined search_i_mode
    if search_condition.isArgsAll(request) is True:
        search_condition.search_mode = "all"
    elif search_condition.args_request_handler(request) is False:
        flash(u"신규항목 조회 중 오류가 발생했습니다.")
        current_app.logger.error(u"신규항목 조회 중 오류가 발생했습니다.")
        return jsonify(None)

    # for Debug
    search_condition.check_validate()
    search_condition.print_console()
    search_condition.print_log()

    try:
        taskRunList = get_task_run_list.get_task_run_list_hts(search_condition)

    except SqlBaseException:
        current_app.logger.error(u"조회 중 오류가 발생했습니다.")
        return jsonify(None)

    result_list = list()

    for idx in range(0, len(taskRunList)):
        taskRun_dict = dict()
        taskRun_dict["TASK_RESULT_NO"] = taskRunList[idx]['TASK_RESULT_NO']
        taskRun_dict["INSTANCE_NO"] = taskRunList[idx]['INSTANCE_NO']
        taskRun_dict["NODE_ID"] = taskRunList[idx]['NODE_ID']
        taskRun_dict["TASK_ID"] = taskRunList[idx]['TASK_ID']
        taskRun_dict["EXEC_NO"] = taskRunList[idx]['EXEC_NO']
        taskRun_dict["STATUS"] = taskRunList[idx]['STATUS']
        if taskRunList[idx]['START_DT'] != "":
            start_tmp = datetime.strptime(taskRunList[idx]['START_DT'], '%Y%m%d%H%M%S')  # 20181113155801
            taskRun_dict["START_DT"] = start_tmp.strftime('%Y-%m-%d %H:%M:%S')
        else:
            taskRun_dict["START_DT"] = taskRunList[idx]['START_DT']

        # if taskRunList[idx]['END_DT'] != "":
        #     end_tmp = datetime.strptime(taskRunList[idx]['END_DT'], '%Y%m%d%H%M%S')  # 20181113155801
        #     taskRun_dict["END_DT"] = end_tmp.strftime('%Y-%m-%d %H:%M:%S')
        # else:
        taskRun_dict["END_DT"] = taskRunList[idx]['END_DT']
        taskRun_dict["RUNNER_ID"] = taskRunList[idx]['RUNNER_ID']
        taskRun_dict["RESULT"] = taskRunList[idx]['RESULT']
        taskRun_dict["RUN_RESULT"] = taskRunList[idx]['RUN_RESULT']
        # json_val = json.dumps(taskRun_dict)
        # result_list.append(json_val)
        result_list.append(taskRun_dict)

    current_app.logger.debug("result_list=<%r>" % result_list)
    # print (new_result)

    return jsonify(result_list)