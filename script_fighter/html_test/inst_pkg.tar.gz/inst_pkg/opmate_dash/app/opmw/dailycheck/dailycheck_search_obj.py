# _*_ coding: utf-8 _*_
from flask import current_app, request, flash


class NewRunListSearch:
    def __init__(self, search_condition=None):
        self.search_mode = ""
        self.node_id = ""
        self.task_id = ""
        self.runner_id = ""
        self.fromStart_dt = ""
        self.toStart_dt = ""
        self.fromEnd_dt = ""
        self.toEnd_dt = ""
        self.status = ""
        self.result = ""
        self.okyn = ""
        self.search_condition_map = {
            'Request': 'C',
            'Fail': 'F',
            'Complete': 'S',
            'Ready': 'R',
            '미수행': 'N',
            'Success': 'S',
            'Check': 'N',
            'OK': 'Y',
            'ALL': ''
        }
        # request handler

    def form_request_handler(self, request):
        """
        request_handler(arg_param=request)
        :param request:
        :param arg_param:
        :return:
        """
        try:
            if request is not None:
                # self.search_mode = request.form.get("search_i_mode")
                self.node_id = request.form.get("search_i_node_id")
                self.task_id = request.form.get("search_i_task_id")
                self.runner_id = request.form.get("search_i_runner_id")
                self.fromStart_dt = request.form.get("search_i_fromStart_dt")
                self.toStart_dt = request.form.get("search_i_toStart_dt")
                self.status = request.form.get("search_i_status")
                self.result = request.form.get("search_i_result")
                self.okyn = request.form.get("search_i_okyn")

            if request.form.get("search_i_node_id") == "" or request.form.get("search_i_node_id") is None :
                self.node_id = ""

            if request.form.get("search_i_task_id") == "" or request.form.get("search_i_task_id") is None :
                self.task_id = ""

            if request.form.get("search_i_runner_id") == "" or request.form.get("search_i_runner_id") is None :
                self.runner_id = ""

            if request.form.get("search_i_fromStart_dt") == "" or request.form.get("search_i_fromStart_dt") is None :
                self.fromStart_dt = ""

            if request.form.get("search_i_toStart_dt") == "" or request.form.get("search_i_toStart_dt") is None :
                self.toStart_dt = ""

            if request.form.get("search_i_result") == "" or request.form.get("search_i_result") is None :
                self.result = ""
            else:
                self.result = self.search_condition_map[str(request.form.get("search_i_result"))]

            if request.form.get("search_i_status") == "" or request.form.get("search_i_status") is None:
                self.status = ""
            else:
                self.status = self.search_condition_map[str(request.form.get("search_i_status"))]

            if request.form.get("search_i_okyn") == "" or request.form.get("search_i_okyn") is None :
                self.okyn = ""
            else:
                self.okyn = self.search_condition_map[str(request.form.get("search_i_okyn"))]

            self.print_log()

        except Exception as e:
            current_app.logger.error(u"요청 처리 오류 : [{0}]".format(e.message))
            flash(u"요청 처리 오류 : [{0}]".format(e.message))
            return False

        return True

    def args_request_handler(self, request):
        """
        request_handler(arg_param=request)
        :param request:
        :param arg_param:
        :return:
        """
        try:
            if request is not None:
                # self.search_mode = request.args.get("search_i_mode")
                self.node_id = request.args.get("search_i_node_id")
                self.task_id = request.args.get("search_i_task_id")
                self.runner_id = request.args.get("search_i_runner_id")
                self.fromStart_dt = request.args.get("search_i_fromStart_dt")
                self.toStart_dt = request.args.get("search_i_toStart_dt")
                self.status = request.form.get("search_i_status")
                self.result = request.args.get("search_i_result")
                self.okyn = request.args.get("search_i_okyn")

            if request.args.get("search_i_node_id") == "" or request.args.get("search_i_node_id") is None:
                self.node_id = ""
            if request.args.get("search_i_task_id") == "" or request.args.get("search_i_task_id") is None:
                self.task_id = ""
            if request.args.get("search_i_runner_id") == "" or request.args.get("search_i_runner_id") is None:
                self.runner_id = ""

            if request.args.get("search_i_fromStart_dt") == "" or request.args.get("search_i_fromStart_dt") is None:
                self.fromStart_dt = ""
            if request.args.get("search_i_toStart_dt") == "" or request.args.get("search_i_toStart_dt") is None:
                self.toStart_dt = ""

            if request.args.get("search_i_result") == "" or request.args.get("search_i_result") is None:
                self.result = ""
            else:
                self.result = self.search_condition_map[str(request.args.get("search_i_result"))]

            if request.form.get("search_i_status") == "" or request.form.get("search_i_status") is None:
                self.status = ""
            else:
                self.status = self.search_condition_map[str(request.form.get("search_i_status"))]

            if request.args.get("search_i_okyn") == "" or request.args.get("search_i_okyn") is None:
                self.okyn = ""
            else:
                self.okyn = self.search_condition_map[str(request.args.get("search_i_okyn"))]

        except Exception as e:
            current_app.logger.error(u"요청 처리 오류 : [{0}]".format(e.message))
            flash(u"요청 처리 오류 : [{0}]".format(e.message))
            return False

        return True

    def isFormAll(self, request):
        """
        request_handler(arg_param=request)
        :param request:
        :param arg_param:
        :return:
        """
        if request is not None:
            if (request.form.get("search_i_node_id") == "" or request.form.get("search_i_node_id") is None) and \
                    (request.form.get("search_i_task_id") == "" or request.form.get("search_i_task_id") is None) and \
                    (request.form.get("search_i_runner_id") == "" or request.form.get("search_i_runner_id") is None) and \
                    (request.form.get("search_i_fromStart_dt") == "" or request.form.get("search_i_fromStart_dt") is None) and \
                    (request.form.get("search_i_toStart_dt") == "" or request.form.get("search_i_toStart_dt") is None) and \
                    (request.form.get("search_i_result") == "" or request.form.get("search_i_result") is None) and \
                    (request.form.get("search_i_status") == "" or request.form.get("search_i_status") is None) and \
                    (request.form.get("search_i_okyn") == "" or request.form.get("search_i_okyn") is None):

                return True
            else:
                return False

    def isArgsAll(self, request):
        """
        request_handler(arg_param=request)
        :param request:
        :param arg_param:
        :return:
        """
        if request is not None:
            if (request.args.get("search_i_node_id") == "" or request.args.get("search_i_node_id") is None) and \
                (request.args.get("search_i_task_id") == "" or request.args.get("search_i_task_id") is None) and \
                (request.args.get("search_i_runner_id") == "" or request.args.get("search_i_runner_id") is None) and \
                (request.args.get("search_i_fromStart_dt") == "" or request.args.get("search_i_fromStart_dt") is None) and \
                (request.args.get("search_i_toStart_dt") == "" or request.args.get("search_i_toStart_dt") is None) and \
                (request.args.get("search_i_result") == "" or request.args.get("search_i_result") is None) and \
                (request.form.get("search_i_status") == "" or request.args.get("search_i_status") is None) and \
                (request.args.get("search_i_okyn") == "" or request.args.get("search_i_okyn") is None) :

                return True
            else:
                return False

    # response handler
    def response_handler(self):
        current_app.logger.info(u"조회 완료 되었습니다.")
        flash(u"조회 완료 되었습니다.")
        return

    # check validation
    def check_validate(self):
        result = True
        if self.fromStart_dt != "":
            s_fromStart = (str(self.fromStart_dt)).strip().split('-')
            self.fromStart_dt = s_fromStart[0] + s_fromStart[1] + s_fromStart[2] + "000000"

        if self.toStart_dt != "" :
            s_toStart = (str(self.toStart_dt)).strip().split('-')
            self.toStart_dt = s_toStart[0] + s_toStart[1] + s_toStart[2] + "235959"

        return result

    # print to Log file
    def print_log(self):
        current_app.logger.debug(u"self.search_mode     = {0}".format(self.search_mode))
        current_app.logger.debug(u"self.node_id         = {0}".format(self.node_id))
        current_app.logger.debug(u"self.task_id         = {0}".format(self.task_id))
        current_app.logger.debug(u"self.runner_id       = {0}".format(self.runner_id))
        current_app.logger.debug(u"self.fromStart_dt    = {0}".format(self.fromStart_dt))
        current_app.logger.debug(u"self.toStart_dt      = {0}".format(self.toStart_dt))
        current_app.logger.debug(u"self.result          = {0}".format(self.result))
        current_app.logger.debug(u"self.status          = {0}".format(self.status))
        current_app.logger.debug(u"self.okyn            = {0}".format(self.okyn))

        return

    # print to Console
    def print_console(self):
        print(u"self.search_mode    = {0}".format(self.search_mode))
        print(u"self.node_id        = {0}".format(self.node_id))
        print(u"self.task_id        = {0}".format(self.task_id))
        print(u"self.runner_id      = {0}".format(self.runner_id))
        print(u"self.fromStart_dt   = {0}".format(self.fromStart_dt))
        print(u"self.toStart_dt     = {0}".format(self.toStart_dt))
        print(u"self.result         = {0}".format(self.result))
        print(u"self.status         = {0}".format(self.status))
        print(u"self.okyn           = {0}".format(self.okyn))

        return

