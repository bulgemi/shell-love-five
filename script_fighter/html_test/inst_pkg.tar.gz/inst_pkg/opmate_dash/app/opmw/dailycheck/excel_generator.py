# _*_ coding: utf-8 _*_

# from openpyxl.compat import range
# from openpyxl.utils import get_column_letter
from flask import current_app
from datetime import datetime
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Border, Side, PatternFill, Font, GradientFill, Alignment, colors, Protection
from openpyxl.worksheet.protection import SheetProtection
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.comments import Comment
import os
import json


# def gen_excel():
#     wb = Workbook()
#
#     dest_filename = 'empty_book.xlsx'
#
#     ws1 = wb.active
#     ws1.title = "range names"
#
#     for row in range(1, 40):
#         ws1.append(range(600))
#
#     ws2 = wb.create_sheet(title="pi")
#
#     ws2['F5'] = 3.14
#
#     ws3 = wb.create_sheet(title="Data")
#     for row in range(10, 20):
#         for col in range(27, 54):
#             _ = ws3.cell(column=col, row=row, value="{0}".format(get_column_letter(col)))
#
#     print(ws3['aa10'].value)
#
#     wb.save(filename=dest_filename)


class StyleInfo:
    def __init__(self):
        ############################
        # Setting Style in Cell
        ############################
        # Setting Border
        self.thin = Side(border_style="thin", color=colors.BLACK)  # "000000" == colors.BLACK
        self.thick = Side(border_style="thick", color=colors.BLACK)
        self.double = Side(border_style="double", color=colors.BLACK)

        # Setting Title
        self.title_border = {'left': Border(top=self.thick, left=self.thick, right=self.thin, bottom=self.double),
                             'right': Border(top=self.thick, left=self.thin, right=self.thick, bottom=self.double),
                             'middle': Border(top=self.thick, left=self.thin, right=self.thin, bottom=self.double)}

        # Setting Data Top(Row)
        self.data_top_border = {'left': Border(top=self.double, left=self.thick, right=self.thin, bottom=self.thin),
                                'right': Border(top=self.double, left=self.thin, right=self.thick, bottom=self.thin),
                                'middle': Border(top=self.double, left=self.thin, right=self.thin, bottom=self.thin)}

        # Setting Data Bottom(Row)
        self.data_bottom_border = {'left': Border(top=self.thin, left=self.thick, right=self.thin, bottom=self.thick),
                                   'right': Border(top=self.thin, left=self.thin, right=self.thick, bottom=self.thick),
                                   'middle': Border(top=self.thin, left=self.thin, right=self.thin, bottom=self.thick)}

        # Setting Data Middle(Row)
        self.data_middle_border = {'left': Border(top=self.thin, left=self.thick, right=self.thin, bottom=self.thin),
                                   'right': Border(top=self.thin, left=self.thin, right=self.thick, bottom=self.thin),
                                   'middle': Border(top=self.thin, left=self.thin, right=self.thin, bottom=self.thin)}

        self.fill = PatternFill("solid", fgColor=colors.YELLOW)
        self.fill_check = PatternFill("solid", fgColor=colors.RED)
        self.font = Font(b=True)
        self.alignment = Alignment(horizontal="center", vertical="center")


def generate_excel(data):
    """
    일일점검 수행결과를 엑셀파일로 저장
    :param meta_data:
    :return:
    """
    file_dir = current_app.config['EXCEL_EXPORT_HOME']
    file_name = 'dailycheck_' + datetime.now().strftime('%Y%m%d') + '.xlsx'

    current_app.logger.info('Start Excel File Export : {0}/{1}'.format(file_dir, file_name))

    ################
    # create excel #
    ################
    wb = Workbook()

    # grab the active worksheet
    ws_data = wb.active
    ws_data.title = u"일일점검"

    ############################
    # Setting Style in Cell
    ############################
    style = StyleInfo()

    form_column_name_list = ['TASK_ID', 'INSTANCE_NO', 'NODE_ID', 'STATUS', 'RESULT', 'TITLE', 'VALUE']
    col_idx = 1

    for col_name in form_column_name_list:

        cell = ws_data.cell(row=1, column=col_idx)
        cell.value = col_name
        # cell.comment = Comment(col_name['itm_id'], usr_def_itm_yn)

        cell.fill = style.fill
        cell.font = style.font
        cell.alignment = style.alignment
        cell.border = style.data_middle_border['middle']

        # if col_idx == 1:  # 첫번째 컬럼
        #     cell.border = style.title_border['left']
        # elif col_idx == len(form_column_name_list):  # 마지막 컬럼
        #     cell.border = style.title_border['right']
        # else:
        #     cell.border = style.title_border['middle']

        col_idx += 1

    ##############
    # Write Data
    ##############
    row_idx = 2

    for data_row in data:
        col_idx = 1

        cell.border = style.data_middle_border['middle']
        cell = ws_data.cell(row=row_idx, column=col_idx)
        cell.value = data_row['TASK_ID']
        col_idx += 1

        cell.border = style.data_middle_border['middle']
        cell = ws_data.cell(row=row_idx, column=col_idx)
        cell.value = data_row['INSTANCE_NO']
        col_idx += 1

        cell.border = style.data_middle_border['middle']
        cell = ws_data.cell(row=row_idx, column=col_idx)
        cell.value = data_row['NODE_ID']
        col_idx += 1

        cell.border = style.data_middle_border['middle']
        cell = ws_data.cell(row=row_idx, column=col_idx)
        cell.value = data_row['STATUS']
        col_idx += 1

        cell.border = style.data_middle_border['middle']
        cell = ws_data.cell(row=row_idx, column=col_idx)
        cell.value = data_row['RESULT']
        if cell.value == 'CHECK':
            cell.fill = style.fill_check
        col_idx += 1

        cell.border = style.data_middle_border['middle']
        cell = ws_data.cell(row=row_idx, column=col_idx)
        cell.value = data_row['TITLE']
        col_idx += 1

        cell.border = style.data_middle_border['middle']
        cell = ws_data.cell(row=row_idx, column=col_idx)
        cell.value = str(data_row['VALUE']).strip()
        col_idx += 1

        cell.border = style.data_middle_border['middle']

        # if row_idx == 2:  # data 의 첫번째 Row
        #     if col_idx == 1:  # 첫번째 컬럼
        #         cell.border = style.data_top_border['left']
        #     elif col_idx == len(data_row):  # 마지막 컬럼
        #         cell.border = style.data_top_border['right']
        #     else:
        #         cell.border = style.data_top_border['middle']
        # elif row_idx == len(form_column_name_list) + 1:  # 마지막 Row
        #     if col_idx == 1:  # 첫번째 컬럼
        #         cell.border = style.data_bottom_border['left']
        #     elif col_idx == len(data_row):  # 마지막 컬럼
        #         cell.border = style.data_bottom_border['right']
        #     else:
        #         cell.border = style.data_bottom_border['middle']
        # else:
        #     if col_idx == 1:  # 첫번째 컬럼
        #         cell.border = style.data_middle_border['left']
        #     elif col_idx == len(data_row):  # 마지막 컬럼
        #         cell.border = style.data_middle_border['right']
        #     else:
        #         cell.border = style.data_middle_border['middle']

        row_idx += 1

    #############################
    # Save the file
    #############################
    # If Not Exists Directory, Make Directory.
    if os.path.exists(file_dir) is False:
        os.mkdir(file_dir, 0775)

    wb.save(file_dir + "/" + file_name)

    current_app.logger.info('Completed Excel File Export : {0}/{1}'.format(file_dir, file_name))

    # 성공: True, 실패: False
    return True, file_dir, file_name
