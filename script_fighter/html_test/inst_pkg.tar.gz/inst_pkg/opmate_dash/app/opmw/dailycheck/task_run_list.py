# _*_ coding: utf-8 _*_

__author__ = 'kim kyung hee'

from datetime import datetime
from dateutil.relativedelta import relativedelta
from flask import Blueprint, render_template, current_app, flash, request
# Cellar
from app.splunkbridge.bridge import SplunkBridge, connect_splunk
from app import get_login_session, login_required
# MPCR DAO


infradb_conf_info = Blueprint('infradb_conf_info', __name__, template_folder='templates')
query_infradb_conf_info = Blueprint('query_infradb_conf_info', __name__, template_folder='templates')


@infradb_conf_info.route('/opmw/dailycheck')
@login_required
def dailycheck_result():
    """
    일일점검 결과 조회 목록
    :return:
    """
    html_file = 'opmw/dailycheck_result_list.html'

    contents = dict()
    contents['end_date'] = datetime.now().strftime("%Y%m%d")
    datetime_object = datetime.strptime(contents['end_date'], '%Y%m%d')
    yyyymmdd = datetime_object - relativedelta(days=1)
    contents['start_date'] = yyyymmdd.strftime("%Y%m%d")

    th_row_list = list()
    row_list = list()

    service = connect_splunk(username=current_app.config['SPLUNK_USER'],
                             password=current_app.config['SPLUNK_PASSWORD'],
                             host=current_app.config['SPLUNK_IP'],
                             port=int(current_app.config['SPLUNK_PORT']))
    bridge = SplunkBridge(service)

    dbname = '*'
    macro_name = '`TEXT_ORACLE_CONF_INFO({}, {}, {})`'.format(contents['start_date'], contents['end_date'], dbname)

    current_app.logger.debug("macro_name=<%r>" % macro_name)

    result, message = bridge.search_one_shot(macro_name='`int_csp_sru_cpu_db`')
    # result, message = bridge.search_one_shot(macro_name=macro_name)

    for data_index, data in enumerate(result):
        row_data_list = list()

        for k, v in data.items():
            if data_index == 0:
                th_row_list.append(k)
            current_app.logger.debug("k<%r>=<%r>" % (k, v))
            row_data_list.append(v)
        row_list.append(row_data_list)

    if len(result) > 0:
        contents['th_row'] = th_row_list
        contents['row'] = row_list
    else:
        flash('Splunk Macro 호출 or 데이터 조회에 실패하였습니다.')

    return render_template('opmw/dailycheck_result_list.html', menu_active="dailycheck_result",
                           login_info=get_login_session())

