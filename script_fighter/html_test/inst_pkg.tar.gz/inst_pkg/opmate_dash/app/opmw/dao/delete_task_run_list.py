# _*_ coding: utf-8 _*_

__author__ = 'kim kyung hee'

# flask
from flask import current_app, flash
# DAO
from app import db
from app.models import OpmwTaskRunListDtl


def delete_task_run_list_dtl(task_result_no):
    """
    TASK_RUN_LIST_DTL 테이블에서 task_result_no Row 삭제 .

    :return:True or False
    """
    # current_app.logger.debug("task_result_no=<%r>" % task_result_no)
    try:
        # 기존 정보 삭제.
        OpmwTaskRunListDtl.query \
            .filter(OpmwTaskRunListDtl.TASK_RESULT_NO == task_result_no) \
            .delete()
        db.session.commit()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        db.session.rollback()

        return False

    return True
