# _*_ coding: utf-8 _*_

__author__ = 'kim kyunh hee'

# flask
from flask import current_app, flash
# DAO
from app.models import OpmwTaskRunList


def get_task_result_no_max():
    """
    TASK_RUN_LIST 테이블에서 마지막 task_result_no 를 채번한다.

    :return:task_result_no
    """
    try:
        result = OpmwTaskRunList.query \
            .order_by(OpmwTaskRunList.TASK_RESULT_NO.desc()) \
            .first()

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return False, 0

    # Max(TASK_RESULT_NO) 에 +1 해서 TASK_RESULT_NO 반환.
    if result is not None:
        task_result_no = int(result.TASK_RESULT_NO) + 1
    else:
        task_result_no = 0

    return task_result_no