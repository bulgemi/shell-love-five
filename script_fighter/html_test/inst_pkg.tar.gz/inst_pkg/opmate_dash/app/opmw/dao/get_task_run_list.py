# _*_ coding: utf-8 _*_

__author__ = 'kim kyung hee'

# flask
from flask import current_app, flash
# DAO
from app import db
from app.cellarerror.sqlerror import SqlBaseException
from app.models import OpmwTaskRunList, OpmwTaskRunListDtl
from sqlalchemy import and_ , or_ , func


def get_run_list_max_result_no():
    """
    TASK_RUN_LIST 테이블에서 마지막 task_result_no 를 채번한다.

    :return:task_result_no
    """
    try:
        result = OpmwTaskRunList.query \
            .order_by(OpmwTaskRunList.TASK_RESULT_NO.desc()) \
            .first()

    except Exception as e:
        raise SqlBaseException(e)

    # Max(TASK_RESULT_NO) TASK_RESULT_NO 반환.
    if result is not None:
        task_result_no = int(result.TASK_RESULT_NO)
    else:
        task_result_no = 0

    return task_result_no


def get_run_list_dtl_max_result_no():
    """
    TASK_RUN_LIST_DTL 테이블에서 마지막 task_result_no 를 채번한다.

    :return:task_result_no
    """
    try:
        result = OpmwTaskRunListDtl.query \
            .order_by(OpmwTaskRunListDtl.TASK_RESULT_NO.desc()) \
            .first()
        print ("get_run_list_dtl_max_result_no = <%r>" % result.TASK_RESULT_NO)
    except Exception as e:
        raise SqlBaseException(e)

    # Max(TASK_RESULT_NO) TASK_RESULT_NO 반환.
    if result is not None:
        task_result_no = int(result.TASK_RESULT_NO)
    else:
        task_result_no = 0

    return task_result_no


def get_run_list_dtl_max_seq(task_result_no):
    """
    TASK_RUN_LIST_DTL 테이블에서 task_result_no 의 마지막 SEQ 를 채번한다.

    :return:seq
    """
    try:
        result = OpmwTaskRunListDtl.query \
            .filter(OpmwTaskRunListDtl.TASK_RESULT_NO == task_result_no) \
            .order_by(OpmwTaskRunListDtl.SEQ.desc()) \
            .first()

    except Exception as e:
        raise SqlBaseException(e)

    # Max(TASK_RESULT_NO) TASK_RESULT_NO 반환.
    if result is not None:
        seq = int(result.SEQ)
    else:
        seq = 0

    return seq


# def get_new_task_run_list(search_condition, page, per_page):
def get_new_task_run_list(search_condition):
    """
    SELECT TASK_RESULT_NO
         , INSTANCE_NO
         , NODE_ID
         , EXEC_NO
         , TASK_ID
         , STATUS
         , START_DT
         , END_DT
         , RUNNER_ID
         , RESULT
         , RUN_RESULT
    FROM TASK_RUN_LIST
    ORDER BY DESC TASK_RESULT_NO

    :return : 해당 페이지의 TASK_RUN_LIST 데이터
    """
    search_mode = search_condition.search_mode

    # if search_mode is None:
    #     search_mode = 'all'

    sel_task_id = str(search_condition.task_id)
    sel_result = str(search_condition.result)
    sel_okyn = str(search_condition.okyn)
    sel_node_id = str(search_condition.node_id)
    sel_runner_id = str(search_condition.runner_id)
    sel_fromStart_dt = str(search_condition.fromStart_dt)
    sel_toStart_dt = str(search_condition.toStart_dt)
    sel_fromEnd_dt = str(search_condition.fromEnd_dt)
    sel_toEnd_dt = str(search_condition.toEnd_dt)
    print
    try:
        session = db.session
        temp_query = list()
        temp_query.append("SELECT A.TASK_RESULT_NO, A.INSTANCE_NO, A.NODE_ID, A.TASK_ID, A.EXEC_NO, ")
        temp_query.append(" A.STATUS, A.START_DT, A.END_DT, A.RUNNER_ID, A.RESULT, A.RUN_RESULT ")
        temp_query.append(" FROM TASK_RUN_LIST A, ")
        temp_query.append(" ( SELECT INSTANCE_NO, NODE_ID, max(EXEC_NO) AS EXEC_NO FROM TASK_RUN_LIST ")
        temp_query.append(" GROUP BY INSTANCE_NO, NODE_ID ) B ,  ")
        temp_query.append(" ( SELECT max(INSTANCE_NO) AS INSTANCE_NO FROM TASK_RUN_LIST ")
        temp_query.append(" GROUP BY TASK_ID ) C ")
        temp_query.append(" WHERE A.NODE_ID = B.NODE_ID AND A.EXEC_NO = B.EXEC_NO ")
        temp_query.append("   AND A.INSTANCE_NO = B.INSTANCE_NO AND B.INSTANCE_NO = C.INSTANCE_NO")

        # if search_mode == "all":
        #     pass
        # else:
            # if sel_task_id != "" or sel_result != "" or sel_okyn != "" or sel_okyn != "":
        if sel_task_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.TASK_ID like " + "'%" + search_condition.task_id + "%'")
        if sel_result != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RESULT = " + "'" + search_condition.result + "'")
        if sel_okyn != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RUN_RESULT = " + "'" + search_condition.okyn + "'")
        if sel_node_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.NODE_ID like " + "'%" + sel_node_id + "%'")
        if sel_runner_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RUNNER_ID like " + "'%" + sel_runner_id + "%'")
        if search_condition.status != "":
            temp_query.append(" AND ")
            temp_query.append(" A.STATUS = " + "'" + search_condition.status + "'")
        if sel_fromStart_dt != "" and sel_toStart_dt != "":
            temp_query.append(" AND ")
            temp_query.append(" A.START_DT >= " + "'" + sel_fromStart_dt + "'")
            temp_query.append(" AND ")
            temp_query.append(" A.START_DT <= " + "'" + sel_toStart_dt + "'")
        if sel_fromEnd_dt != "" and sel_toEnd_dt != "":
            temp_query.append(" AND ")
            temp_query.append(" A.END_DT >= " + "'" + sel_fromEnd_dt + "'")
            temp_query.append(" AND ")
            temp_query.append(" A.END_DT <= " + "'" + sel_toEnd_dt + "'")
        temp_query.append(" ORDER BY A.TASK_RESULT_NO DESC ")

        # if per_page is not None and page is not None:
        #     temp_query.append(" LIMIT {0}, {1}".format((page - 1) * per_page, per_page))

        # print temp_query
        query = ''.join(temp_query)
        current_app.logger.debug('get_new_task_run_list query=<%r>' % query)
        statement = session.query(
            'TASK_RESULT_NO',
            'INSTANCE_NO',
            'NODE_ID',
            'EXEC_NO',
            'TASK_ID',
            'STATUS',
            'START_DT',
            'END_DT',
            'RUNNER_ID',
            'RESULT',
            'RUN_RESULT'
        ).from_statement(query)
        current_app.logger.debug('get_new_task_run_list statement=<%r>' % str(statement))
        # result = statement.all()
        # current_app.logger.debug('result=<%r>' % result)
        # seq = 0
        result_list = list()
        result = statement.all()
        # pagination = result.paginate(page, per_page=per_page, error_out=False)

        # 2018.12.13 KYM added.
        # if per_page is None and page is None:
        #     page = 0
        #     per_page = 0

        for page_result in result:
            # seq += 1
            # list_seq = ((page - 1) * per_page) + seq
            # result_list.append({"SEQ": list_seq
            result_list.append({"TASK_RESULT_NO": page_result.TASK_RESULT_NO
                                   , "INSTANCE_NO": page_result.INSTANCE_NO
                                   , "NODE_ID": page_result.NODE_ID
                                   , "EXEC_NO": page_result.EXEC_NO
                                   , "TASK_ID": page_result.TASK_ID
                                   , "STATUS": page_result.STATUS
                                   , "START_DT": page_result.START_DT
                                   , "END_DT": page_result.END_DT
                                   , "RUNNER_ID": page_result.RUNNER_ID
                                   , "RESULT": page_result.RESULT
                                   , "RUN_RESULT": page_result.RUN_RESULT
                                })

    except Exception as e:
        raise SqlBaseException(e)
    # return pagination, stmt
    return result_list


def get_new_task_run_list_total_count(search_condition):
    """
    SELECT TASK_RESULT_NO
         , INSTANCE_NO
         , NODE_ID
         , EXEC_NO
         , TASK_ID
         , STATUS
         , START_DT
         , END_DT
         , RUNNER_ID
         , RESULT
         , RUN_RESULT
    FROM TASK_RUN_LIST
    ORDER BY DESC TASK_RESULT_NO

    :return : 해당 페이지의 TASK_RUN_LIST 데이터
    """
    search_mode = search_condition.search_mode

    # if search_mode is None:
    #     search_mode = 'all'

    sel_task_id = str(search_condition.task_id)
    sel_result = str(search_condition.result)
    sel_okyn = str(search_condition.okyn)
    sel_node_id = str(search_condition.node_id)
    sel_runner_id = str(search_condition.runner_id)
    sel_fromStart_dt = str(search_condition.fromStart_dt)
    sel_toStart_dt = str(search_condition.toStart_dt)
    sel_fromEnd_dt = str(search_condition.fromEnd_dt)
    sel_toEnd_dt = str(search_condition.toEnd_dt)

    try:
        session = db.session

        temp_query = list()
        temp_query.append("SELECT COUNT({0}) AS {1}".format('A.TASK_RESULT_NO', 'TASK_RESULT_NO'))
        temp_query.append(" FROM TASK_RUN_LIST A, ")
        temp_query.append(" ( SELECT INSTANCE_NO, NODE_ID, max(EXEC_NO) AS EXEC_NO FROM TASK_RUN_LIST ")
        temp_query.append(" GROUP BY INSTANCE_NO, NODE_ID ) B ,  ")
        temp_query.append(" ( SELECT max(INSTANCE_NO) AS INSTANCE_NO FROM TASK_RUN_LIST ")
        temp_query.append(" GROUP BY TASK_ID ) C ")
        temp_query.append(" WHERE A.NODE_ID = B.NODE_ID AND A.EXEC_NO = B.EXEC_NO ")
        temp_query.append("   AND A.INSTANCE_NO = B.INSTANCE_NO AND B.INSTANCE_NO = C.INSTANCE_NO")

        # if search_mode == "all":
        #     pass
        # else:
            # if sel_task_id != "" or sel_result != "" or sel_okyn != "":
        if sel_task_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.TASK_ID like " + "'%" + search_condition.task_id + "%'")
        if sel_result != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RESULT = " + "'" + search_condition.result + "'")
        if sel_okyn != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RUN_RESULT = " + "'" + search_condition.okyn + "'")
        if sel_node_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.NODE_ID like " + "'%" + sel_node_id + "%'")
        if sel_runner_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RUNNER_ID like " + "'%" + sel_runner_id + "%'")
        if search_condition.status != "":
            temp_query.append(" AND ")
            temp_query.append(" A.STATUS = " + "'" + search_condition.status + "'")
        if sel_fromStart_dt != "" and sel_toStart_dt != "":
            temp_query.append(" AND ")
            temp_query.append(" A.START_DT >= " + "'" + sel_fromStart_dt + "'")
            temp_query.append(" AND ")
            temp_query.append(" A.START_DT <= " + "'" + sel_toStart_dt + "'")
        if sel_fromEnd_dt != "" and sel_toEnd_dt != "":
            temp_query.append(" AND ")
            temp_query.append(" A.END_DT >= " + "'" + sel_fromEnd_dt + "'")
            temp_query.append(" AND ")
            temp_query.append(" A.END_DT <= " + "'" + sel_toEnd_dt + "'")
        temp_query.append(" ORDER BY A.TASK_RESULT_NO DESC ")

        query = ''.join(temp_query)
        current_app.logger.debug('get_new_task_run_list_total_count query=<%r>' % query)

        statement = session.query(
            'TASK_RESULT_NO'
        ).from_statement(query)

        current_app.logger.debug('get_new_task_run_list_total_count statement=<%r>' % str(statement))

        result = statement.first()
        current_app.logger.debug('statement=<%r>' % str(statement))
        current_app.logger.debug('result=<%r>' % format(int(result[0]), ','))

    except Exception as e:
        raise SqlBaseException(e)

    # return pagination, stmt
    return int(result[0])


def get_task_run_list_all():
    """
    SELECT TASK_RESULT_NO
         , INSTANCE_NO
         , NODE_ID
         , EXEC_NO
         , TASK_ID
         , STATUS
         , START_DT
         , END_DT
         , RUNNER_ID
         , RESULT
         , RUN_RESULT
    FROM TASK_RUN_LIST
    ORDER BY DESC TASK_RESULT_NO
    LIMIT 20;
    """

    try:
        result_list = OpmwTaskRunList.query.with_entities(
            OpmwTaskRunList.TASK_RESULT_NO,
            OpmwTaskRunList.INSTANCE_NO,
            OpmwTaskRunList.NODE_ID,
            OpmwTaskRunList.EXEC_NO,
            OpmwTaskRunList.TASK_ID,
            OpmwTaskRunList.STATUS,
            OpmwTaskRunList.START_DT,
            OpmwTaskRunList.END_DT,
            OpmwTaskRunList.RUNNER_ID,
            OpmwTaskRunList.RESULT,
            OpmwTaskRunList.RUN_RESULT)\
            .order_by(OpmwTaskRunList.END_DT.desc())

        # seq = 0
        result = result_list.all()

        # current_app.logger.debug("get_task_run_list=<%r>" % str(result))

    except Exception as e:
        raise SqlBaseException(e)

    return result

def get_task_run_list_dtl(task_result_no):
    """
    SELECT  SEQ,
            DEPTH,
            ITM_VAL
    FROM
            TASK_RUN_LIST_DTL
    WHERE
            TASK_RESULT_NO = task_result_no
    """

    stat_depth_map = {
        '1': 'Title',
        '2': 'Result',
        '3': 'Value',
        '4': 'Error'  # 2018.11.21 KYM added
    }
    result_list = list()

    try:
        result_list_dtl = OpmwTaskRunListDtl.query.with_entities(OpmwTaskRunListDtl.SEQ,
                                                                 OpmwTaskRunListDtl.DEPTH,
                                                                 OpmwTaskRunListDtl.ITM_VAL)\
                                    .filter(OpmwTaskRunListDtl.TASK_RESULT_NO == int(task_result_no))\
                                    .all()

        current_app.logger.debug("result_list_dtl=<%r>" % str(result_list_dtl))
        current_app.logger.debug("stat_clcd_map[1]=<%r>" % stat_depth_map['1'])
        current_app.logger.debug("stat_clcd_map[2]=<%r>" % stat_depth_map['2'])
        current_app.logger.debug("stat_clcd_map[3]=<%r>" % stat_depth_map['3'])
        current_app.logger.debug("stat_clcd_map[4]=<%r>" % stat_depth_map['4'])

        dtl_max_seq = get_run_list_dtl_max_seq(task_result_no)

        if len(result_list_dtl) > 0:
            for idx in range(1, dtl_max_seq+1):
                result_dic = dict()
                # print ("idx <%r>" % str(idx))

                for inquiry in result_list_dtl:
                    if int(idx) == int(inquiry[0]):
                        result_dic[stat_depth_map[str(inquiry[1])]] = str(inquiry[2])

                # result_dic['SEQ'] = int(idx)
                result_list.append(result_dic)

        else:
            return None

    except Exception as e:
        raise SqlBaseException(e)

    return result_list


def get_task_id_list():
    """
    SELECT DISTINCT TASK_ID
    FROM TASK_RUN_LIST;

    TASK_RUN_LIST 테이블에서 task_id 목록을 가져온다

    :return:task_id list
    """
    try:
        task_id_list = OpmwTaskRunList.query.with_entities(
            OpmwTaskRunList.TASK_ID)\
            .distinct()

        result = task_id_list.all()

        # current_app.logger.debug("get_task_id_list=<%r>" % str(result))
    except Exception as e:
        raise SqlBaseException(e)

    return result

def get_result_okyn(task_result_no):
    """
    SELECT ITM_VAL
    FROM TASK_RUN_LIST_DTL;
    WHERE ITM_VAL like "Check"
        and DATA_TYP_CL_CD == 'TWR_I_0010'
        and TASK_RESULT_NO == task_result_no

    TASK_RUN_LIST_DTL 테이블에서 Result 값중 check 있는지 여부 확인

    :return: 소문자 ITM_VAL 값 ('check' or None)
    """
    try:
        result_okyn = OpmwTaskRunListDtl.query.with_entities(OpmwTaskRunListDtl.ITM_VAL) \
            .filter(OpmwTaskRunListDtl.TASK_RESULT_NO == int(task_result_no)) \
            .filter(OpmwTaskRunListDtl.ITM_VAL.like('Check')) \
            .filter(OpmwTaskRunListDtl.DATA_TYP_CL_CD == 'TWR_I_0010') \
            .first()

        if result_okyn is not None:
            result = (result_okyn.ITM_VAL).lower()
        else:
            result = None
        # current_app.logger.debug("get_task_id_list=<%r>" % result)
    except Exception as e:
        raise SqlBaseException(e)

    return result


# 2018.11.07 KYM added.
def get_exec_no_maxval(task_id, instance_no, node_id):
    """
    특정 태스크 인스턴스 번호에 대한 exec_no 의 MAX 값을 가져온다.
    :param task_id:
    :return:
        exec_no
    """

    exec_no = None

    try:
        exec_no = db.session.query(func.max(OpmwTaskRunList.EXEC_NO))\
            .filter(and_((OpmwTaskRunList.TASK_ID == task_id),
                         (OpmwTaskRunList.INSTANCE_NO == instance_no),
                         (OpmwTaskRunList.NODE_ID == node_id)))\
            .group_by(OpmwTaskRunList.TASK_ID, OpmwTaskRunList.INSTANCE_NO, OpmwTaskRunList.NODE_ID).first()

        if exec_no is None:
            exec_no = (0,)

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]"
                                 % (e.args, e.message))
        raise SqlBaseException(e)

    return exec_no[0]


# def get_task_run_list_hts(search_condition, page, per_page):
def get_task_run_list_hts(search_condition):
    """
    SELECT TASK_RESULT_NO
         , INSTANCE_NO
         , NODE_ID
         , EXEC_NO
         , TASK_ID
         , STATUS
         , START_DT
         , END_DT
         , RUNNER_ID
         , RESULT
         , RUN_RESULT
    FROM TASK_RUN_LIST
    ORDER BY DESC TASK_RESULT_NO

    :return : 해당 페이지의 TASK_RUN_LIST 데이터
    """
    search_mode = search_condition.search_mode

    sel_task_id = str(search_condition.task_id)
    sel_result = str(search_condition.result)
    sel_okyn = str(search_condition.okyn)
    sel_node_id = str(search_condition.node_id)
    sel_runner_id = str(search_condition.runner_id)
    sel_fromStart_dt = str(search_condition.fromStart_dt)
    sel_toStart_dt = str(search_condition.toStart_dt)
    sel_fromEnd_dt = str(search_condition.fromEnd_dt)
    sel_toEnd_dt = str(search_condition.toEnd_dt)

    print
    try:
        session = db.session
        temp_query = list()
        temp_query.append("SELECT A.TASK_RESULT_NO, A.INSTANCE_NO, A.NODE_ID, A.TASK_ID, A.EXEC_NO, ")
        temp_query.append(" A.STATUS, A.START_DT, A.END_DT, A.RUNNER_ID, A.RESULT, A.RUN_RESULT ")
        temp_query.append(" FROM TASK_RUN_LIST A ")
        temp_query.append(" WHERE A.TASK_RESULT_NO > 0 ")

        # if search_mode == "all":
        #     pass
        # else:
            # if sel_task_id != "" or sel_result != "" or sel_okyn != "" or sel_node_id != "":
        if sel_task_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.TASK_ID like " + "'%" + search_condition.task_id + "%'")
        if sel_result != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RESULT = " + "'" + search_condition.result + "'")
        if sel_okyn != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RUN_RESULT = " + "'" + search_condition.okyn + "'")
        if sel_node_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.NODE_ID like " + "'%" + sel_node_id + "%'")
        if sel_runner_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RUNNER_ID like " + "'%" + sel_runner_id + "%'")
        if search_condition.status != "":
            temp_query.append(" AND ")
            temp_query.append(" A.STATUS = " + "'" + search_condition.status + "'")
        if sel_fromStart_dt != "" and sel_toStart_dt != "":
            temp_query.append(" AND ")
            temp_query.append(" A.START_DT >= " + "'" + sel_fromStart_dt + "'")
            temp_query.append(" AND ")
            temp_query.append(" A.START_DT <= " + "'" + sel_toStart_dt + "'")
        if sel_fromEnd_dt != "" and sel_toEnd_dt != "":
            temp_query.append(" AND ")
            temp_query.append(" A.END_DT >= " + "'" + sel_fromEnd_dt + "'")
            temp_query.append(" AND ")
            temp_query.append(" A.END_DT <= " + "'" + sel_toEnd_dt + "'")
        temp_query.append(" ORDER BY A.TASK_RESULT_NO DESC ")

        # if per_page is not None and page is not None:
        #     temp_query.append(" LIMIT {0}, {1}".format((page - 1) * per_page, per_page))

        # print temp_query
        query = ''.join(temp_query)
        current_app.logger.debug('get_new_task_run_list query=<%r>' % query)
        statement = session.query(
            'TASK_RESULT_NO',
            'INSTANCE_NO',
            'NODE_ID',
            'EXEC_NO',
            'TASK_ID',
            'STATUS',
            'START_DT',
            'END_DT',
            'RUNNER_ID',
            'RESULT',
            'RUN_RESULT'
        ).from_statement(query)
        current_app.logger.debug('get_new_task_run_list statement=<%r>' % str(statement))
        # result = statement.all()
        # current_app.logger.debug('result=<%r>' % result)
        # seq = 0
        result_list = list()
        result = statement.all()
        # pagination = result.paginate(page, per_page=per_page, error_out=False)
        for page_result in result:
            # seq += 1
            # list_seq = ((page - 1) * per_page) + seq
            # result_list.append({"SEQ": list_seq
            result_list.append({"TASK_RESULT_NO": page_result.TASK_RESULT_NO
                                   , "INSTANCE_NO": page_result.INSTANCE_NO
                                   , "NODE_ID": page_result.NODE_ID
                                   , "TASK_ID": page_result.TASK_ID
                                   , "EXEC_NO": page_result.EXEC_NO
                                   , "STATUS": page_result.STATUS
                                   , "START_DT": page_result.START_DT
                                   , "END_DT": page_result.END_DT
                                   , "RUNNER_ID": page_result.RUNNER_ID
                                   , "RESULT": page_result.RESULT
                                   , "RUN_RESULT": page_result.RUN_RESULT
                                })

    except Exception as e:
        raise SqlBaseException(e)
    # return pagination, stmt
    return result_list


def get_task_run_list_hts_total_count(search_condition):
    """
    SELECT TASK_RESULT_NO
         , INSTANCE_NO
         , NODE_ID
         , EXEC_NO
         , TASK_ID
         , STATUS
         , START_DT
         , END_DT
         , RUNNER_ID
         , RESULT
         , RUN_RESULT
    FROM TASK_RUN_LIST
    ORDER BY DESC TASK_RESULT_NO

    :return : 해당 페이지의 TASK_RUN_LIST 데이터
    """
    search_mode = search_condition.search_mode

    sel_task_id = str(search_condition.task_id)
    sel_result = str(search_condition.result)
    sel_okyn = str(search_condition.okyn)
    sel_node_id = str(search_condition.node_id)
    sel_runner_id = str(search_condition.runner_id)
    sel_fromStart_dt = str(search_condition.fromStart_dt)
    sel_toStart_dt = str(search_condition.toStart_dt)
    sel_fromEnd_dt = str(search_condition.fromEnd_dt)
    sel_toEnd_dt = str(search_condition.toEnd_dt)

    try:
        session = db.session

        temp_query = list()
        temp_query.append("SELECT COUNT({0}) AS {1}".format('A.TASK_RESULT_NO', 'TASK_RESULT_NO'))
        temp_query.append(" FROM TASK_RUN_LIST A ")
        temp_query.append(" WHERE A.TASK_RESULT_NO > 0 ")

        # if search_mode == "all":
        #     pass
        # else:
            # if sel_task_id != "" or sel_result != "" or sel_okyn != "" or sel_node_id != "":
        if sel_task_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.TASK_ID like " + "'%" + search_condition.task_id + "%'")
        if sel_result != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RESULT = " + "'" + search_condition.result + "'")
        if sel_okyn != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RUN_RESULT = " + "'" + search_condition.okyn + "'")
        if sel_node_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.NODE_ID like " + "'%" + sel_node_id + "%'")
        if sel_runner_id != "":
            temp_query.append(" AND ")
            temp_query.append(" A.RUNNER_ID like " + "'%" + sel_runner_id + "%'")
        if search_condition.status != "":
            temp_query.append(" AND ")
            temp_query.append(" A.STATUS = " + "'" + search_condition.status + "'")
        if sel_fromStart_dt != "" and sel_toStart_dt != "":
            temp_query.append(" AND ")
            temp_query.append(" A.START_DT >= " + "'" + sel_fromStart_dt + "'")
            temp_query.append(" AND ")
            temp_query.append(" A.START_DT <= " + "'" + sel_toStart_dt + "'")
        if sel_fromEnd_dt != "" and sel_toEnd_dt != "":
            temp_query.append(" AND ")
            temp_query.append(" A.END_DT >= " + "'" + sel_fromEnd_dt + "'")
            temp_query.append(" AND ")
            temp_query.append(" A.END_DT <= " + "'" + sel_toEnd_dt + "'")
        temp_query.append(" ORDER BY A.TASK_RESULT_NO DESC ")

        query = ''.join(temp_query)
        current_app.logger.debug('get_new_task_run_list_total_count query=<%r>' % query)

        statement = session.query(
            'TASK_RESULT_NO'
        ).from_statement(query)

        current_app.logger.debug('get_new_task_run_list_total_count statement=<%r>' % str(statement))

        result = statement.first()
        current_app.logger.debug('statement=<%r>' % str(statement))
        current_app.logger.debug('result=<%r>' % format(int(result[0]), ','))

    except Exception as e:
        raise SqlBaseException(e)

    # return pagination, stmt
    return int(result[0])

