# _*_ coding: utf-8 _*_

__author__ = 'kim youngme'

from flask import current_app, flash
from sqlalchemy import and_
# Cellar
from app import db
from app.models import OpmwTreeCatMgmt


def get_tree_ca_list():
    """
    Tree Node List 조회.

    :return tree_list:
    """
    try:
        stmt = OpmwTreeCatMgmt.query.with_entities(OpmwTreeCatMgmt.CAT_ID,
                                                   OpmwTreeCatMgmt.CAT_NM,
                                                   OpmwTreeCatMgmt.DEPTH,
                                                   OpmwTreeCatMgmt.SEQ,
                                                   OpmwTreeCatMgmt.UPPER_CAT_ID,
                                                   OpmwTreeCatMgmt.USE_YN)

        stmt = stmt.order_by(OpmwTreeCatMgmt.SEQ)

        result = stmt.all()
        tree_list = list()
        for item_result in result:
            tree_list.append({"CAT_ID": item_result.CAT_ID
                               , "CAT_NM": item_result.CAT_NM
                               , "UPPER_CAT_ID": item_result.UPPER_CAT_ID
                               , "DEPTH": item_result.DEPTH
                            })
        return tree_list
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None


def get_tree_node_list():
    """
    트리 노드 목록 조회

    :return tree_node_list:
    """
    try:
        session = db.session
        temp_query = list()
        temp_query.append("SELECT CAT_ID, CAT_NM, UPPER_CAT_ID, DEPTH ")
        temp_query.append(" FROM TREE_CAT_MGMT ")
        temp_query.append(" WHERE USE_YN = 'Y' ")
        temp_query.append(" UNION ")
        temp_query.append(" SELECT CONCAT('node_',ND.NODE_ID) as CAT_ID, ND.NODE_ID as CAT_NM, ")
        temp_query.append(" ND.CAT_ID as UPPER_CAT_ID, (CA.DEPTH + 1) as DEPTH ")
        temp_query.append(" FROM TREE_NODE_MGMT ND, TREE_CAT_MGMT CA ")
        temp_query.append(" WHERE ND.CAT_ID = CA.CAT_ID ")

        query = ''.join(temp_query)
        current_app.logger.debug('get_tree_node_list query=<%r>' % query)
        statement = session.query(
            'CAT_ID',
            'CAT_NM',
            'UPPER_CAT_ID',
            'DEPTH'
        ).from_statement(query)
        current_app.logger.debug('get_tree_node_list statement=<%r>' % str(statement))

        ca_node_list = list()
        result = statement.all()
        tree_node_list = list()
        for item_result in result:
            tree_node_list.append({"CAT_ID": item_result.CAT_ID
                                 , "CAT_NM": item_result.CAT_NM
                                 , "UPPER_CAT_ID": item_result.UPPER_CAT_ID
                                 , "DEPTH": item_result.DEPTH
                              })
        return tree_node_list
    except Exception as e:
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))
        return None
