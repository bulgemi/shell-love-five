# _*_ coding: utf-8 _*_

__author__ = 'kim kyung hee'

# flask
from flask import current_app, flash
# Cellar
from app import db
from datetime import datetime
# DAO
from app.models import OpmwTaskRunList, OpmwTaskRunListDtl
from app.cellarerror.sqlerror import SqlBaseException
from app.opmw.dao.get_task_run_list import get_exec_no_maxval


def save_dailycheck_result_list_dtl(task_result_list, task_result_no):
    """
    TASK_RUN_LIST_DTL (Task수행결과 상세) 테이블 insert 처리.

    :param task_result_list:
    :param task_result_no:
    :return:
        True or False
    """
    CLCD_TITLE = str(current_app.config['OPMATE_CLCD_TITLE'])
    CLCD_RESULT = str(current_app.config['OPMATE_CLCD_RESULT'])
    CLCD_VALUE = str(current_app.config['OPMATE_CLCD_VALUE'])

    DEPTH_TITLE = current_app.config['OPMATE_DEPTH_TITLE']
    DEPTH_RESULT = current_app.config['OPMATE_DEPTH_RESULT']
    DEPTH_VALUE = current_app.config['OPMATE_DEPTH_VALUE']

    # insert Data to TASK_RUN_LIST_DTL
    result_index = 1
    result_okyn = 'Y'

    try:
        for result_dic in task_result_list:
            t_result_data = OpmwTaskRunListDtl()
            t_result_data.TASK_RESULT_NO = task_result_no
            t_result_data.DATA_TYP_CL_CD = CLCD_TITLE
            t_result_data.SEQ = result_index
            t_result_data.DEPTH = DEPTH_TITLE
            t_result_data.ITM_VAL = result_dic["title"].encode('utf-8')

            print task_result_no, CLCD_TITLE, result_index, DEPTH_TITLE, result_dic["title"]
            insert_dailycheck_result(t_result_data)

            r_result_data = OpmwTaskRunListDtl()
            r_result_data.TASK_RESULT_NO = task_result_no
            r_result_data.DATA_TYP_CL_CD = CLCD_RESULT
            r_result_data.SEQ = result_index
            r_result_data.DEPTH = DEPTH_RESULT
            r_result_data.ITM_VAL = result_dic["result"].encode('utf-8')

            print result_dic["result"], task_result_no, CLCD_RESULT, result_index, DEPTH_RESULT
            insert_dailycheck_result(r_result_data)

            v_result_data = OpmwTaskRunListDtl()
            v_result_data.TASK_RESULT_NO = task_result_no
            v_result_data.DATA_TYP_CL_CD = CLCD_VALUE
            v_result_data.SEQ = result_index
            v_result_data.DEPTH = DEPTH_VALUE

            v_result_data.ITM_VAL = str(result_dic["value"])[0:4000].encode('utf-8')
            print result_dic["value"], task_result_no, CLCD_VALUE, result_index, DEPTH_VALUE
            insert_dailycheck_result(v_result_data)
            result_index += 1

    except Exception as e:
        current_app.logger.error("args=[%r], message=[%r]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        return False
    finally:
        return True


# 2018.11.07 KYM added.
def save_task_run_list(task_id, instance_no, node_id, runner_id):
    """
    Ondemand 수행 시 초기데이터 저장 (TASK_RUN_LIST table)

    :param task_id:
    :param instance_no:
    :param node_id:
    :param runner_id:
    :return:
        True or False
        task_result_no
    """
    try:
        max_exec_no = get_exec_no_maxval(task_id, instance_no, node_id)

        t_result_data = OpmwTaskRunList()
        t_result_data.INSTANCE_NO = instance_no
        t_result_data.TASK_ID = task_id
        t_result_data.NODE_ID = node_id
        t_result_data.EXEC_NO = max_exec_no + 1
        t_result_data.STATUS = 'C'  # 상태 : C(Request)
        # t_result_data.START_DT = 'N/A'
        t_result_data.START_DT = datetime.now().strftime("%Y%m%d%H%M%S")
        t_result_data.END_DT = 'N/A'
        if runner_id is not None:
            t_result_data.RUNNER_ID = runner_id

        t_result_data.RESULT = 'N'  # 수행결과 : N(N/A)

        task_result_no = insert_dailycheck_run_list(t_result_data)
        current_app.logger.debug("######## task_result_no : [%r] instance_no : [%r] runner_id : [%r] max_exec_no : [%d]" % (task_result_no, t_result_data.INSTANCE_NO, t_result_data.RUNNER_ID, t_result_data.EXEC_NO))

    except Exception as e:
        current_app.logger.error("args=[%r], message=[%r]" % (e.args, e.message))
        return False, None

    return True, task_result_no


# 2018.11.20 KYM added.
def save_dailycheck_result_error(task_result_no, result_msg):
    """
    일일점검 결과 중 에러 내용이 있을 경우 저장(TASK_RUN_LIST_DTL table)
    :param task_result_no:
    :param result_msg:
    :return:
        True or False
    """
    try:
        clcd_error = str(current_app.config['OPMATE_CLCD_ERROR'])
        t_error_data = OpmwTaskRunListDtl()

        t_error_data.TASK_RESULT_NO = task_result_no
        t_error_data.DATA_TYP_CL_CD = clcd_error
        t_error_data.SEQ = 1
        t_error_data.DEPTH = 4  # DEPTH가 4일 경우 Error 을 의미
        t_error_data.ITM_VAL = result_msg

        insert_dailycheck_result(t_error_data)

    except Exception as e:
        current_app.logger.error("args=[%r], message=[%r]" % (e.args, e.message))
        return False

    return True


def insert_dailycheck_result(task_result):
    """
        TASK_RUN_LIST_DTL (Task수행결과 상세) 테이블 insert 처리.

        :param task_result_list:
        :return:
            True or False
    """
    # Insert Data to TASK_RUN_LIST_DTL
    try:
        db.session.add(task_result)  # TASK_RUN_LIST_DTL
        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()

        return False
    return True


# 2018.11.07 KYM modified
def insert_dailycheck_run_list(task_result):
    """
        TASK_RUN_LIST (Task수행결과) 테이블 insert 처리.

        :param task_result:
        :return:
            True or False
    """
    # Insert Data to TASK_RUN_LIST
    try:
        db.session.add(task_result)  # TASK_RUN_LIST
        # db.session.flush()
        db.session.commit()
        db.session.refresh(task_result)
        task_result_no = task_result.TASK_RESULT_NO

    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()
        return None

    return task_result_no
