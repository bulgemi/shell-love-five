# _*_ coding: utf-8 _*_

__author__ = 'kim kyung hee'

# flask
from flask import current_app, flash
# Cellar
from app import db
from datetime import datetime
# DAO
from app.models import OpmwTaskRunList, OpmwTaskRunListDtl
from app.opmw.dao.insert_task_run_list import insert_dailycheck_run_list


def update_dailycheck_result_okyn(task_result_no, okyn, viewrun_result_list):
    """
        TASK_RUN_LIST (Task수행결과 상세) 테이블 RUN_RESULT update 처리.

        :param task_result_no:
        :param okyn
        :param viewrun_result_list
        :return:
            True or False
    """
    runresult_map = {
        'Request': 'C',
        'Fail': 'F',
        'Complete': 'S',
        'Ready': 'R',
        'N/A': 'N',
        'Success': 'S',
        'Check': 'N',
        'OK': 'Y'
    }

    try:
        update_result = OpmwTaskRunList.query \
            .filter(OpmwTaskRunList.TASK_RESULT_NO == task_result_no) \
            .first()

        update_result.RUN_RESULT = okyn

        # 2018.11.07 KYM added.
        update_result.STATUS = runresult_map[viewrun_result_list['status']]
        update_result.START_DT = viewrun_result_list['startDt']
        update_result.END_DT = viewrun_result_list['endDt']
        update_result.RESULT = runresult_map[viewrun_result_list['resultCd']]
        update_result.EXIT_CD = viewrun_result_list['exitCd']

        current_app.logger.debug("task_result_no=<%r> okyn=<%r>" % (str(task_result_no), okyn))
        current_app.logger.debug("update_result.RUN_RESULT=<%r>" % update_result.RUN_RESULT)
        current_app.logger.debug("update_result.STATUS=<%r>" % update_result.STATUS)
        current_app.logger.debug("update_result.START_DT=<%r>" % update_result.START_DT)
        current_app.logger.debug("update_result.END_DT=<%r>" % update_result.END_DT)
        current_app.logger.debug("update_result.RESULT=<%r>" % update_result.RESULT)
        current_app.logger.debug("update_result.EXIT_CD=<%r>" % update_result.EXIT_CD)
        # current_app.logger.debug("OpmwTaskRunList.TASK_RESULT_NO type=<%r>" % type(OpmwTaskRunList.TASK_RESULT_NO))
        db.session.commit()

    except Exception as e:
        current_app.logger.error("args=[%r], message=[%r]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        return False
    finally:
        return True


def insert_dailycheck_result(task_result):
    """
        TASK_RUN_LIST_DTL (Task수행결과 상세) 테이블 insert 처리.

        :param task_result_list:
        :return:
            True or False
    """
    # Insert Data to TASK_RUN_LIST_DTL
    try:
        db.session.add(task_result)  # TASK_RUN_LIST_DTL
        db.session.commit()
    except Exception as e:
        current_app.logger.error(u"args=[%s], message=[%s]" % (e.args, e.message))
        db.session.rollback()

        return False
    return True


# 2018.11.20 KYM added.
def update_dailycheck_result_error(task_result_no):
    """
        일일점검 수행 중 오류 발생 시 TASK_RUN_LIST (Task수행결과 상세) 테이블 update 처리.

        :param task_result_no:
        :return:
            True or False
    """

    try:
        update_result = OpmwTaskRunList.query \
            .filter(OpmwTaskRunList.TASK_RESULT_NO == task_result_no) \
            .first()

        update_result.STATUS = 'F'  # 상태 : F(Fail)
        update_result.END_DT = datetime.now().strftime("%Y%m%d%H%M%S")
        update_result.RESULT = 'F'  # 결과 : F(Fail)

        current_app.logger.debug("task_result_no=<%r>" % str(task_result_no))
        current_app.logger.debug("update_result.STATUS=<%r>" % update_result.STATUS)
        current_app.logger.debug("update_result.END_DT=<%r>" % update_result.END_DT)
        current_app.logger.debug("update_result.RESULT=<%r>" % update_result.RESULT)

        # current_app.logger.debug("OpmwTaskRunList.TASK_RESULT_NO type=<%r>" % type(OpmwTaskRunList.TASK_RESULT_NO))
        db.session.commit()

    except Exception as e:
        current_app.logger.error("args=[%r], message=[%r]" % (e.args, e.message))
        flash(u"args=[%s], message=[%s]" % (e.args, e.message))

        return False

    finally:
        return True
