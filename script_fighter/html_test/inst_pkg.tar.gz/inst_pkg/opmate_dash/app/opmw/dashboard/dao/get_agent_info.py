# _*_ coding: utf-8 _*_

from flask import current_app
# Cellar DAO
from sqlalchemy import func, text

from app.models import OpmwNodeList
from app.cellarerror.sqlerror import SqlBaseException


def get_agent_list():
    """
    OpMate로부터 가져온 노드의 정보들을 조회한다.
    :return:
    """

    try:

        stmt = OpmwNodeList.query.with_entities(OpmwNodeList.NODE_ID,
                                                OpmwNodeList.HEARTBEAT_DT,
                                                OpmwNodeList.STATUS)
        result = stmt.all()

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]"
                                 % (e.args, e.message))
        raise SqlBaseException(e)

    return result
