# _*_ coding: utf-8 _*_

from flask import current_app
# Cellar DAO
from sqlalchemy import func, text

from app.models import OpmwTaskRunList, OpmwTaskMgmt
from app.cellarerror.sqlerror import SqlBaseException
from app import db


def get_task_id_list():
    """
    대시보드 화면에 노출시킬 func_cl_cd, task_id를 가져온다.
    :return:
    """

    try:
        flag = 'Y'

        result = OpmwTaskMgmt.query \
            .with_entities(OpmwTaskMgmt.WIDGET_ID,
                           OpmwTaskMgmt.TASK_ID) \
            .filter(OpmwTaskMgmt.VIEW_YN == str(flag))

        task_id_list = dict()

        for row in result:
            task_id_list[row[0]] = row[1]

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]"
                                 % (e.args, e.message))
        raise SqlBaseException(e)

    return task_id_list


'''
def get_exec_no_maxval(task_id):
    """
    특정 태스크 인스턴스 번호에 대한 exec_no 의 MAX 값을 가져온다.
    :param task_id:
    :return:
        exec_no
    """

    exec_no = None

    try:
        exec_no = db.session.query(func.max(OpmwTaskRunList.EXEC_NO))\
            .filter(OpmwTaskRunList.TASK_ID == task_id)\
            .group_by(OpmwTaskRunList.TASK_ID).all()

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]"
                                 % (e.args, e.message))
        raise SqlBaseException(e)

    return exec_no[0]
'''


def get_ins_no_maxval(task_id):
    """
    특정 태스크ID에 대한 instance_no 의 MAX 값을 가져온다.
    :param task_id:
    :return:
        instance_no
    """

    instance_no = None

    try:
        instance_no = db.session.query(func.max(OpmwTaskRunList.INSTANCE_NO))\
            .filter(OpmwTaskRunList.TASK_ID == task_id)\
            .group_by(OpmwTaskRunList.TASK_ID).all()

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]"
                                 % (e.args, e.message))
        raise SqlBaseException(e)

    return instance_no[0]


# 2018.11.14 KYM modified. parameter 변경
# def get_task_run_count(task_id, exec_no):
def get_task_run_count(instance_no):
    """
    특정 태스크 수행결과의 각 건수를 가져온다.
    :param instance_no:
    :return:
        result
    """
    result = None

    try:

        sql = text("SELECT SUM(IF(A.RESULT='S' && A.RUN_RESULT='Y', 1, 0)) AS cnt_success \n"
                   "     , SUM(IF(A.RESULT='S' && A.RUN_RESULT='N', 1, 0)) AS cnt_check \n"
                   "     , SUM(IF(A.RESULT='N', 1, 0)) AS cnt_none \n"
                   "     , SUM(IF(A.RESULT='F', 1, 0)) AS cnt_fail \n"
                   "FROM TASK_RUN_LIST A \n"
                   "   , ( \n"
                   "         SELECT INSTANCE_NO \n"
                   "              , NODE_ID \n"
                   "              , MAX(EXEC_NO) AS EXEC_NO \n"
                   "         FROM TASK_RUN_LIST \n"
                   "         WHERE INSTANCE_NO = %r \n"
                   "         GROUP BY NODE_ID \n"
                   "     ) B \n"
                   "WHERE A.INSTANCE_NO = B.INSTANCE_NO \n"
                   "AND   A.NODE_ID = B.NODE_ID \n" 
                   "AND   A.EXEC_NO = B.EXEC_NO" % (int(instance_no)))

        current_app.logger.debug(sql)
        result = db.engine.execute(sql).fetchall()

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]"
                                 % (e.args, e.message))
        raise SqlBaseException(e)

    return result
