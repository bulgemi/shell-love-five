# _*_ coding: utf-8 _*_

from flask import current_app
# Cellar DAO
from app.models import TomsMigHist
from app.cellarerror.sqlerror import SqlBaseException


def get_toms_mig_hist_data():
    """
    TOMS 연동 정보 테이블에서 최근 연동 정보를 반환한다.
    :return:
    """
    result = None

    try:
        # 최근 TOMS 연동 정보 조회.
        result = TomsMigHist.query\
            .with_entities(TomsMigHist.INIT_DTM,
                           TomsMigHist.DONE_DTM,
                           TomsMigHist.STATUS)\
            .order_by(TomsMigHist.INIT_DTM.desc()).first()

        # current_app.logger.debug("result[0]=<%r>" % result[0])
        # current_app.logger.debug("result[1]=<%r>" % result[1])
        # current_app.logger.debug("result[2]=<%r>" % result[2])

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]"
                                 % (e.args, e.message))
        raise SqlBaseException(e)

    return result
