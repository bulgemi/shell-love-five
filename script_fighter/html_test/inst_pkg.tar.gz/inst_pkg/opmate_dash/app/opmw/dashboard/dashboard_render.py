# _*_ coding: utf-8 _*_
"""
=======================================================================================================================
:mod: `대시보드 화면`
=======================================================================================================================
.. moduleauthor:: 김영미 <youngme_kim@sk.com>

설명
=====
일일점검 결과, OpMate Agent 상태 정보 등의 현황 대시보드 제공
"""
__author__ = 'kim dong-hun'

from flask import Blueprint, render_template, request, current_app, flash, jsonify
from app.cellarerror.sqlerror import SqlBaseException
# Cellar
from app import get_login_session, login_required
# Dashboard DAO
from dao.get_toms_mig_hist import get_toms_mig_hist_data
from dao.get_task_run_info import get_task_id_list, get_task_run_count, get_ins_no_maxval
from dao.get_agent_info import get_agent_list
#from app.taskqueue.task_opmw_ondemand import run_job
from app.taskqueue.task_opmw_daily import run_job
# MPCR DAO


opmw_dashboard = Blueprint('opmw_dashboard', __name__, template_folder='templates')


@opmw_dashboard.route('/', methods=["GET", "POST"])
def opmw_dashboard_from():
    """
    대시보드
    :return:
    """
    # current_app.logger.debug("call task_opmw_ondemand queue = <%r>" % run_job("kym_task01", 2555, "skt_agent03", "youngme_kim@sk.com"))
    # current_app.logger.debug("call task_opmw_daily queue = <%r>" % run_job("kym_task01"))

    html_file = 'opmw/dashboard.html'

    return render_template(html_file, menu_active="opmw", login_info=get_login_session())


@opmw_dashboard.route('/dashboard/sync_system')
def sync_system():
    try:
        result_sync_system = get_toms_mig_hist_data()

        if len(result_sync_system) <= 0:
            current_app.logger.error(u"TOMS 연동정보 조회 중 오류가 발생했습니다.")
            return jsonify({
                                "status": "#ERROR#"
                            })

        status = result_sync_system[2]

        # current_app.logger.debug("sync_time=<%r>" % sync_time)
        # current_app.logger.debug("running_time=<%r>" % running_time)
        current_app.logger.debug("status=<%r>" % status)

    except SqlBaseException:
        current_app.logger.error(u"TOMS 연동정보 조회 중 오류가 발생했습니다.")
        return jsonify({
                            "status": "#ERROR#"
                        })

    result = {
                "status": status.encode('utf-8')
            }

    current_app.logger.debug("result=<%r>" % result)
    return jsonify(result)


@opmw_dashboard.route('/dashboard/count_dailycheck')
def count_dailycheck_result():

    try:
        task_id_list = get_task_id_list()

        '''
        # linux
        task_id_linux = task_id_list['SMR_U_0001']
        # exec_no_linux = get_exec_no_maxval(task_id_linux)
        ins_no_linux = get_ins_no_maxval(task_id_linux)
        linux = get_task_run_count(ins_no_linux[0])
        
         # Middleware
        task_id_mw = task_id_list['SMR_U_0004']
        # exec_no_mw = get_exec_no_maxval(task_id_mw)
        ins_no_mw = get_ins_no_maxval(task_id_mw)
        mw = get_task_run_count(ins_no_mw[0])

        # DB
        task_id_db = task_id_list['SMR_U_0003']
        # exec_no_db = get_exec_no_maxval(task_id_db)
        ins_no_db = get_ins_no_maxval(task_id_db)
        db = get_task_run_count(ins_no_db[0])

        # Windows
        task_id_windows = task_id_list['SMR_U_0002']
        # exec_no_windows = get_exec_no_maxval(task_id_windows)
        ins_no_windows = get_ins_no_maxval(task_id_windows)
        windows = get_task_run_count(ins_no_windows[0])
        '''

        # linux
        if 'W_00' in task_id_list.keys():
            task_id_linux = task_id_list['W_00']
            # exec_no_linux = get_exec_no_maxval(task_id_linux)
            ins_no_linux = get_ins_no_maxval(task_id_linux)
            linux = get_task_run_count(ins_no_linux[0])
        else:
            task_id_linux = 'N/A'
            linux = [(0, 0, 0, 0)]

        # Middleware
        if 'W_02' in task_id_list.keys():
            task_id_mw = task_id_list['W_02']
            # exec_no_mw = get_exec_no_maxval(task_id_mw)
            ins_no_mw = get_ins_no_maxval(task_id_mw)
            mw = get_task_run_count(ins_no_mw[0])
        else:
            task_id_mw = 'N/A'
            mw = [(0, 0, 0, 0)]

        # DB
        if 'W_03' in task_id_list.keys():
            task_id_db = task_id_list['W_03']
            # exec_no_db = get_exec_no_maxval(task_id_db)
            ins_no_db = get_ins_no_maxval(task_id_db)
            db = get_task_run_count(ins_no_db[0])
        else:
            task_id_db = 'N/A'
            db = [(0, 0, 0, 0)]

        # Windows
        if 'W_01' in task_id_list.keys():
            task_id_windows = task_id_list['W_01']
            # exec_no_windows = get_exec_no_maxval(task_id_windows)
            ins_no_windows = get_ins_no_maxval(task_id_windows)
            windows = get_task_run_count(ins_no_windows[0])
        else:
            task_id_windows = 'N/A'
            windows = [(0, 0, 0, 0)]

        # 차트 추가 2019.05.08
        # W_04
        if 'W_04' in task_id_list.keys():
            task_id_w04 = task_id_list['W_04']
            # exec_no_windows = get_exec_no_maxval(task_id_windows)
            ins_no_w04 = get_ins_no_maxval(task_id_w04)
            w04 = get_task_run_count(ins_no_w04[0])
        else:
            task_id_w04 = 'N/A'
            w04 = [(0, 0, 0, 0)]

        # W_05
        if 'W_05' in task_id_list.keys():
            task_id_w05 = task_id_list['W_05']
            # exec_no_windows = get_exec_no_maxval(task_id_windows)
            ins_no_w05 = get_ins_no_maxval(task_id_w05)
            w05 = get_task_run_count(ins_no_w05[0])
        else:
            task_id_w05 = 'N/A'
            w05 = [(0, 0, 0, 0)]

        # Agent 상태점검 정보조회 2019.05.02
        # 1. NODE_LIST에서 DB데이터 조회
        agent_list = get_agent_list()

        # 2. agent 상태 파악 (현재 시점과 node의 heartbeat_dt가 2시간 이상 차이날 경우 오류로 표시)
        from datetime import datetime, timedelta

        normal_cnt = 0
        err_cnt = 0
        disable_cnt = 0

        for row in agent_list:
            if row[2] == 'D':  # row[2] is status
                disable_cnt += 1
            else:
                heartbeat_dt = row[1]  # 2018 08 27 17 50 49
                sel_dt = datetime(int(heartbeat_dt[:4]), int(heartbeat_dt[4:6]), int(heartbeat_dt[6:8]),
                                  int(heartbeat_dt[8:10]), int(heartbeat_dt[-4:-2]), int(heartbeat_dt[-2:]))
                now_dt = datetime.now()

                # current_app.logger.debug("sel_dt : [%s], now_dt : [%s], hour_cha : [%s]"
                #                          % (sel_dt, now_dt, (now_dt - sel_dt).total_seconds() / 3600))

                if (now_dt - sel_dt).total_seconds() / 3600 < 2:
                    normal_cnt += 1
                else:
                    err_cnt += 1

        current_app.logger.debug("normal_cnt : [%r], err_cnt : [%r], disable_cnt : [%r]"
                                 % (normal_cnt, err_cnt, disable_cnt))

    except SqlBaseException:
        current_app.logger.error(u"정보 조회 중 오류가 발생했습니다.")
        return jsonify({
                            "linux": "#ERROR#",
                            "mw": "#ERROR#",
                            "db": "#ERROR#",
                            "windows": "#ERROR#"
                        })

    result = {
                "linux": [str(cnt) for cnt in linux[0]],
                "mw": [str(cnt) for cnt in mw[0]],
                "db": [str(cnt) for cnt in db[0]],
                "windows": [str(cnt) for cnt in windows[0]],
                "task_id_linux": task_id_linux,
                "task_id_mw": task_id_mw,
                "task_id_db": task_id_db,
        "task_id_windows": task_id_windows,
        "normal_cnt": normal_cnt,
        "err_cnt": err_cnt,
        "disable_cnt": disable_cnt,
        "w04": [str(cnt) for cnt in w04[0]],
        "w05": [str(cnt) for cnt in w05[0]],
        "task_id_w04": task_id_w04,
        "task_id_w05": task_id_w05
             }

    return jsonify(result)
