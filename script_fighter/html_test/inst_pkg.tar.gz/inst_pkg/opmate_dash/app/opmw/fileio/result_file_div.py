# _*_ coding: utf-8 _*_
import os, base64
# _*_ coding: utf-8 _*_
from flask import current_app


def save_viewrun_file_div(viewrun_result):
    OPM_RET_PATH = str(current_app.config['OPMATE_RESULT_PATH'])

    result_list = list()
    viewrun_list = viewrun_result['insNodeList']
    for idx in range(0, len(viewrun_list)):
        result_dic = dict()
        result_dic['nodeId'] = viewrun_list[idx]['nodeId']
        result_dic['taskId'] = viewrun_list[idx]['taskId']
        result_dic['instanceNo'] = viewrun_list[idx]['taskInstanceNo']
        result_dic['status'] = viewrun_list[idx]['status']
        result_dic['resultCd'] = viewrun_list[idx]['resultCd']
        result_dic['execNo'] = viewrun_list[idx]['execNo']

        if 'startDt' in viewrun_list[idx]:
            result_dic['startDt'] = viewrun_list[idx]['startDt']
        else:
            result_dic['startDt'] = ""
        if 'endDt' in viewrun_list[idx]:
            result_dic['endDt'] = viewrun_list[idx]['endDt']
        else:
            result_dic['endDt'] = ""
        if 'exitCd' in viewrun_list[idx]:
            result_dic['exitCd'] = viewrun_list[idx]['exitCd']
        else:
            result_dic['exitCd'] = 0

        result_dic['stdout'] = base64.b64decode(viewrun_list[idx]['encbase64out'])
        result_dic['stderr'] = base64.b64decode(viewrun_list[idx]['encbase64err'])
        file_nm = viewrun_list[idx]['taskId'] + "__" + str(viewrun_list[idx]['taskInstanceNo']) + "__" + viewrun_list[idx]['nodeId'] + '.txt'
        filepath = OPM_RET_PATH+'/'+file_nm
        result_dic['filepath'] = filepath
        current_app.logger.debug("viewrun_div_save filepath=<%r>" % filepath)

        fp = open(filepath, 'wt')
        if viewrun_list[idx]['resultCd'] == "Success":
            fp.write(result_dic['stdout'])
        else:
            fp.write(result_dic['stderr'])
        fp.close

        result_list.append(result_dic)

    current_app.logger.debug("viewrun_div_save result_list=<%r>" % result_list)

    return result_list

def save_viewrun_result_file(viewrun_result_dic):

    fp = open(viewrun_result_dic['filepath'], 'wt')
    if viewrun_result_dic['resultCd'] == "Success":
        fp.write(viewrun_result_dic['stdout'])
    else:
        fp.write(viewrun_result_dic['stderr'])
    fp.close

    current_app.logger.debug("viewrun_result_save viewrun_result_dic=<%r>" % viewrun_result_dic)

    return True

def get_viewrun_result_list(viewrun_result):
    OPM_RET_PATH = str(current_app.config['OPMATE_RESULT_PATH'])

    result_list = list()
    viewrun_list = viewrun_result['insNodeList']
    for idx in range(0, len(viewrun_list)):
        result_dic = dict()
        result_dic['nodeId'] = viewrun_list[idx]['nodeId']
        result_dic['taskId'] = viewrun_list[idx]['taskId']
        result_dic['instanceNo'] = viewrun_list[idx]['taskInstanceNo']
        result_dic['status'] = viewrun_list[idx]['status']
        result_dic['resultCd'] = viewrun_list[idx]['resultCd']
        result_dic['execNo'] = viewrun_list[idx]['execNo']

        if 'startDt' in viewrun_list[idx]:
            result_dic['startDt'] = viewrun_list[idx]['startDt']
        else:
            result_dic['startDt'] = ""
        if 'endDt' in viewrun_list[idx]:
            result_dic['endDt'] = viewrun_list[idx]['endDt']
        else:
            result_dic['endDt'] = ""
        if 'exitCd' in viewrun_list[idx]:
            result_dic['exitCd'] = viewrun_list[idx]['exitCd']
        else:
            result_dic['exitCd'] = 0

        result_dic['stdout'] = base64.b64decode(viewrun_list[idx]['encbase64out'])
        result_dic['stderr'] = base64.b64decode(viewrun_list[idx]['encbase64err'])
        file_nm = viewrun_list[idx]['taskId'] + "__" + str(viewrun_list[idx]['taskInstanceNo']) + "__" + viewrun_list[idx]['nodeId'] + '.txt'
        filepath = OPM_RET_PATH+'/'+file_nm
        result_dic['filepath'] = filepath
        current_app.logger.debug("viewrun_div_save filepath=<%r>" % filepath)

        result_list.append(result_dic)

    current_app.logger.debug("viewrun_div_save result_list=<%r>" % result_list)

    return result_list

def delete_viewrun_result_file(filepath):
    return os.remove(filepath)

