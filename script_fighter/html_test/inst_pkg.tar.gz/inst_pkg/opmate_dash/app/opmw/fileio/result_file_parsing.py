# _*_ coding: utf-8 _*_
from flask import current_app


def dailycheck_result_parsing(file_nm):
    OPM_DLM_TITLE = str(current_app.config['OPMATE_DELIMITER_TITLE'])
    OPM_DLM_RESULT = str(current_app.config['OPMATE_DELIMITER_RESULT'])
    OPM_DLM_VALUE = str(current_app.config['OPMATE_DELIMITER_VALUE'])
    OPM_RET_PATH = str(current_app.config['OPMATE_RESULT_PATH'])

    # current_app.logger.debug("OPMATE_DELIMITER_TITLE=<%r>"%OPM_DLM_TITLE)
    # current_app.logger.debug("OPM_DLM_RESULT=<%r>"%OPM_DLM_RESULT)
    # current_app.logger.debug("OPM_DLM_VALUE=<%r>"%OPM_DLM_VALUE)
    # current_app.logger.debug("OPM_RET_PATH=<%r>"%OPM_RET_PATH)

    # result_fullpath = OPM_RET_PATH+'/'+file_nm
    current_app.logger.debug("file_nm=<%r>" % file_nm)
    result_list = []
    curr_index = 0
    value_flag = 0
    try:
        if file_nm == "":
            return current_app.logger.error("file name is null")

        rf = open(file_nm, 'r')
        lines = rf.readlines()

        for line in lines:
            if OPM_DLM_TITLE in line:   # Title
                value_flag = 0
            else:
                if value_flag == 0:
                    continue

            if value_flag == 1:   # Multi Line Value 처리
                v_items = line
                old_values = result_list[curr_index - 1]["value"]
                new_values = old_values + v_items
                result_list[curr_index - 1]["value"] = new_values
                continue
            else:
                t_items = (line.strip()).split(OPM_DLM_TITLE)           # title
                r_items = (t_items[1].strip()).split(OPM_DLM_RESULT)    # result

                if '[' in r_items[0] and ']' in r_items[0]:
                    comment_items = (r_items[0].strip()).split(']')     # @@@ 바로 뒤에 [] 가 있는경우 제거
                    r_items[0] = comment_items[1]

                if OPM_DLM_VALUE in r_items[1] or ' -' in r_items[1] or '- ' in r_items[1] :   # Value 가 있는경우
                    v_items = (r_items[1].strip()).split(' -')
                    if v_items[1].strip() is "":
                        value_flag = 1

                    items = {"title": r_items[0].strip(), "result": v_items[0].strip(), "value": v_items[1].strip()}
                else:
                    items = {"title": r_items[0].strip(), "result": r_items[1].strip(), "value": ''}   # Value 가 없는경우

            result_list.append(items)
            curr_index = len(result_list)
        rf.close()

        if(len(lines) > 0) and (len(result_list) == 0):
            rd = open(file_nm, 'r')
            stdout_dump = rd.read()
            current_app.logger.debug("stdout_dump=<%r>" % stdout_dump)
            items = {"title": "TaskResult", "result": "OK", "value": str(stdout_dump)}
            current_app.logger.debug("items=<%r>" % items)
            result_list.append(items)
            rd.close()

    except Exception as e:
        current_app.logger.error("args=[%r], message=[%r]" % (e.args, e.message))

    finally:
        return result_list

