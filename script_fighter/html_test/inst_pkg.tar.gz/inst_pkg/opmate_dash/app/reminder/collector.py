# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from datetime import datetime
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


class Collector(object):
    conn = None
    logger = None
    pool_size = None
    today = datetime.now().strftime('%Y%m%d%H%M%S')

    query_delay_task = """SELECT A.RPT_ID AS RPT_ID, A.OWNR_ID AS OWNR_ID, A.RPT_NM AS RPT_NM, """\
                       """( """ \
                       """    SELECT B.USR_NM FROM CELLAR_USER B """ \
                       """    WHERE B.USR_ID = A.OWNR_ID """ \
                       """) AS OWNR_NM, A.RPT_DUE_DTM AS RPT_DUE_DTM, A.RPT_DESC AS RPT_DESC """\
                       """FROM RPT_HIST A """\
                       """WHERE A.RPT_STAT_CD != 'RPT_S_0003' """\
                       """AND  A.RPT_STAT_CD != 'RPT_S_0005' """\
                       """AND A.RPT_DUE_DTM < {0} """\
                       """ORDER BY A.RPT_DUE_DTM """\
                       """LIMIT {1}, {2}"""

    query_rpt_hist_wrkr = """SELECT """ \
                          """( """ \
                          """    SELECT B.USR_ID FROM CELLAR_USER B """ \
                          """    WHERE B.USR_CORP_NUM = A.WRKR_ID """ \
                          """) AS USR_ID, """\
                          """( """\
                          """    SELECT C.USR_NM FROM CELLAR_USER C """\
                          """    WHERE C.USR_CORP_NUM = A.WRKR_ID """\
                          """) AS USR_NM """\
                          """FROM RPT_HIST_WRKR A """\
                          """WHERE A.RPT_ID = '{0}' """\
                          """AND A.WRK_STAT_CD = 'WRK_S_0000' """\
                          """ORDER BY A.WRKR_SEQ"""

    query_writing_task = """SELECT A.RPT_ID AS RPT_ID, A.OWNR_ID AS OWNR_ID, A.RPT_NM AS RPT_NM, """\
                         """( """ \
                         """    SELECT B.USR_NM FROM CELLAR_USER B """ \
                         """    WHERE B.USR_ID = A.OWNR_ID """ \
                         """) AS OWNR_NM """ \
                         """FROM RPT_HIST A """ \
                         """WHERE A.RPT_STAT_CD = 'RPT_S_0001' """ \
                         """OR A.RPT_STAT_CD = 'RPT_S_0002' """ \
                         """ORDER BY A.RPT_ID """ \
                         """LIMIT {0}, {1}"""

    query_count_writer = """SELECT COUNT(WRKR_ID) AS CNT FROM RPT_HIST_WRKR """\
                         """WHERE RPT_ID = '{0}'"""

    query_count_writing = """SELECT COUNT(WRKR_ID) AS CNT FROM RPT_HIST_WRKR """ \
                          """WHERE RPT_ID = '{0}' """\
                          """AND WRK_STAT_CD = 'WRK_S_0000'"""

    def __init__(self, address, port, db, user, password, pool_size, logger):
        db_uri = 'mysql+pymysql://{}:{}@{}:{}/{}'.format(user, password, address, port, db)

        self.engine = create_engine(db_uri, pool_size=pool_size, encoding='utf-8', convert_unicode=True)
        session = sessionmaker(bind=self.engine)
        self.session = session()
        self.logger = logger
        self.pool_size = pool_size

    def disconnect(self):
        self.session.close()

    def dump_query_delay_task(self):
        return self.query_delay_task

    def execute_query_delay_task(self, index, fetch_size):
        statement = self.session.query('RPT_ID', 'OWNR_ID', 'RPT_NM', 'OWNR_NM', 'RPT_DUE_DTM', 'RPT_DESC')\
            .from_statement(self.query_delay_task.format(self.today, index, fetch_size))

        # self.logger.debug('statement=<%r>' % str(statement))

        return statement.all()

    def execute_query_rpt_hist_wrkr(self, report_id):
        statement = self.session.query('USR_ID', 'USR_NM')\
            .from_statement(self.query_rpt_hist_wrkr.format(report_id))

        # self.logger.debug('statement=<%r>' % str(statement))

        return statement.all()

    def execute_query_writing_task(self, index, fetch_size):
        statement = self.session.query('RPT_ID', 'OWNR_ID', 'RPT_NM', 'OWNR_NM') \
            .from_statement(self.query_writing_task.format(index, fetch_size))

        self.logger.debug('statement=<%r>' % str(statement))

        return statement.all()

    def execute_query_count_writer(self, report_id):
        statement = self.session.query('CNT') \
            .from_statement(self.query_count_writer.format(report_id))

        self.logger.debug('statement=<%r>' % str(statement))

        return statement.first()

    def execute_query_count_writing(self, report_id):
        statement = self.session.query('CNT') \
            .from_statement(self.query_count_writing.format(report_id))

        self.logger.debug('statement=<%r>' % str(statement))

        return statement.first()
