# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import os
import sys
from datetime import datetime
from sys import exit
import argparse
import yaml
import codecs
import logging
# collector
from collector import Collector
from sender import PressMailSender, NotifyMailSender

sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))))

from app.cipher.crypto_util import AESCipher


class ConfigInfo(object):
    database = None
    FetchSize = None
    logger = logging.getLogger()
    PoolSize = None

    def __init__(self, config_file, fetch_size, pool_size):
        config_info = yaml.load(codecs.open(config_file, "r", "euc-kr"))

        logging_info = config_info['Logging']

        self.logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter(logging_info['Format'])

        if logging_info['Path'] is None:
            log_file = "./{}".format('reminder.log')
        else:
            log_file = "{}/{}".format(logging_info['Path'], 'reminder.log')

        ch = logging.FileHandler(log_file)
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        self.FetchSize = fetch_size
        self.PoolSize = pool_size

        self.database = config_info['Database']


if __name__ == '__main__':
    reload(sys)
    sys.setdefaultencoding('utf-8')
    aes = AESCipher()

    result = True

    parser = argparse.ArgumentParser(description='Task Reminder Program.')

    parser.add_argument('-c', help='config file(full path)', required=True)
    args = parser.parse_args()

    config = ConfigInfo(args.c, 100, 5)

    collector = Collector(config.database['Host'], config.database['Port'], config.database['DB'],
                          config.database['User'], aes.decrypt(config.database['Password']),
                          config.PoolSize, config.logger)

    # config.logger.debug("collector query_delay_task=<%r>" % collector.dump_query_delay_task())

    index = 0

    while True:
        query_delay_task_result = collector.execute_query_delay_task((index * config.FetchSize), config.FetchSize)

        if len(query_delay_task_result) <= 0:
            break
        else:
            index += 1

        # config.logger.debug("query_delay_task_result=<%r>" % query_delay_task_result)

        for delay_task in query_delay_task_result:
            report_id = delay_task[0]
            report_owner_id = delay_task[1]
            report_name = delay_task[2]
            report_owner_name = delay_task[3]
            report_due_date_temp = delay_task[4]
            report_desc = delay_task[5]

            due_date_time = datetime.strptime(report_due_date_temp, '%Y%m%d%H%M%S')
            report_due_date = due_date_time.strftime("%Y-%m-%d %H:%M:%S")

            config.logger.debug("report_id=<%r>, report_owner_id=<%r>"
                                % (report_id, report_owner_id))
            config.logger.debug("report_name=<%r>, report_owner_name=<%r>"
                                % (report_name, report_owner_name))
            config.logger.debug("report_due_date=<%r>, report_desc=<%r>"
                                % (report_due_date, report_desc))

            writer_list = collector.execute_query_rpt_hist_wrkr(report_id)

            for writer_info in writer_list:
                writer_id = writer_info[0]
                writer_name = writer_info[1]

                if len(writer_id) > 0:
                    press_mail_sender = PressMailSender()

                    subject = "[Cellar] {0}님, 현황조사[{1}] 작성독려 메일입니다.".format(writer_name, report_name)
                    contents = press_mail_sender.create_contents(writer_name, writer_id,
                                                                 report_owner_name, report_owner_id,
                                                                 report_name, report_id,
                                                                 report_due_date, report_desc)

                    # config.logger.debug("writer_id=<%r>, writer_name=<%r>" % (writer_id, writer_name))
                    # config.logger.debug("-----------------------------------------------------------------------------")
                    # config.logger.debug(contents)
                    # config.logger.debug("-----------------------------------------------------------------------------")

                    press_mail_sender.send_mail(writer_id, subject, contents)
                    press_mail_sender.close()

    index = 0

    while True:
        query_writing_task_result = collector.execute_query_writing_task((index * config.FetchSize), config.FetchSize)

        if len(query_writing_task_result) <= 0:
            break
        else:
            index += 1

        # config.logger.debug("query_writing_task_result=<%r>" % query_writing_task_result)

        for writing_task in query_writing_task_result:
            report_id = writing_task[0]
            report_owner_id = writing_task[1]
            report_name = writing_task[2]
            report_owner_name = writing_task[3]

            config.logger.debug("report_id=<%r>, report_owner_id=<%r>"
                                % (report_id, report_owner_id))
            config.logger.debug("report_name=<%r>, report_owner_name=<%r>"
                                % (report_name, report_owner_name))

            writer_cnt = collector.execute_query_count_writer(report_id)

            # config.logger.debug("writer_cnt(%r)=<%r>" % (type(writer_cnt[0]), writer_cnt[0]))

            if writer_cnt[0] > 0:
                writing_cnt = collector.execute_query_count_writing(report_id)

                # config.logger.debug("writing_cnt(%r)=<%r>" % (type(writing_cnt[0]), writing_cnt[0]))

                if writing_cnt[0] <= 0:
                    notify_mail_sender = NotifyMailSender()

                    subject = "[Cellar] {0}님, 현황조사[{1}] 확인요청 메일입니다.".format(report_owner_name, report_name)
                    contents = notify_mail_sender.create_contents(report_owner_name, report_owner_id,
                                                                  report_name, report_id)

                    notify_mail_sender.send_mail(report_owner_id, subject, contents)
                    notify_mail_sender.close()

    collector.disconnect()

    if result is True:
        exit(0)
    else:
        exit(1)
