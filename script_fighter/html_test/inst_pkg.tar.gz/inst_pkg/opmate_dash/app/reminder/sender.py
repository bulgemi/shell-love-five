# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import random
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.header import Header
# attachment
# from email.mime.base import MIMEBase
# from email import encoders
from jinja2 import Template


class MailSender(object):
    def __init__(self):
        self.server = smtplib.SMTP('localhost')
        # self.server.set_debuglevel(1)
        self.from_address = 'Cellar@sk.com'
        self.msg = MIMEMultipart("alternative")

    def send_mail(self, to_address, subject, contents):
        self.msg["From"] = self.from_address
        self.msg["To"] = to_address
        self.msg["Subject"] = Header(s=subject, charset="utf-8")
        self.msg.attach(MIMEText(contents, "html", _charset="utf-8"))
        self.server.sendmail(self.from_address, [to_address], self.msg.as_string())

    def close(self):
        self.server.quit()

    def __exit__(self, *err):
        self.close()


class PressMailSender(MailSender):
    def __init__(self):
        MailSender.__init__(self)

    def create_contents(self, writer_name, writer_email,
                        reporter_name, reporter_email,
                        report_name, report_id,
                        report_due_dtm, report_desc):
        template_list = list()

        template_1 = """{{ writer_name }}({{ writer_email }})님, 안녕하세요.<br/>"""\
                     """<br/>"""\
                     """{{ reporter_name }}({{ reporter_email }})께서 요청하신 아래 현황조사 작성이 지연되고 있습니다.<br/>"""\
                     """<br/>"""\
                     """현황조사명: {{ report_name }}<br/>"""\
                     """바로가기: http://cellar.skcc.com:5000/tasks/edit_new_task/{{ report_id }}<br/>"""\
                     """완료기한: {{ report_due_dtm }}<br/>"""\
                     """설명: {{ report_desc }}<br/>"""\
                     """<br/>"""\
                     """작성 부탁드립니다.<br/>"""\
                     """<br/>"""\
                     """감사합니다.<br/>"""

        template_2 = """{{ writer_name }}({{ writer_email }})님, 안녕하세요.<br/>"""\
                     """<br/>"""\
                     """아래 현황조사 작성이 늦어져, {{ reporter_name }}({{ reporter_email }})님 이마에 주름살이 깊어지고 있습니다.<br/>"""\
                     """<br/>"""\
                     """현황조사명: {{ report_name }}<br/>"""\
                     """바로가기: http://cellar.skcc.com:5000/tasks/edit_new_task/{{ report_id }}<br/>"""\
                     """완료기한: {{ report_due_dtm }}<br/>"""\
                     """설명: {{ report_desc }}<br/>"""\
                     """<br/>"""\
                     """작성 부탁드립니다.<br/>"""\
                     """<br/>"""\
                     """감사합니다.<br/>"""

        template_3 = """{{ writer_name }}({{ writer_email }})님, 안녕하세요.<br/>"""\
                     """<br/>"""\
                     """아래 현황조사 작성이 늦어져, {{ reporter_name }}({{ reporter_email }})님의 낯빛이 어둡습니다.<br/>"""\
                     """<br/>"""\
                     """현황조사명: {{ report_name }}<br/>"""\
                     """바로가기: http://cellar.skcc.com:5000/tasks/edit_new_task/{{ report_id }}<br/>"""\
                     """완료기한: {{ report_due_dtm }}<br/>"""\
                     """설명: {{ report_desc }}<br/>"""\
                     """ <br/>"""\
                     """지금 시작하세요.<br/>"""\
                     """<br/>"""\
                     """감사합니다.<br/>"""

        template_4 = """{{ writer_name }}({{ writer_email }})님, 안녕하세요.<br/>"""\
                     """ <br/>"""\
                     """아래 현황조사 작성이 늦어져, {{ reporter_name }}({{ reporter_email }})님의 속이 타고 있습니다.<br/>"""\
                     """<br/>"""\
                     """현황조사명: {{ report_name }}<br/>"""\
                     """바로가기: http://cellar.skcc.com:5000/tasks/edit_new_task/{{ report_id }}<br/>"""\
                     """완료기한: {{ report_due_dtm }}<br/>"""\
                     """설명: {{ report_desc }}<br/>"""\
                     """<br/>"""\
                     """지금 시작하세요.<br/>"""\
                     """<br/>"""\
                     """감사합니다.<br/>"""

        template_list.append(template_1)
        template_list.append(template_2)
        template_list.append(template_3)
        template_list.append(template_4)

        template_index = random.randrange(0, 4)
        template = Template(template_list[template_index])

        contents = template.render(writer_name=writer_name, writer_email=writer_email,
                                   reporter_name=reporter_name, reporter_email=reporter_email,
                                   report_name=report_name, report_id=report_id,
                                   report_due_dtm=report_due_dtm, report_desc=report_desc)

        return contents.encode('utf-8')


class NotifyMailSender(MailSender):
    def __init__(self):
        MailSender.__init__(self)

    def create_contents(self, reporter_name, reporter_email, report_name, report_id):
        template = """{{ reporter_name }}({{ reporter_email }})님, 안녕하세요.<br/>"""\
                   """<br/>"""\
                   """현황조사명 "{{ report_name }}"({{ report_id }})에 등록된 작성자가 작업을 모두 완료하였습니다.<br/>"""\
                   """확인해보세요.<br/>"""\
                   """<br/>"""\
                   """바로가기: http://cellar.skcc.com:5000/tasks/edit_new_task/{{ report_id }}<br/>"""\
                   """<br/>"""\
                   """감사합니다.<br/>"""

        template = Template(template)

        contents = template.render(reporter_name=reporter_name, reporter_email=reporter_email,
                                   report_name=report_name, report_id=report_id)

        return contents.encode('utf-8')
