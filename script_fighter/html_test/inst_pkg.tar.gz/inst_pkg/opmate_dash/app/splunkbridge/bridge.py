# _*_ coding: utf-8 _*_
__author__ = 'kim dong-hun'

import time
import sys
import splunklib.client as client
import splunklib.results as results


def output(stream):
    """Write the contents of the given stream to stdout."""
    while True:
        content = stream.read(1024)

        if len(content) == 0:
            break
        sys.stdout.write(content)


def connect_splunk(username, password, host='localhost', port=8089):
    """
    통품감 Splunk에 접속한다.

    :param username:
    :param password:
    :param host:
    :param port:
    :return:
    """
    service = client.connect(username=username, password=password, host=host, port=port)

    return service


def cancel_splunk(job):
    """
    통품감 Splunk job 을 취소한다.
    :param job:
    :return:
    """
    job.cancel()


class SplunkBridge(object):
    def __init__(self, service):
        self.service = service

    def search_log(self, macro_name, flag='search', **kwargs):
        """
        통품감 Splunk 에 질의한 후, 결과를 받아온다.

        :param macro_name:
        :param flag:
        :param kwargs:
        :return:
        """
        query_output = list()
        query_message = list()

        query = "{} {}".format(flag, macro_name)
        sid = self.service.search(query, **kwargs).sid
        job = self.service.job(sid)

        while not job.is_done():
            time.sleep(1)

        reader = results.ResultsReader(job.results())

        for result in reader:
            if isinstance(result, dict):
                query_output.append(result)
            elif isinstance(result, results.Message):
                query_message.append(result)

        return query_output, query_message

    def search_one_shot(self, macro_name, flag='search'):
        """
        통품감 Splunk 에 one shot 질의한 후, 결과를 받아온다.

        :param macro_name:
        :param flag:
        :return:
        """
        query_output = list()
        query_message = list()
        kwargs_oneshot = {"count": 0}

        query = "{} {}".format(flag, macro_name)
        search_results = self.service.jobs.oneshot(query, **kwargs_oneshot)

        reader = results.ResultsReader(search_results)

        for result in reader:
            if isinstance(result, dict):
                query_output.append(result)
            elif isinstance(result, results.Message):
                query_message.append(result)

        return query_output, query_message
