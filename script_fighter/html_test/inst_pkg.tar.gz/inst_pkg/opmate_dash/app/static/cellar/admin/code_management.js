// code_management.js

// 공통코드 관리 조회
function f_searchCodeGroupList() {
    var btn = document.getElementById("btn")
    var form = document.getElementById("f_code_management")

    btn.value = 'search';

    form.submit();
    return;
};

// 공통코드그롭 추가
function f_insertRow_g() {

    var newData = {
        "comm_cd_id" : "new",
        "comm_cd_nm" : "",
        "comm_cd_desc" : ""
    };

    $('#grid_list').alopexGrid('dataAdd', $.extend({
        _state : {
            editing: true,
            selected: true
        }
    },newData));

    return;
};

// 공통코드그룹 삭제
function f_deleteRow_g() {

    // 삭제대상 선택여부 확인
    var chk_num = 0
    var dataList = $('#grid_list').alopexGrid('dataGet', {_state:{selected:true}});
    chk_num = dataList.length;

    if(chk_num == 0){
        alert("삭제할 행을 체크해주세요.");
        return false;
    }

    if (confirm("삭제하시겠습니까?") == false) {
        return false;
    }


    var btn = document.getElementById("btn")
    var form = document.getElementById("f_code_management")

    btn.value = 'delete_group';

    var grid_list = $('#grid_list').alopexGrid('dataGet', {_state:{selected:true}});
    var str_group_list = JSON.stringify(grid_list);

    var save_group_list = document.createElement('input');
    save_group_list.setAttribute('type', 'hidden');
    save_group_list.setAttribute('name', 'save_group_list');
    save_group_list.setAttribute('value', str_group_list);

    form.appendChild(save_group_list);

    form.submit();
    return;
};


// 코드상세목록 추가
function f_insertRow_d() {

    var newData = {
        "comm_cd_val" : "new",
        "comm_cd_val_nm" : "",
        "comm_cd_val_eng_nm" : "",
        "comm_cd_val_desc" : ""
    };

    $('#grid_dtl').alopexGrid('dataAdd', $.extend({
        _state : {
            editing: true,
            selected: true
        }
    },newData));

    return;
};

// 코드상세목록 삭제
function f_deleteRow_d() {

    // 삭제대상 선택여부 확인
    var chk_num = 0
    var dataList = $('#grid_dtl').alopexGrid('dataGet', {_state:{selected:true}});
    chk_num = dataList.length;

    if(chk_num == 0){
        alert("삭제할 행을 체크해주세요.");
        return false;
    }

    if (confirm("삭제하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn")
    var form = document.getElementById("f_code_management")

    btn.value = 'delete_detail';

    var grid_dtl = $('#grid_dtl').alopexGrid('dataGet', {_state:{selected:true}});
    var str_dtl_list = JSON.stringify(grid_dtl);

    var save_dtl_list = document.createElement('input');
    save_dtl_list.setAttribute('type', 'hidden');
    save_dtl_list.setAttribute('name', 'save_dtl_list');
    save_dtl_list.setAttribute('value', str_dtl_list);

    form.appendChild(save_dtl_list);

    form.submit();
    return;
};

// 공통코드관리 저장
function f_saveCommCode() {
    if (confirm("저장하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn");
    var form = document.getElementById("f_code_management");

    btn.value = 'save';

    var grid_list = AlopexGrid.currentData($('#grid_list').alopexGrid('dataGet',
        {_state: {edited:true}}, {_state:{selected:true}}, {_state:{editing:true}}
    ));
    var grid_dtl = AlopexGrid.currentData($('#grid_dtl').alopexGrid('dataGet',
        {_state: {edited:true}}, {_state:{selected:true}}, {_state:{editing:true}}
    ));
    var str_group_list = JSON.stringify(grid_list);
    var str_dtl_list = JSON.stringify(grid_dtl);

    var save_group_list = document.createElement('input');
    save_group_list.setAttribute('type', 'hidden');
    save_group_list.setAttribute('name', 'save_group_list');
    save_group_list.setAttribute('value', str_group_list);

    var save_dtl_list = document.createElement('input');
    save_dtl_list.setAttribute('type', 'hidden');
    save_dtl_list.setAttribute('name', 'save_dtl_list');
    save_dtl_list.setAttribute('value', str_dtl_list);

    form.appendChild(save_group_list);
    form.appendChild(save_dtl_list);

    form.submit();
    return;
};

// 공통코드 선택
function f_groupCodeClick(cb, index) {
    var chk_id = "group_code_yn_" + index;
    var chk_yn = document.getElementById(chk_id);

    if (cb.checked == true) {
        chk_yn.value = 'y';
    }
    else {
        chk_yn.value = 'n';
    }

    //alert(chk_id + ", " + chk_yn.value);
    return;
};

// 공통상세코드 선택
function f_groupCodeDtlClick(cb, index) {
    var chk_id = "group_code_dtl_yn_" + index;
    var chk_yn = document.getElementById(chk_id);

    if (cb.checked == true) {
        chk_yn.value = 'y';
    }
    else {
        chk_yn.value = 'n';
    }

    //alert(chk_id + ", " + chk_yn.value);
    return;
};

// 공통코드 '수정' 버튼 제어
function f_edit_g() {

    $('#grid_list').alopexGrid('updateOption',{cellInlineEdit: true});
    $('#bt_edit_g').attr('class', 'Button opmate-btn__typeb:hover');

    return;
};

// 공통상세코드 '수정' 버튼 제어
function f_edit_d() {

    $('#grid_dtl').alopexGrid('updateOption',{cellInlineEdit: true});
    $('#bt_edit_d').attr('class', 'Button opmate-btn__typeb:hover');

    return;
};


// 공통코드 상세
function getDetail(cd_id) {
    var btn = document.getElementById("btn");
    var comm_cd_id = document.getElementById("comm_cd_id");

    btn.value = 'search';
    comm_cd_id.value = cd_id;

    var form = document.getElementById("f_code_management");

    form.submit();
    return;
};
