// code_management.js

function f_makeGrid(data_list, data_dtl) {

    $('#grid_list').alopexGrid({
        height: 530,
        pager: true,
        paging: {
            perPage: 20,
            pagerCount: 5,
            pagerTotal: true
        },
        autoColumnIndex: true,
        cellSelectable: true,
        filteringHeader: true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        columnMapping : [
            {
                align : 'center',
                key : 'check',
                width : '30px',
                selectorColumn : true
            }, {
                key : 'comm_cd_id',
                title : '그룹ID',
                width : '100px',
                align : 'center',
                editable: false
            }, {
                key : 'comm_cd_nm',
                title : '그룹명',
                width : '100px',
                align : 'center',
                editable: true
            }, {
                key : 'comm_cd_desc',
                title : '설명',
                width : '300px',
                align : 'center',
                editable: true
            }
        ],
        data: data_list
    });

    $('#grid_dtl').alopexGrid({
        height: 470,
        autoColumnIndex: true,
        cellSelectable: true,
        filteringHeader: true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        columnMapping : [
            {
                align : 'center',
                key : 'check',
                width : '30px',
                selectorColumn : true
            },
            {
                key : 'comm_cd_val',
                title : '코드ID',
                width : 150,
                align : 'center',
                editable: false
            }, {
                key : 'comm_cd_val_nm',
                title : '코드한글명',
                width : 150,
                align : 'center',
                editable: true
            }, {
                key : 'comm_cd_val_eng_nm',
                title : '코드영문명',
                width : 150,
                align : 'center',
                editable: true
            }, {
                key : 'comm_cd_val_desc',
                title : '설명',
                width : 250,
                align : 'center',
                editable: true
            }
        ],
        data: data_dtl
    });

    $('#grid_list').on('click', function(e) {
        var evObj = AlopexGrid.parseEvent(e);
        var dataObj = evObj.data;

        if(evObj.mapping.key == 'comm_cd_id') {
            var rowData = $("#grid_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });
            comm_cd_id = rowData['comm_cd_id'];
            getDetail(comm_cd_id);
        }

    });

};

