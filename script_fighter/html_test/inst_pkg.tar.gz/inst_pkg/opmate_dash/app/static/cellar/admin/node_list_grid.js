// task_setting_grid.js

function f_makeGrid(data_node_list) {

    $('#node_grid').alopexGrid({
        height: 372,
        pager: true,
        paging: {
         //   perPage: 10,
        //    pagerCount: 5,
            pagerTotal: true
        },
        autoColumnIndex: true,
        cellSelectable: true,
        filteringHeader: true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        columnMapping : [
            {
                align : 'center',
                key : 'check',
                width : '43px',
                selectorColumn : true
            },
            {
                align : 'center',
                key : 'NODE_ID',
                title : '노드ID',
                width : '260px',
                //align : 'center',
                editable: true
            },
            {
                align : 'center',
                key : 'OS_NAME',
                title : 'OS명',
                width : '270px',
                //align : 'center',
                editable: true
            },
            {
                align : 'center',
                key : 'IP',
                title : 'IP',
                width : '270px',
                //align : 'center',
                editable: true
            }
        ],
        data: data_node_list
    });

};

function f_close() {
    $a.close();
};

function f_searchNodeID() {
    var btn = document.getElementById("btn");
    var form = document.getElementById("f_node_list");

    btn.value = 'search';

    form.submit();
    return;
};

function f_choice() {
    // 삭제대상 선택여부 확인
    var chk_num = 0
    var dataList = $('#node_grid').alopexGrid('dataGet', {_state:{selected:true}});
    chk_num = dataList.length;

    if(chk_num == 0){
        alert("추가할 노드를 체크해주세요.");
        return false;
    }

    $a.close(dataList);
};