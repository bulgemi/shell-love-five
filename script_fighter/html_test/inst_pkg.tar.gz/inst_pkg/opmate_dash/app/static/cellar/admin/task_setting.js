// task_setting.js

// 태스크 설정 조회
function f_searchTaskList() {
    var btn = document.getElementById("btn")
    var form = document.getElementById("f_task_setting")

    btn.value = 'search';

    form.submit();
    return;
};

// 태스크 목록 추가
function f_insertRow_t() {

    var newData = {
        "task_id": "new",
        "task_nm": "new",
        "task_desc": ""
    };

    $('#grid_task_list').alopexGrid('dataAdd', $.extend({
        _state : {
            editing: true,
            selected: true
        }
    },newData));

    return;
};

// 태스크 목록 삭제
function f_deleteRow_t() {

    // 삭제대상 선택여부 확인
    var chk_num = 0
    var dataList = $('#grid_task_list').alopexGrid('dataGet', {_state:{selected:true}});

    chk_num = dataList.length;

    if (chk_num == 0) {
        alert("삭제할 행을 체크해주세요.");
        return false;
    }

    if (confirm("삭제하시겠습니까?") == false) {
        return false;
    }


    var btn = document.getElementById("btn")
    var form = document.getElementById("f_task_setting")

    btn.value = 'delete_task_list';

    var grid_list = $('#grid_task_list').alopexGrid('dataGet', {_state:{selected:true}});
    var str_task_list = JSON.stringify(grid_list);

    var delete_task_list = document.createElement('input');

    delete_task_list.setAttribute('type', 'hidden');
    delete_task_list.setAttribute('name', 'delete_task_list');
    delete_task_list.setAttribute('value', str_task_list);

    form.appendChild(delete_task_list);

    form.submit();
    return;
};


// 재수행 가능그룹 추가
function f_insertRow_g() {

    var newData = {
        "group_name" : "new",
        "group" : "new"
    };

    $('#grid_group').alopexGrid('dataAdd', $.extend({
        _state : {
            editing: true,
            selected: true
        }
    }, newData));

    return;
};

// 재수행 가능그룹 삭제
function f_deleteRow_g() {

    // 삭제대상 선택여부 확인
    var chk_num = 0
    var dataList = $('#grid_group').alopexGrid('dataGet', {_state:{selected:true}});
    chk_num = dataList.length;

    if(chk_num == 0){
        alert("삭제할 행을 체크해주세요.");
        return false;
    }

    if (confirm("삭제하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn")
    var form = document.getElementById("f_task_setting")

    btn.value = 'delete_group_list';

    var grid_group = $('#grid_group').alopexGrid('dataGet', {_state:{selected:true}});
    var str_group_list = JSON.stringify(grid_group);

    var delete_group_list = document.createElement('input');
    delete_group_list.setAttribute('type', 'hidden');
    delete_group_list.setAttribute('name', 'delete_group_list');
    delete_group_list.setAttribute('value', str_group_list);

    form.appendChild(delete_group_list);

    form.submit();
    return;
};

// 태스크 동기화
function f_sync() {
    if (confirm("동기화를 진행하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn");
    var form = document.getElementById("f_task_setting");

    btn.value = 'sync';

    form.submit();
    return;
};

// 태스크 설정 저장
function f_save() {
    if (confirm("저장하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn");
    var form = document.getElementById("f_task_setting");

    btn.value = 'save';

    var grid_task_list = AlopexGrid.currentData($('#grid_task_list').alopexGrid('dataGet',
        {_state: {edited:true}}, {_state:{selected:true}}, {_state:{editing:true}}
    ));
    var grid_group = AlopexGrid.currentData($('#grid_group').alopexGrid('dataGet',
        {_state: {edited:true}}, {_state:{selected:true}}, {_state:{editing:true}}
    ));
    var str_task_list = JSON.stringify(grid_task_list);
    var str_group_list = JSON.stringify(grid_group);

    var save_task_list = document.createElement('input');

    save_task_list.setAttribute('type', 'hidden');
    save_task_list.setAttribute('name', 'save_task_list');
    save_task_list.setAttribute('value', str_task_list);

    var save_group_list = document.createElement('input');

    save_group_list.setAttribute('type', 'hidden');
    save_group_list.setAttribute('name', 'save_group_list');
    save_group_list.setAttribute('value', str_group_list);

    form.appendChild(save_task_list);
    form.appendChild(save_group_list);

    form.submit();
    return;
};

// 태스크 선택
function f_taskIdClick(cb, index) {
    var chk_id = "task_id_yn_" + index;
    var chk_yn = document.getElementById(chk_id);

    if (cb.checked == true) {
        chk_yn.value = 'y';
    }
    else {
        chk_yn.value = 'n';
    }

    //alert(chk_id + ", " + chk_yn.value);
    return;
};

// 재수행 가능그룹 선택
function f_groupCodeClick(cb, index) {
    var chk_id = "group_code_yn_" + index;
    var chk_yn = document.getElementById(chk_id);

    if (cb.checked == true) {
        chk_yn.value = 'y';
    }
    else {
        chk_yn.value = 'n';
    }

    //alert(chk_id + ", " + chk_yn.value);
    return;
};


// 재수행 가능그룹 조회
function getGroup(cd_id) {
    var btn = document.getElementById("btn");
    var task_id = document.getElementById("task_id");

    btn.value = 'search';
    task_id.value = cd_id;

    var form = document.getElementById("f_task_setting");

    form.submit();
    return;
};

// 태스크 목록 '수정' 제어
function f_edit_t() {
    $('#grid_task_list').alopexGrid('updateOption',{cellInlineEdit: true});
    $('#bt_edit_t').attr('class', 'Button opmate-btn__typeb:hover');
    return;
};

// 재수행 가능그룹 '수정' 제어
function f_edit_g() {
    $('#grid_group').alopexGrid('updateOption',{cellInlineEdit: true});
    $('#bt_edit_g').attr('class', 'Button opmate-btn__typeb:hover');
    return;
};
