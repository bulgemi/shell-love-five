// task_setting_grid.js

function f_makeGrid(data_task_list, data_group_list, group_info) {

    $('#grid_task_list').alopexGrid({
        height: 530,
        pager: true,
        paging: {
            perPage: 20,
            pagerCount: 5,
            pagerTotal: true
        },
        autoColumnIndex: true,
        cellSelectable: true,
        filteringHeader: true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        columnMapping : [
            {
                align : 'center',
                key : 'check',
                width : '30px',
                selectorColumn : true
            }, {
                key : 'task_id',
                title : '태스크ID',
                width : '200px',
                //align : 'center',
                editable: true
            }, {
                key : 'task_nm',
                title : '태스크명',
                width : '200px',
                //align : 'center',
                editable: true
            }, {
                key : 'task_desc',
                title : '설명',
                width : '100px',
                //align : 'center',
                editable: true
            }
        ],
        data: data_task_list
    });

    $('#grid_group').alopexGrid({
        height: 530,
        pager: true,
        paging: {
            perPage: 20,
            pagerCount: 5,
            pagerTotal: true
        },
        autoColumnIndex: true,
        cellSelectable: true,
        filteringHeader: true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        columnMapping : [
            {
                align : 'center',
                key : 'check',
                width : '30px',
                selectorColumn : true
            },
            {
                key : 'group_name',
                title : '그룹명',
                width : '300px',
                //align : 'center',
                editable: group_info
            }, {
                key : 'group',
                title : '그룹',
                width : '200px',
                //align : 'center',
                editable: false
            }
        ],
        data: data_group_list
    });

    $('#grid_task_list').on('click', function(e) {
        var evObj = AlopexGrid.parseEvent(e);
        var dataObj = evObj.data;

//        alert(evObj.mapping.key);

        // checkbox 이벤트 발생시
        if (evObj.mapping.key === "check") {
//            alert('check [' + dataObj._index.data + '] ColumnClicked!!!');

            var rowData = $("#grid_task_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });
            var row_state = rowData["_state"]

//            alert(row_state["selected"]);

            if (row_state["selected"] === true) { // selected
                var form_element = document.getElementById("f_task_setting");
                var input = document.createElement("input");

                input.setAttribute("type", "hidden");
                input.setAttribute("name", "selected_task_id");
                input.setAttribute("value", rowData['task_id']);

                form_element.appendChild(input);
            } else {
                var form_element = document.getElementById("f_task_setting");
                var selected_task_id_list = document.getElementsByName("selected_task_id");

                for (var l=0; l < selected_task_id_list.length; l++) {
                    if (rowData['task_id'] == selected_task_id_list[l].value) {
                        var del_e = selected_task_id_list[l];
                        form_element.removeChild(del_e);
                    }
                }

//                for (var l=0; l < selected_task_id_list.length; l++) {
//                    alert(selected_task_id_list[l].value);
//                }
            }

//            alert(document.getElementsByName("selected_task_id").length);
        }

        if (evObj.mapping.key == 'task_id' ) {
            var rowData = $("#grid_task_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });
            task_id = rowData['task_id'];

//            alert("task_id=" + task_id)

            if (task_id !== 'new') {
                getGroup(task_id);
            }
            else {
                // new row
            }
        }
    });

    $('#grid_group').on('click', function(e) {
        var evObj = AlopexGrid.parseEvent(e);
        var dataObj = evObj.data;

//        alert(evObj.mapping.key);

        // checkbox 이벤트 발생시
        if (evObj.mapping.key === "check" || evObj.mapping.key === "group_name") {
//            alert('check [' + dataObj._index.data + '] ColumnClicked!!!');

            var rowData = $("#grid_group").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });
            var row_state = rowData["_state"]

//            alert(row_state["selected"]);

            if (row_state["selected"] === true) { // selected
                var form_element = document.getElementById("f_task_setting");
                var selected_group_name = document.getElementsByName("selected_group_name");

                for (var l=0; l < selected_group_name.length; l++) {
                    if (rowData['group_name'] == selected_group_name[l].value) {
                        var del_e = selected_group_name[l];
                        form_element.removeChild(del_e);
                    }
                }

                var input = document.createElement("input");

                input.setAttribute("type", "hidden");
                input.setAttribute("name", "selected_group_name");
                input.setAttribute("value", rowData['group_name']);

//                alert(rowData['group_name']);

                form_element.appendChild(input);
            } else {
                var form_element = document.getElementById("f_task_setting");
                var selected_group_name = document.getElementsByName("selected_group_name");

                for (var l=0; l < selected_group_name.length; l++) {
                    if (rowData['group_name'] == selected_group_name[l].value) {
                        var del_e = selected_group_name[l];
                        form_element.removeChild(del_e);
                    }
                }

//                for (var l=0; l < selected_group_name.length; l++) {
//                    alert(selected_group_name[l].value);
//                }
            }

//            alert(document.getElementsByName("selected_group_name").length);
        }
    });
};

