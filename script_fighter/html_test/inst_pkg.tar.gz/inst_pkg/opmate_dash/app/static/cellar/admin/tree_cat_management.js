// code_management.js

// 공통코드 관리 조회
/*
function f_searchCodeGroupList() {
    var btn = document.getElementById("btn")
    var form = document.getElementById("f_code_management")

    btn.value = 'search';

    form.submit();
    return;
};
*/

// 트리 카테고리 추가
function f_insertRow() {

    var dataList = $('#grid_tree').alopexGrid('dataGet', {_state:{selected:true}});

    if(dataList.length == 0) {

        $('#grid_tree').alopexGrid("dataAdd",
            {"cat_nm" : "", "use_yn" : "Y"}
        );

    } else if (dataList.length == 1) {
        var parentDataIndex = dataList[0]._index.data;

        $("#grid_tree").alopexGrid("dataAdd",
            {"cat_nm" : "", "use_yn" : "Y"},
            {
                parentQuery : {_index:{data:parentDataIndex}},
            }
        );
    } else {
        alert("하나의 행만 체크해주세요.");
        return false;
    }

    return;
};

// 트리 카테고리 삭제
function f_deleteRow() {

    // 삭제대상 선택여부 확인
    var chk_num = 0
    var dataList = $('#grid_tree').alopexGrid('dataGet', {_state:{selected:true}});
    chk_num = dataList.length;

    if(chk_num == 0){
        alert("삭제할 행을 체크해주세요.");
        return false;
    }

    if (confirm("하위 노드가 존재하는 경우 모두 삭제됩니다. \n삭제하시겠습니까?") == false) {
        return false;
    }


    var btn = document.getElementById("btn")
    var form = document.getElementById("f_tree_cat_management")

    btn.value = 'delete';

    var grid_list = $('#grid_tree').alopexGrid('dataGet', {_state:{selected:true}});
    var str_tree_list = JSON.stringify(grid_list);

    var save_tree_list = document.createElement('input');
    save_tree_list.setAttribute('type', 'hidden');
    save_tree_list.setAttribute('name', 'save_list');
    save_tree_list.setAttribute('value', str_tree_list);

    form.appendChild(save_tree_list);

    form.submit();
    return;
};


// 트리 카테고리 저장
function f_save() {
    if (confirm("저장하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn");
    var form = document.getElementById("f_tree_cat_management");

    btn.value = 'save';

    var grid_list = AlopexGrid.currentData($('#grid_tree').alopexGrid('dataGet',
        {_state: {edited:true}}, {_state:{selected:true}}, {_state:{editing:true}}
    ));

//    var grid_list = $('#grid_tree').alopexGrid('dataGet',
//        {_state: {edited:true}}, {_state:{selected:true}}, {_state:{editing:true}}
//    );

    var str_list = JSON.stringify(grid_list);

    var save_list = document.createElement('input');
    save_list.setAttribute('type', 'hidden');
    save_list.setAttribute('name', 'save_list');
    save_list.setAttribute('value', str_list);

    form.appendChild(save_list);

    form.submit();

    return;
};

// 공통코드 선택
function f_groupCodeClick(cb, index) {
    var chk_id = "group_code_yn_" + index;
    var chk_yn = document.getElementById(chk_id);

    if (cb.checked == true) {
        chk_yn.value = 'y';
    }
    else {
        chk_yn.value = 'n';
    }

    //alert(chk_id + ", " + chk_yn.value);
    return;
};

// 공통상세코드 선택
function f_groupCodeDtlClick(cb, index) {
    var chk_id = "group_code_dtl_yn_" + index;
    var chk_yn = document.getElementById(chk_id);

    if (cb.checked == true) {
        chk_yn.value = 'y';
    }
    else {
        chk_yn.value = 'n';
    }

    //alert(chk_id + ", " + chk_yn.value);
    return;
};

// 공통코드 '수정' 버튼 제어
function f_edit_g() {

    $('#grid_list').alopexGrid('updateOption',{cellInlineEdit: true});
    $('#bt_edit_g').attr('class', 'Button opmate-btn__typeb:hover');

    return;
};
