// code_management.js

function f_makeGrid(data_list) {

    $('#grid_tree').alopexGrid({
        height: 470,
        autoColumnIndex: true,
        cellSelectable: true,
        cellInlineEdit: true,
        endInlineEditByOuterClick: true,
        enableDefaultContextMenu:false,
        disableTextSelection : true,
//        rowSelectOption: {
//            clickSelect: true
//        },
        //filteringHeader: true,
        useClassHovering: true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        columnMapping : [
            {
	            align : 'center',
	            key : 'check',
	            width : '30px',
	            selectorColumn : true
	        },
            {
                dragdropColumn : true,
                width : 30
            },
            {
                key : "cat_nm",
                title : "카테고리명",
                width : 150,
                treeColumn : true,
                treeColumnHeader : true,
                editable : true
            },
            {
                key : "cat_id",
                title : "카테고리ID",
            },
            {
                key : "upper_cat_id",
                title : "상위카테고리ID"
            },
            {
                key : "depth",
                title : "Depth",
                align : "center",
                width : 60
            },
            {
                key : "use_yn",
                title : "사용 여부",
                align : "center",
                width : 60,
                editable : {
                    type: 'select',
                    rule: [
                        {text:'선택하세요', value:''},
                        {text:'사용', value:'Y'},
                        {text:'미사용', value:'N'}
                    ]
                }
            }
        ],
        tree : {
            useTree : true,
            idKey : "cat_id",
            parentIdKey : "upper_cat_id",
            expandedKey : "cat_expanded",
            depthKey : "depth",
            idGenerator :
				function(id, parentId, data, parentData, idMap) {
					//ID생성에 대한 구체적인 규칙이 있을 경우 여기에 코딩합니다.
					if(parentId == null) {
						//부모가 없을경우 A 없이 숫자만 들어감.
						return (id != null) ? (parseInt(id) + 1) : "1";
					}
					var childArr = (id == null) ? [] : id.split("C");
					var parentArr = parentId.split("C");
					if(childArr.length === parentArr.length+1) {
						childArr[childArr.length-1] = parseInt(childArr[childArr.length-1]) + 1;
						return childArr.join("C");
					} else {
						parentArr.push("1");
						return parentArr.join("C");
					}
				}
        },
        data: data_list
    });

/*
    $('#grid_list').on('click', function(e) {
        var evObj = AlopexGrid.parseEvent(e);
        var dataObj = evObj.data;

        if(evObj.mapping.key == 'comm_cd_id') {
            var rowData = $("#grid_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });
            comm_cd_id = rowData['comm_cd_id'];
            getDetail(comm_cd_id);
        }

    });
*/

};

