// tree_node_management.js


// 노드 ID 추가
function f_insertRow() {
    var h_cat_id = document.getElementById("cat_id");

    if(h_cat_id.value === "") {
        alert("왼쪽 카테고리를 먼저 선택해주세요.");
        return false;
    }

    popup_url = '/admin/node_list_popup';

    popupObj = $a.popup({
        url: popup_url,
        data : { },
        windowpopup: false,
        iframe: true,
        width: 900,
        height: 650,
        title : "노드 목록 조회",
        beforeCallback : function(data) { // 팝업창을 닫을 때 실행
            return true; //리턴값이 true가 아닌경우 팝업창이 닫히지 않고 중단됨. true일 경우는 callback함수가 호출된다.
        },
        callback : function(data) { // 팝업창을 닫을 때 실행
            if(data !== null) {
                //var json_data = JSON.stringify(data);
                var node_arr = new Array();

                for(var idx=0; idx < data.length; idx++) {
                    var node_obj = new Object();
                    node_obj.NODE_ID = data[idx]['NODE_ID'];
                    node_obj.OS_NAME = data[idx]['OS_NAME'];
                    node_obj.IP = data[idx]['IP'];

                    $('#grid_node_list').alopexGrid('dataAdd', $.extend({
                        _state : {
//                            editing: true,
                            selected: true
                        }
                    }, node_obj));
                }
            }
        }
    });
    return;
};

//노드 ID 삭제
function f_deleteRow() {
    // 삭제대상 선택여부 확인
    var chk_num = 0
    var dataList = $('#grid_node_list').alopexGrid('dataGet', {_state:{selected:true}});
    chk_num = dataList.length;

    if(chk_num == 0){
        alert("삭제할 행을 체크해주세요.");
        return false;
    }

    if (confirm("삭제하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn")
    var form = document.getElementById("f_tree_nodemanagement")

    btn.value = 'delete';

    // 선택된 카테고리 Row 정보
    var tree_select_cat_rowData = $("#grid_tree_ca_list").alopexGrid( "dataGet" , {_state:{selected:true}});
    var str_select_cat_rowData = JSON.stringify(tree_select_cat_rowData);

    var tree_sel_cat_data = document.createElement('input');
    tree_sel_cat_data.setAttribute('type', 'hidden');
    tree_sel_cat_data.setAttribute('name', 'tree_sel_cat_data');
    tree_sel_cat_data.setAttribute('value', str_select_cat_rowData);
    form.appendChild(tree_sel_cat_data);

    // 선택된 노드 리스트 정보
    var grid_delete_node_list = $('#grid_node_list').alopexGrid('dataGet', {_state:{selected:true}});
    var str_delete_node_list = JSON.stringify(grid_delete_node_list);

    var delete_node_list = document.createElement('input');
    delete_node_list.setAttribute('type', 'hidden');
    delete_node_list.setAttribute('name', 'delete_node_list');
    delete_node_list.setAttribute('value', str_delete_node_list);
    form.appendChild(delete_node_list);

    form.submit();
    return;
};


// 트리 노드 설정 저장
function f_save() {
    if (confirm("저장하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn");
    var form = document.getElementById("f_tree_nodemanagement");

    btn.value = 'save';

    var grid_list = AlopexGrid.currentData($('#grid_node_list').alopexGrid('dataGet',
        {_state: {edited:true}}, {_state:{selected:true}}, {_state:{editing:true}}
    ));

    var str_list = JSON.stringify(grid_list);

    var save_list = document.createElement('input');
    save_list.setAttribute('type', 'hidden');
    save_list.setAttribute('name', 'save_list');
    save_list.setAttribute('value', str_list);

    form.appendChild(save_list);

    form.submit();

    return;
};

function f_searchNodeID() {
    var btn = document.getElementById("btn")
    var form = document.getElementById("f_tree_nodemanagement")

    btn.value = 'search';

    form.submit();
    return;
}

function f_viewCatNodeList(i_cat_id) {
    $.getJSON('/admin/tree_node_management_list', {
        cat_id : i_cat_id
    }, function(ncatNodeList) {
        // Grid 새로 그리기
        $('#grid_node_list').alopexGrid('dataSet', ncatNodeList);

        // tree click 시 hidden cat_id에 setting (2019.04.24 add KYM)
        var h_cat_id = document.getElementById("cat_id");
        h_cat_id.value = i_cat_id;

        return;
    });
    return;
};
