// task_setting_grid.js

function f_makeGrid(data_tree_ca_list, data_node_list) {

    $("#grid_tree_ca_list").alopexGrid({
        autoColumnIndex : true,
        disableTextSelection : true,
        rowSelectOption: {
            clickSelect: true,
            singleSelect: true,
            radioColumm: true
        },
        header: false,
        useClassHovering: true,
        columnMapping : [
            {
                key : "CAT_NM",
                title : "카테고리이름",
                width : 60,
                treeColumn : true,
                treeColumnHeader : true
            }
        ],
        tree : {
            useTree : true,
            idKey : "CAT_ID",
            parentIdKey : "UPPER_CAT_ID",
            expandedKey : "CAT_EXPANDED",
            depthKey : "DEPTH"
        },
        data : data_tree_ca_list
    });


    $('#grid_node_list').alopexGrid({
        height: 480,
        pager: true,
        paging: {
            perPage: 14,
            pagerCount: 5,
            pagerTotal: true
        },
        autoColumnIndex: true,
        cellSelectable: true,
        filteringHeader: true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        columnMapping : [
            {
                align : 'center',
                key : 'check',
                width : '30px',
                selectorColumn : true
            },
            {
                key : 'NODE_ID',
                title : '노드ID',
                width : '200px',
                //align : 'center',
                editable: true
            }, {
                key : 'OS_NAME',
                title : 'OS명',
                width : '100px',
                //align : 'center',
                editable: true
            }, {
                key : 'IP',
                title : 'IP',
                width : '200px',
                //align : 'center',
                editable: true
            }
        ],
        data: data_node_list
    });

    $('#grid_tree_ca_list').on('click', '.bodycell', function(e) {
        var evObj = AlopexGrid.parseEvent(e);
        var dataObj = evObj.data;

        if(evObj.mapping.key == 'CAT_NM') {
            var rowData = $("#grid_tree_ca_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });
            cat_id = rowData['CAT_ID'];

            f_viewCatNodeList(cat_id);
        }

    });
};

