// user_management.js

// 사용자관리 조회
function f_search() {
    var btn = document.getElementById("btn");
    var form = document.getElementById("f_user_management");

    btn.value = 'search';

    form.submit();
    return;
};

// 사용자관리 엑셀 export
function f_export_excel() {
    var btn = document.getElementById("btn");
    var form = document.getElementById("f_user_management");

    btn.value = 'export';

    form.submit();

    return;
};

// 사용자관리 엑셀 import
function f_import_excel() {
    var btn = document.getElementById("btn");
    var form = document.getElementById("f_user_management");

    btn.value = 'import';
    form.setAttribute("enctype", "multipart/form-data");

    form.submit();

    return;
};

// 사용자 삭제
function f_delete() {
    if (confirm("삭제하시겠습니까?") == false) {
        return false;
    }


    var btn = document.getElementById("btn");
    var form = document.getElementById("f_user_management");
    var detail_id = document.getElementById("detail_id");

    detail_id.value = '';
    btn.value = 'delete';

    form.submit();
    return;
};

// 사용자관리 checkbox toggle
function toggleUserListCheckAll() {
    var checkAll = document.getElementById("user_list_chk_all");
    // table 에 속한 input 태그들을 가져온다.
    var tblUserList = document.getElementById("tbody_userList");
    var inputs = tblUserList.getElementsByTagName('input');

    for (var i=0; i < inputs.length; i++) {
        var chkRow = inputs.item(i);

        if (chkRow.id.indexOf("user_yn_") > -1) {
            if (checkAll.checked == true) {
                chkRow.value = 'y';
            }
            else {
                chkRow.value = 'n';
            }
        }

        // chk_all(전체체크)와 chk_all(전체체크) 를 제외한 나머지 Row들의
        // checked 상태를 동일하게 함.
        if (chkRow.id.indexOf("user_chk_") > -1) {
            chkRow.checked = checkAll.checked;
        }
    }
    return;
};

// 사용자 선택
function f_userClick(cb, index) {
    var chk_id = "user_yn_" + index;
    var chk_yn = document.getElementById(chk_id);

    if (cb.checked == true) {
        chk_yn.value = 'y';
    }
    else {
        chk_yn.value = 'n';
    }

    //alert(chk_id + ", " + chk_yn.value);
    return;
};

// 신규사용자 추가
function f_add_new() {
    if (confirm("신규 사용자를 추가하시겠습니까?") == false) {
        return false;
    }

    var detail_id = document.getElementById("detail_id");
    var user_id = document.getElementById("user_id");
    var user_name = document.getElementById("user_name");
    var user_memo = document.getElementById("user_memo");
    var group1 = document.getElementById("group1");
    var group2 = document.getElementById("group2");
    var group3 = document.getElementById("group3");
    var group4 = document.getElementById("group4");
    var user_role = document.getElementById("user_role");

    detail_id.value = "new";
    user_id.value = "";

    // user_id.disabled = false;
    $('#user_id').setOptions({
    	disabled: false
    });
    user_name.value = "";
    user_memo.value = "";
    group1.selectedIndex = "0";
    group2.selectedIndex = "0";
    group3.selectedIndex = "0";
    group4.selectedIndex = "0";
    user_role.selectedIndex = "0";
	$("#status_0").setSelected();

    return;
};

// 비밀번호 초기화
function init_password() {
    if (confirm("비밀번호 초기화를 하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn");
    var form = document.getElementById("f_user_management");

    btn.value = 'init';

    form.submit();
    return;
};

// 사용자관리 저장
function f_saveUser() {
    if (confirm("저장하시겠습니까?") == false) {
        return false;
    }

    var btn = document.getElementById("btn");
    var form = document.getElementById("f_user_management");

    btn.value = 'save';

    form.submit();
    return;
};

// paginate
function f_paginate(page_num) {
    var btn = document.getElementById("btn");
    var detail_id = document.getElementById("detail_id");

    btn.value = 'search';
    detail_id.value = "";

    var form = document.getElementById("f_user_management");
    document.getElementById("page_num").value = page_num;

    form.submit();
    return;
};

// 사용자 상세 정보
function getDetail(user_id) {
    var btn = document.getElementById("btn");
    var detail_id = document.getElementById("detail_id");

    btn.value = 'search';
    detail_id.value = user_id;

    var form = document.getElementById("f_user_management");

    form.submit();
    return;
};

// toggle excel upload form
function toggle_excel_import() {
    var sub = document.getElementById('attach_box');

    if (sub.style.display == 'none') {
        alert("엑셀 Import 시 등록된 데이터 모두 등록됩니다.\n(암호화 된 문서일 경우 암호화 해제 필요.)");
        sub.style.display = 'block';
    } else {
        sub.style.display = 'none';
    }

    return;
};
