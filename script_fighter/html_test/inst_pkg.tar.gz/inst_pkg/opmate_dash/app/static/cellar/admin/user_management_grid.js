// user_management_grid.js

function gridInit(data) {
    $('#gr_user_list').alopexGrid({
        height: 530,
        pager: true,
        paging: {
            perPage: 20,
            pagerCount: 5,
            pagerTotal: true
        },
//        rowSelectOption :{
//		    clickSelect: true
//		},
        autoColumnIndex: true,
        filteringHeader: true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        columnMapping : [
            {
                align : 'center',
                key : 'check',
                width : '30px',
                selectorColumn : true
            }, {
                key : 'user_id',
                title : '사용자ID',
                sorting: true,
                width : 100
            }, {
                key : 'user_name',
                title : '사용자명',
                sorting: true,
                width : 100
            }, {
                key : 'user_role',
                title : '역할',
                sorting: true,
                width : 50
            }, {
                align : 'center',
                key : 'user_status',
                title : '상태',
                sorting: true,
                width : 50
            }
        ],
        data: data
    });

    // Click 이벤트 처리
    $('#gr_user_list').on('click', function(e) {
        var evObj = AlopexGrid.parseEvent(e);
        var dataObj = evObj.data;

//        alert('row Clicked!!!');

        // 이메일 칼럼 이벤트 발생시
        if (evObj.mapping.key === "check") {
//            alert('check [' + dataObj._index.data + '] ColumnClicked!!!');

//            var rowData = JSON.stringify($("#gr_user_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data }));
            var rowData = $("#gr_user_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });
            var row_state = rowData["_state"]

//            alert(row_state["selected"]);

            if (row_state["selected"] === true) { // selected
                var form_element = document.getElementById("f_user_management");
                var input = document.createElement("input");

                input.setAttribute("type", "hidden");
                input.setAttribute("name", "selected_usr_id");
                input.setAttribute("value", rowData['user_id']);

                form_element.appendChild(input);
            } else {
                var form_element = document.getElementById("f_user_management");
                var selected_usr_id_list = document.getElementsByName("selected_usr_id");

                for (var l=0; l < selected_usr_id_list.length; l++) {
                    if (rowData['user_id'] == selected_usr_id_list[l].value) {
                        var del_e = selected_usr_id_list[l];
                        form_element.removeChild(del_e);
                    }
                }

//                for (var l=0; l < selected_usr_id_list.length; l++) {
//                    alert(selected_usr_id_list[l].value);
//                }
            }

//            alert(document.getElementsByName("selected_usr_id").length);
        }

        if(evObj.mapping.key === "user_id") {
//            alert('user_id ColumnClicked!!!');
//            var rowData = JSON.stringify($("#gr_user_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data }));
            var rowData = $("#gr_user_list").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });
//            alert(rowData['user_id']);
            user_id = rowData['user_id'];
            getDetail(user_id);
        }
    });
};