//
function confirm_form(msg) {
    return confirm(msg);
};

//
function down_excel(report_id) {
    uri = "/tasks/down_excel/" + report_id;
    location.href=uri;
};

//
function down_excel_gs(survey_id) {
    uri = "/general_survey/down_excel/" + survey_id;
    location.href=uri;
};
