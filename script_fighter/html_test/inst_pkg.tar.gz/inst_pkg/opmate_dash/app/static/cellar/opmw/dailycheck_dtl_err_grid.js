function result_dtl_err_gridInit(taskRunListDtl, params){
    $('#dailychec_dtl_err').alopexGrid({
        autoColumnIndex: true,
        height: 'content',
        cellInlineEdit:true,
        filteringHeader: true,
        numberingColumnFromZero: false,
//        cellSelectable: true,
        fitTableWidth: true,
        rowSelectOption: {
            clickSelect: true,
            singleSelect: true
        },
        rowOption: {
            defaultHeight: 'content'
        },
        message: {
            nodata: '일일점검 결과 상세 항목이 존재하지 않습니다',
        },

        columnMapping : [
            {
                align : 'center',
                width : '45px',
                numberingColumn : true
            }
            , {
                key: 'Error',
                title: 'Error',
                width : '700px',
            }
        ],
        data: taskRunListDtl
    });
};

