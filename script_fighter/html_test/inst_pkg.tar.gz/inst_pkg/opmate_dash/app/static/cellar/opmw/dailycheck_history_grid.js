function f_taskRunList_history_gridInit(taskRunList ) {
    $('#dailycheck_history').alopexGrid({
        autoColumnIndex: true,
        height: 500,
        pager: true,
        paging: {
            perPage: 15,
            pagerCount: 5,
            pagerTotal: true
        },
        filteringHeader: true,
        useClassHovering: true,
        cellSelectable : true,
        message: {
            nodata: '데이터가 없습니다.'
        },
        defaultColumnMapping : {
            sorting:true
        },
        columnMapping : [
            {
                key : 'NODE_ID',
                title : '노드',
                width : '100px'
            }, {
                key : 'TASK_ID',
                title : '작업명',
                width : '200px'
            }, {
                align : 'center',
                key : 'START_DT',
                title : '수행시간',
                width : '100px'
            }, {
                align : 'center',
                key : 'RUNNER_ID',
                title : '수행계정',
                width : '100px'
            }, {
                align : 'center',
                key : 'STATUS',
                title : '수행상태',
                width : '80px',
                render : function (value, data, render, mapping, grid) {
                    if (value == "S") {
                        return '<div class="Icon success" align="center"></div>';
                    } else if (value == "F") {
                        return '<div class="Icon fail" align="center"></div>';
                    } else if (value == "C") { // ready
                        return '<div class="Icon loader" align="center"></div>';
                    } else if (value == "R") { //request
                        return '<div class="Icon loader" align="center"></div>';
                    }
			    },
            },{
                align : 'center',
                key : 'RESULT',
                title : '수행결과',
                width : '80px',
                render : function (value, data, render, mapping, grid) {
                    if (value == "S") {
                        return '<div class="Icon success" align="center"></div>';
                    } else if (value == "F") {
                        return '<div class="Icon fail" align="center"></div>';
                    }
			    },
            }, {
                align : 'center',
                key : 'RUN_RESULT',
                title : 'OK여부',
                width : '80px',
                render : function (value, data, render, mapping, grid) {
                    if (value == "Y") {
                        return '<div class="Icon ok" align="center"></div>';
                    } else if (value == "N") {
                        return '<div class="Icon check" align="center"></div>';
                    }
			    },
            }
        ],
        data: taskRunList
    });

    $('#dailycheck_history').on('click', '.bodycell', function(e) {
        var evObj = AlopexGrid.parseEvent(e);
        var dataObj = evObj.data;

        if (evObj.mapping.key === "TASK_ID" || evObj.mapping.key === "NODE_ID" || evObj.mapping.key === "START_DT" || evObj.mapping.key === "RUNNER_ID" || evObj.mapping.key === "RESULT" || evObj.mapping.key === "RUN_RESULT" ) {
            var rowData = $("#dailycheck_history").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });

            result_no = rowData["TASK_RESULT_NO"];
            task_id = rowData["TASK_ID"];
            node_id = rowData["NODE_ID"];
            runner_id = rowData["RUNNER_ID"];
            status = rowData["STATUS"];
            result = rowData["RESULT"];
            okyn = rowData["RUN_RESULT"];

            if (task_id != '') {
                popup_url = '/opmw/dailycheck_history_dtl_popup?'+'result_no'+'='+String(result_no)+'&'+'task_id'+'='+task_id+'&'+'node_id'+'='+node_id+'&'+'runner_id'+'='+runner_id+'&'+'status'+'='+status+'&'+'result'+'='+result+'&'+'okyn'+'='+okyn;

                popupObj = $a.popup({
                    url: popup_url,
                    data : { 'result_no':result_no, 'task_id':task_id, 'node_id':node_id, 'runner_id':runner_id, 'status':status,  'result':result, 'okyn':okyn },
                    windowpopup: false,
                    iframe: true,
                    width: 900,
                    height: 650,
                    title : "일일점검 결과 이력조회",
                    beforeCallback : function(data) { // 팝업창을 닫을 때 실행
                        return true; //리턴값이 true가 아닌경우 팝업창이 닫히지 않고 중단됨. true일 경우는 callback함수가 호출된다.
                    },
                    callback : function(data) { // 팝업창을 닫을 때 실행
        //                alert("popup closed!");
                    }
                });
            };
        };
    });
};

function f_treeView_gridInit(treeNodeList){
    $("#nodelist-tree").alopexGrid({
        autoColumnIndex : true,
        disableTextSelection : true,
        rowSelectOption: {
            clickSelect: true,
            singleSelect: true,
            radioColumm: true
        },
        header: false,
        useClassHovering: true,
        columnMapping : [
            {
                key : "CAT_NM",
                title : "카테고리이름",
                width : 60,
                treeColumn : true,
                treeColumnHeader : true
            }
        ],
        tree : {
            useTree : true,
            idKey : "CAT_ID",
            parentIdKey : "UPPER_CAT_ID",
            expandedKey : "CAT_EXPANDED",
            depthKey : "DEPTH"
        },
        data : treeNodeList
    });

    $('#nodelist-tree').on('click', '.bodycell', function(e) {
        var evObj = AlopexGrid.parseEvent(e);
        var dataObj = evObj.data;

        if(evObj.mapping.key == 'CAT_NM') {
            var rowData = $("#nodelist-tree").alopexGrid( "dataGetByIndex" , {data : dataObj._index.data });

            if (rowData['CAT_ID'].match('node_') ) {
                $('#i_node_id').val(rowData['CAT_NM']);
                f_newviewRunList();
            }

        }

    });
};

