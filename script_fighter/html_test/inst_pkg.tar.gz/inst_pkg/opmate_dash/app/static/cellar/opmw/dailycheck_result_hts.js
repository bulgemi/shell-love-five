// dailycheck_result_hts.js

// 2019.04.05 KKH modified.
// 조회버튼 선처리
function f_preSearchRunList() {
    document.getElementById("search_i_node_id").value       = $('#i_node_id').val();
    document.getElementById("search_i_task_id").value       = $('#i_task_id').val();
    document.getElementById("search_i_runner_id").value     = $('#i_runner_id').val();
    document.getElementById("search_i_fromStart_dt").value  = $('#i_fromStart_dt').val();
    document.getElementById("search_i_toStart_dt").value    = $('#i_toStart_dt').val();
    document.getElementById("search_i_result").value        = $('#i_result').val();
    document.getElementById("search_i_okyn").value          = $('#i_okyn').val();
    return true;
};

function f_searchRunList_hts() {
//    f_preSearchRunList()

    var form = document.createElement('form');
    form.setAttribute('method', 'post');
    form.setAttribute('action', '/opmw/dailycheck_history_list')

    var node, task, fromStart_dt, toStart_dt, runner_id, result, run_result;

    node = document.createElement('input');
    node.setAttribute('type', 'hidden');
    node.setAttribute('name', 'search_i_node_id');
    node.setAttribute('value', $('#i_node_id').val());
    form.appendChild(node);

    task = document.createElement('input');
    task.setAttribute('type', 'hidden');
    task.setAttribute('name', 'search_i_task_id');
    task.setAttribute('value', $('#i_task_id').val());
    form.appendChild(task);

    fromStart_dt = document.createElement('input');
    fromStart_dt.setAttribute('type', 'hidden');
    fromStart_dt.setAttribute('name', 'search_i_fromStart_dt');
    fromStart_dt.setAttribute('value', $('#i_fromStart_dt').val());
    form.appendChild(fromStart_dt);

    toStart_dt = document.createElement('input');
    toStart_dt.setAttribute('type', 'hidden');
    toStart_dt.setAttribute('name', 'search_i_toStart_dt');
    toStart_dt.setAttribute('value', $('#i_toStart_dt').val());
    form.appendChild(toStart_dt);

    runner_id = document.createElement('input');
    runner_id.setAttribute('type', 'hidden');
    runner_id.setAttribute('name', 'search_i_runner_id');
    runner_id.setAttribute('value', $('#i_runner_id').val());
    form.appendChild(runner_id);

    result = document.createElement('input');
    result.setAttribute('type', 'hidden');
    result.setAttribute('name', 'search_i_result');
    result.setAttribute('value', $('#i_result').val());
    form.appendChild(result);

    run_result = document.createElement('input');
    run_result.setAttribute('type', 'hidden');
    run_result.setAttribute('name', 'search_i_okyn');
    run_result.setAttribute('value', $('#i_okyn').val());
    form.appendChild(run_result);


    document.body.appendChild(form);
    form.submit();
    return;
};

function f_newviewRunList() {
    $.getJSON('/opmw/dailycheck_hts_new', {
        search_i_mode : "",
        search_i_node_id : $('#i_node_id').val(),
        search_i_task_id : $('#i_task_id').val(),
        search_i_runner_id : $('#i_runner_id').val(),
        search_i_fromStart_dt :$('#i_fromStart_dt').val(),
        search_i_toStart_dt : $('#i_toStart_dt').val(),
//        search_i_status : search_i_status,
        search_i_result : $('#i_result').val(),
        search_i_okyn : $('#i_okyn').val()
    }, function(ntaskRunList) {
        // filter 정보 유지
        if(filterInfo != null){
            $("#dailycheck_history").alopexGrid('filterSet', filterInfo );
        }

        // Grid 새로 그리기
        $('#dailycheck_history').alopexGrid('dataSet', ntaskRunList);

        // page 정보 유지
        if (curr_page > 0){
             $('#dailycheck_history').alopexGrid('pageSet', curr_page);
        }

        // sorting 정보 유지
        if(sortingInfo != null){
            $("#dailycheck_history").alopexGrid('dataSort', sortingInfo );
        }
        else {
            $("#dailycheck_history").alopexGrid('dataSort', [ {sortingColumn : 'START_DT', sortingDirection: 'desc'}]);
        }
        return;
    });
    return;

};

function f_refreshRunList() {
    // page 정보 저장
    curr_page = $('#dailycheck_history').alopexGrid('pageInfo')['current'];

    // sorting 정보 유지
   sortingInfo = $('#dailycheck_history').alopexGrid('sortingInfo');

    // filter 유지
    filterInfo = $('#dailycheck_history').alopexGrid('filterInfo').filterColumnMappingList;

    f_newviewRunList();
    return;
};

// onload 이벤트 처리
function onloadComplete() {
    var interval = 10; // 3600초 = 1시간
    var timeleft = interval;
    $("#dailycheck_history").alopexGrid('dataSort', [ {sortingColumn : 'START_DT', sortingDirection: 'desc'}]);
    var refreshTimer = setInterval(function() {
        timeleft--;
        if (timeleft <= 0) {
            f_refreshRunList()
            // Reset
            timeleft = interval;
        }
    }, 1000 ); // 5초에 한번씩 refresh
    return;
};