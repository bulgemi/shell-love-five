// dashboard_chart_agent.js

var agent_chart_dashboard = null;
var agent_text_ctx = null;

function f_drawAgentChart() {

    // get chart canvas
    var agent_chart_ctx = document.getElementById("agent_doughnut").getContext("2d");

    if(agent_chart_dashboard != null) {
        agent_chart_dashboard.destroy();
        agent_chart_dashboard = null;
    }

    var plugin = {
        afterDraw: function(chart) {

            if (agent_chart_dashboard.options.elements.center) {
                var helpers = Chart.helpers;
                var centerX = (agent_chart_dashboard.chartArea.left + agent_chart_dashboard.chartArea.right) / 2;
                var centerY = (agent_chart_dashboard.chartArea.top + agent_chart_dashboard.chartArea.bottom) / 2;

                if(agent_text_ctx != null){
                    agent_text_ctx = null;
                }

                agent_text_ctx = agent_chart_dashboard.chart.ctx;

                var fontSize = helpers.getValueOrDefault(agent_chart_dashboard.options.elements.center.fontSize, Chart.defaults.global.defaultFontSize);
                var fontStyle = helpers.getValueOrDefault(agent_chart_dashboard.options.elements.center.fontStyle, Chart.defaults.global.defaultFontStyle);
                var fontFamily = helpers.getValueOrDefault(agent_chart_dashboard.options.elements.center.fontFamily, Chart.defaults.global.defaultFontFamily);
                var font = helpers.fontString(fontSize, fontStyle, fontFamily);

                agent_text_ctx.font = font;
                agent_text_ctx.fillStyle = helpers.getValueOrDefault(agent_chart_dashboard.options.elements.center.fontColor, Chart.defaults.global.defaultFontColor);
                agent_text_ctx.textAlign = 'center';
                agent_text_ctx.textBaseline = 'middle';
                agent_text_ctx.fillText(agent_chart_dashboard.options.elements.center.text, centerX, centerY);

                agent_text_ctx.restore();
            }
        },
    }


    // draw chart
    agent_chart_dashboard = new Chart(agent_chart_ctx, {
        type: 'doughnut',
        data: {
            "labels" : ["정상", "비활성화", "미설치", "오류"],
            "datasets" : [
                {
                    "label" : "System Linux",
                    "data" : [7, 2, 1, 0],
                    "backgroundColor" : [
                                        "rgb(54, 162, 235)",
                                        "rgb(255, 205, 86)",
                                        "rgb(187, 153, 255)",
                                        "rgb(255, 99, 132)"
                                        ]
                 }
            ]
        },
        options: {
            elements: {
                center: {
                    text: '오류 : 0건',
                    fontColor: '#000',
                    fontFamily: "'Helvetica Neue', 'Helvetica', 'Arial', sans-serif",
                    fontSize: 24,
                    fontStyle: 'normal'
                }
            },
            responsive: true,
            legend: {
                display: true
            },
            hover: {
                    onHover: function(event, elements) {
                        $("#agent_doughnut").css("cursor", elements[0] ? "pointer" : "default");
                     }
            }
        },
        plugins: [plugin]
    });


    $(document).ready(function() {
        $("#agent_doughnut").click(
        function(evt){
            var activePoints = agent_chart_dashboard.getElementsAtEvent(evt);
            var clickedElementIndex = activePoints[0]._index;
            var value = agent_chart_dashboard.data.labels[clickedElementIndex];
        });
    });
};
