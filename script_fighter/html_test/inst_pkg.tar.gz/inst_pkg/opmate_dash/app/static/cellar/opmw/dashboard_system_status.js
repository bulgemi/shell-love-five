// dashboard_system_status.js

// TOMS 연동 현황.
function f_getSyncSystem() {
    $.getJSON('/opmw/dashboard/sync_system', {
    }, function(data) {
        var tblSyncSystem = document.getElementById("tbl_system_status");
        var tblTr = tblSyncSystem.getElementsByTagName("tr");
        var tblTd = tblTr[0].getElementsByTagName("td");

        var status = tblTd[0].getElementsByTagName("span")[0];

        if ( data.status  == 'D') {
            status.setAttribute("class", "Label Success");
            status.innerHTML = '정상';
        } else if ( data.status == 'E') {
            status.setAttribute("class", "Label Danger");
            status.innerHTML = '에러';
        } else {
            status.setAttribute("class", "Label Warning");
            status.innerHTML = '미연동';
        }

        return;

    });

    return;
};
