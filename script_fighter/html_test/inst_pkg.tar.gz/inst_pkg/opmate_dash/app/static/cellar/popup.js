$a.page(function() {
    // 초기화 함수
    this.init = function(id, param) {
        var msgs = param["item"];
		$('#popCont').html(msgs);
    };
});