document.addEventListener("DOMContentLoaded", function (event) {
    let dash = AlopexDash.create({
        tagId: 'dashboard',
        columnLimit: 4,
        widgetSize : ['auto', 200],
        widgets : {
            generalSample : {
              type: 'general.content',
              title: "Linux",
              data: {
                  html : `
                    <p>기본 위젯의 레이아웃만 잡아드리니 해당 위젯에 맞는 내용으로 수정하여 적용하시면 됩니다.</p>
                  `
              },
            },
            generalSample2 : {
              type: 'general.content',
              title: "Windows",
              data: {
                  html : `
                    <p>general.content type으로 모양만 봐주세요.</p>
                  `
              },
            },
            generalSample3 : {
              type: 'general.content',
              title: "MiddleWare",
              data: {
                  html : `
                    <p>여기에 해당 위젯의 내용을 넣어주세요.</p>
                  `
              },
            },
            generalSample4 : {
              type: 'general.content',
              title: "Database",
              data: {
                  html : `
                    <p>여기에 해당 위젯의 내용을 넣어주세요.</p>
                  `
              },
            },
            generalSample5 : {
              type: 'general.content',
              title: "Agent 상태점검",
              data: {
                  html : `
                    <p>여기에 해당 위젯의 내용을 넣어주세요.</p>
                  `
              },
            }
        }
    });
});
