$a.page(function(){
	this.init = function(){
		//header navmenu
		var nav = $('.nav > li');
		var subnav = $('.apxtyped-submenu__wrap');
		$(nav).find(subnav).parent().addClass('expanded');

		//popup
		$('#pop-temp1').click( function() {
		    $a.popup({
		        url: "05-popup.html",
		        iframe: false,  // default 는 true
		        width: 700,
		        height: 400,
		        title : "일일 점검 수행 결과 상세"
		    });
		});
		$('#pop-temp2').click( function() {
		    $a.popup({
		        url: "05-popup.html",
		        iframe: false,  // default 는 true
		        width: 700,
		        height: 400,
		        title : "일일 점검 결과 이력조회 상세"
		    });
		});
		$('#pop-temp3').click( function() {
		    $a.popup({
		        url: "popup3.html",
		        iframe: false,  // default 는 true
		        width: 750,
		        height: 650,
		        title : "테이블과 파일추가가 있는 팝업창",
		    });
		});
		$('.Tabs').on('tabchange', function(e, index, index2){
		    $('#gr4').alopexGrid("viewUpdate");
		});

		var leftMenuMinWidth = 40;
		var leftMenuHideWidth = 120;
		var leftMenuInitWidth = 340;

		var $leftMenuSplitter = $("#left-menu__split");
		var $leftMenuBtn = $('#left-menu__btn');
		var $leftMenuContent = $(".left-contents")

		$("#left-menu__split").setOptions({
			onDrag : function(event){
				var frameWidth = parseInt($('#frame1').css('width'));
				if( frameWidth <= leftMenuHideWidth &&  $leftMenuBtn.hasClass("left-footer__close")){
					$leftMenuContent.hide();
					$leftMenuBtn.removeClass("left-footer__close").addClass("left-footer__open");
				} else if( frameWidth > leftMenuHideWidth && $leftMenuBtn.hasClass("left-footer__open")){
					$leftMenuContent.show();
					$leftMenuBtn.removeClass("left-footer__open").addClass("left-footer__close");
				}
			}
		});

		$("#left-menu__btn").on("click", function(){

			if($leftMenuBtn.hasClass("left-footer__close")){
				$leftMenuContent.hide();
				$leftMenuBtn.removeClass("left-footer__close").addClass("left-footer__open");
				$leftMenuSplitter.setOptions({position : leftMenuMinWidth});
			}else {
				$leftMenuContent.show();
				$leftMenuBtn.removeClass("left-footer__open").addClass("left-footer__close");
				$leftMenuSplitter.setOptions({position : leftMenuInitWidth});
			}
		});
	}
});
