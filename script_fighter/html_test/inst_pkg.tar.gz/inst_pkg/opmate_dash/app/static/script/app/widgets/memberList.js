AlopexDash.define("memberList", {
    properties : {
        defaultGridOption :{
            fitTableWidth :true,
            autoColumnIndex: true,
        },
        gridId : '',
    },
    model : {
        html : {type : "string", default:"<div grid></div>"},
        dataList : { type : ["object"], default:[]},
        gridOption : { type : "object", default : {}}
    },
    render: function (data) {
        /**
         * Render 내 AlopexGrid 마크업 선언 : <div grid></div> 
         * AlopexGrid 는 lifecycle.created 콜백 수행 시점에 해당 엘리먼트에 생성함
         */
        return `
        <div grid></div>
        <div class="info-wrap">
            <p class="info-title">팀원목록 권한 </p>
            <ul>
                <li>PM 및 PL 권한은 프로젝트 관리자 및 서브시스템 관리자로 지정된 사람으로 지정됩니다.</li>
                <li>PM 및 PL 권한 사용자를 변경하려면 "기본정보>프로젝트 등록/변경"에서 변경하세요.</li>
            </ul>
        </div>
        <div>
            <p>그리드에 들어가는 ui form tags</p>
            <div class="Divselect grid-select">
                <select>
                    <option>전체</option>
                    <option>검색어 1</option>
                    <option>구분어</option>
                    <option>항목 항목 항목</option>
                </select>
                <span></span>
            </div>
            <input class="Textinput grid-input">
        </div>`;
    },
    lifecycle : {
        created : function(data){
            let id = this.generateId();
            let el = this.getElement();

            // Alopex UI 컴포넌트 사용 시 
            $(el).convert();

            // Alopex Grid 생성
            let gridEl= this.getElement().querySelector("[grid]");
            gridEl.id= id;

            let props = this.getProperty();
            props.gridId = id;
            let option = Object.assign({}, props.defaultGridOption, data);
            $(gridEl).alopexGrid(option);
            
        },
        updated : function(){
            
        }
    },
    method : {
        generateId : ()=>{
            let id;
            do{
                let rand = parseInt(Math.random() * 1000);
                id = `AlopexDash_Grid_${rand}`;
            } while (document.getElementById(id) !== null );
            return id;
        }
    }
})
                        