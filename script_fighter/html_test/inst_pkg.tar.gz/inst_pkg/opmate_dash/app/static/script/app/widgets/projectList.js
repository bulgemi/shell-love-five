AlopexDash.define("projectList", {
    properties : {
        defaultGridOption :{
            fitTableWidth :true,
            autoColumnIndex: true,
        },
        gridId : '',
    },
    model : {
        html : {type : "string", default:"<div grid></div>"},
        dataList : { type : ["object"], default:[]},
        gridOption : { type : "object", default : {}}
    },
    render: function (data) {
        /**
         * Render 내 AlopexGrid 마크업 선언 : <div grid></div> 
         * AlopexGrid 는 lifecycle.created 콜백 수행 시점에 해당 엘리먼트에 생성함
         */
        return `
        <div grid></div>
        <div class="src-wrap">
            <span class="src-title">서브시스템</span>
            <div class="Divselect">
                <select>
                    <option>전체</option>
                    <option>검색어 1</option>
                    <option>구분어</option>
                    <option>항목 항목 항목</option>
                </select>
                <span></span>
            </div>
            <button class="Button btn">저장</button>
        </div>
        <h3 class="pms-subtitle">프로젝트명:<span>NEXCORE PMS 방법론 교육 및 시연</span></h3>
        <table class="Table Form-type">
            <colgroup>
                <col style="width:200px">
                <col>
            </colgroup>
            <tbody>
                <tr>
                    <th>규모 및 적용방법론</th>
                    <td>
                        <div class="Divselect">
                            <select>
                                <option>전체</option>
                                <option>검색어 1</option>
                                <option>구분어</option>
                                <option>항목 항목 항목</option>
                            </select>
                            <span></span>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th>Tailoring 특성</th>
                    <td>
                        <div class="Divselect">
                            <select>
                                <option>전체</option>
                                <option>검색어 1</option>
                                <option>구분어</option>
                                <option>항목 항목 항목</option>
                            </select>
                            <span></span>
                        </div>
                    </td>
                </tr>
            </tbody>
        </table> `
    },
    lifecycle : {
        created : function(data){
            let id = this.generateId();
            let el = this.getElement();

            // Alopex UI 컴포넌트 사용 시 
            $(el).convert();

            // Alopex Grid 생성
            let gridEl= this.getElement().querySelector("[grid]");
            gridEl.id= id;

            let props = this.getProperty();
            props.gridId = id;
            let option = Object.assign({}, props.defaultGridOption, data);
            $(gridEl).alopexGrid(option);
            
        },
        updated : function(){
            
        }
    },
    method : {
        generateId : ()=>{
            let id;
            do{
                let rand = parseInt(Math.random() * 1000);
                id = `AlopexDash_Grid_${rand}`;
            } while (document.getElementById(id) !== null );
            return id;
        }
    }
})
                        