AlopexDash.define("projectSearchBox", {
    properties : {
    },
    model : {
    },
    render: function (data) {
        return `
        <table class="Table Form-type">
        <colgroup>
            <col style="width:100px">
            <col>
            <col style="width:100px">
            <col>
            <col style="width:100px">
            <col>
            <col style="width:200px">
            <col>
        </colgroup>
        <tbody>
            <tr>
                <th>년도</th>
                <td>
                    <div class="Divselect">
                        <select>
                            <option>전체</option>
                            <option>검색어 1</option>
                            <option>구분어</option>
                            <option>항목 항목 항목</option>
                        </select>
                        <span></span>
                    </div>
                </td>
                <th>본부</th>
                <td>
                    <div class="Divselect">
                        <select>
                            <option>전체</option>
                            <option>검색어 1</option>
                            <option>구분어</option>
                            <option>항목 항목 항목</option>
                        </select>
                        <span></span>
                    </div>
                </td>
                <th>상태</th>
                <td>
                    <div class="Divselect">
                        <select>
                            <option>전체</option>
                            <option>검색어 1</option>
                            <option>구분어</option>
                            <option>항목 항목 항목</option>
                        </select>
                        <span></span>
                    </div>
                </td>
                <th>검색</th>
                <td>
                    <div class="Divselect">
                        <select>
                            <option>전체</option>
                            <option>검색어 1</option>
                            <option>구분어</option>
                            <option>항목 항목 항목</option>
                        </select>
                        <span></span>
                    </div>
                    <input class="Textinput">
                </td>
            </tr>
        </tbody>
    </table>
    <div class="btn-wrap btn-right">
        <button class="Button btn bg-red" action="search">검색</button>
        <button class="Button btn" action="init">검색조건 초기화</button>
        <button class="Button btn" action="export">엑셀 다운로드</button>
        <button class="Button btn" action="register">일괄등록</button>
    </div> `;
    },
    lifecycle : {
        created : function(data){
            let el = this.getElement();

            // Alopex UI 컴포넌트 사용 시 
            $(el).convert();
            
        },
        updated : function(){
            
        }
    },
    events:{
        click : (e, dashboard, widget) => {
            let action = e.target.getAttribute("action");

            switch(action){
                case "search":
                    alert("search");
                    // to do something
                break;
                case "init":
                    // to do something
                break;
                case "export":
                // to do something
                break;
                case "register":
                // to do something
            break;
            }
        }
    }
})
                        