AlopexDash.define("userSearchBox", {
    properties : {
    },
    model : {
    },
    render: function (data) {
        return `
        <table class="Table Form-type">
        <colgroup>
            <col style="width:100px">
            <col>
            <col style="width:100px">
            <col>
            <col style="width:100px">
            <col>
            <col style="width:200px">
        </colgroup>
        <tbody>
            <tr>
                <th>사번</th>
                <td><input class="Textinput"></td>
                <th>성명</th>
                <td><input class="Textinput"></td>
                <th>회사</th>
                <td><input class="Textinput"></td>
                <th rowspan="3" class="btnwrap-leftline">
                    <button class="Button btn bg-red" action="search">검색</button>
                    <p class="Margin-top-5"><button class="Button btn" action="init">초기화</button></p>
                </th>
            </tr>
            <tr>
                <th>부서명</th>
                <td><input class="Textinput srcinput"><button class="Button btn-search">검색</button></td>
                <th>직위</th>
                <td><input class="Textinput srcinput"><button class="Button btn-search">검색</button></td>
                <th rowspan="2" class="Valign-top">기술등급</th>
                <td rowspan="2"><input class="Textinput srcinput"><button class="Button btn-search">검색</button><br>
                    <div class="Divselect Margin-top-5">
                        <select>
                            <option>전체</option>
                            <option>검색어 1</option>
                            <option>구분어</option>
                            <option>항목 항목 항목</option>
                        </select>
                        <span></span>
                    </div>
                </td>
            </tr>
            <tr>
                <th>등록구분</th>
                <td><div class="Divselect">
                        <select>
                            <option>전체</option>
                            <option>검색어 1</option>
                            <option>구분어</option>
                            <option>항목 항목 항목</option>
                        </select>
                        <span></span>
                    </div>
                </td>
                <th>장기접속자</th>
                <td><div class="Divselect">
                        <select>
                            <option>전체</option>
                            <option>검색어 1</option>
                            <option>구분어</option>
                            <option>항목 항목 항목</option>
                        </select>
                        <span></span>
                    </div>
                </td>
            </tr>
        </tbody>
    </table>`;
    },
    lifecycle : {
        created : function(data){
            let el = this.getElement();

            // Alopex UI 컴포넌트 사용 시 
            $(el).convert();
            
        },
        updated : function(){
            
        }
    },
    method : {
    },
    events:{
        click : (e, dashboard, widget) => {
            console.log(e.target.action)
            let action = e.target.getAttribute("action");

            switch(action){
                case "search":
                    // to do something
                    alert("search");
                break;
                case "init":
                    // to do something
                break;
            break;
            }
        }
    }
})
                        