# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

from flask import Blueprint, render_template
# Cellar
from app import get_login_session, login_required


celery_monitor = Blueprint('celery_monitor', __name__, template_folder='templates')


@celery_monitor.route('/celery_monitor')
@login_required
def monitor_celery():
    return render_template('taskqueue/celery_monitor.html', menu_active="management", login_info=get_login_session())
