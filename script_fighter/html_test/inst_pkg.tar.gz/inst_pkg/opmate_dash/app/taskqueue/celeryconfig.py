# _*_ coding: utf-8 _*_

from celery.schedules import crontab


CELERY_TASK_RESULT_EXPIRES = 18000  # 5 hours
CELERY_TIMEZONE = 'Asia/Seoul'
CELERY_ENABLE_UTC = False

CELERYBEAT_SCHEDULE = {
    # 'test': {
    #     'task': 'manage.add_together',
    #     # 매일 06:00
    #     # 'schedule': crontab(minute=0, hour=6),
    #     'schedule': crontab(minute="*"),
    #     'args': (10, 10),
    # },
    'sync-daily-check': {
        'task': 'manage.do_task_opmw_daily',
        # 매일 08:00
        'schedule': crontab(minute=0, hour=8),
        # 'args': (16, 16),
    },
    'mpcr-monthly': {
        'task': 'manage.do_task_mpcr_monthly',
        # 매월 3일, 06:00
        'schedule': crontab(minute=0, hour=6, day_of_month='3'),
        # 'args': (16, 16),
    },
    'get-node-list-daily': {
        'task': 'manage.do_node_list_daily',
        # 1시간마다
        'schedule': crontab(minute=0, hour='*/1'),
        # 'args': (16, 16),
    }
}
