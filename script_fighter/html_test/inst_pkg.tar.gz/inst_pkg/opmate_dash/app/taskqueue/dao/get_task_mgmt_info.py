# _*_ coding: utf-8 _*_

from flask import current_app
from app.models import OpmwTaskMgmt
from app.cellarerror.sqlerror import SqlBaseException


def get_task_id_list():
    """
    대시보드 화면에 노출시킬 func_cl_cd, task_id를 가져온다.
    :param
    :return:
        task_id_list
    """

    try:
        task_id_list = []
        result = OpmwTaskMgmt.query \
            .with_entities(OpmwTaskMgmt.TASK_ID).all()

        for row in result:
            task_id_list.append(row[0])

    except Exception as e:
        current_app.logger.error("args=[%s], message=[%s]"
                                 % (e.args, e.message))
        raise SqlBaseException(e)

    return task_id_list
