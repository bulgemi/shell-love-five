# _*_ coding: utf-8 _*_
__author__ = 'kim youngme'

from flask import current_app
from app.opmw.api import node_list_call_api
from app.opmw.api.dao.save_node_list import save_node


def load_job(*args):
    """
    Opmate task 수행 처리 등록.
    :param args:
    :return:
    """
    # for arg in args:
    #     current_app.logger.debug("arg: <%r>" % arg)

    # task_id = args[0]

    # current_app.logger.debug("#"*50)
    # current_app.logger.debug("task_id : [%r]" % task_id)

    # 1. Node list 조회 (Restrul)
    api_result, ins_node_list = node_list_call_api.opmate_node_list()

    # 2. Node 정보 DB 저장
    if api_result:
        for data in ins_node_list['nodeList']:
            save_node(data['id'], data['agentGuid'], data['agentVer'], data['osName'], data['ip']
                      , data['hostname'], data['status'], data['heartbeatDt'], data['crtDt'])

    else:
        current_app.logger.error("nodelist api call fail!")
        return api_result

    current_app.logger.debug("##### node_list_daily success!!")
    return


def run_job(*args):
    """
    Opmate task 호출.
    :param args:
    :return:
    """
    import manage as mg
    result = mg.do_node_list_daily.delay(*args)

    return result.id
