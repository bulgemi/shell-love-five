# _*_ coding: utf-8 _*_
__author__ = 'kim dong-hun'

from flask import current_app


def load_job(*args):
    """
    mpcr ppt task 수행 처리 등록.
    :param args:
    :return:
    """
    for arg in args:
        current_app.logger.debug("arg: <%r>" % arg)

    pass


def run_job(*args):
    """
    mpcr ppt task 호출.
    :param args:
    :return:
    """
    import manage as mg
    result = mg.do_task_mpcr_ppt.delay(*args)

    return result.id
