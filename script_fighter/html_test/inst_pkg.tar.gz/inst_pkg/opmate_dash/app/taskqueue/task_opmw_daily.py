# _*_ coding: utf-8 _*_
__author__ = 'kim dong-hun'

from flask import current_app
from app.opmw.api import call_api
from app.opmw.fileio.result_file_parsing import dailycheck_result_parsing
from app.opmw.fileio.result_file_div import save_viewrun_result_file, get_viewrun_result_list, delete_viewrun_result_file
from app.opmw.dao.insert_task_run_list import save_dailycheck_result_list_dtl, save_task_run_list, save_dailycheck_result_error
from app.opmw.dao.update_task_run_list import update_dailycheck_result_error
from app.opmw.dailycheck.dailycheck_api import check_dailycheck_result_okyn
from app.taskqueue.dao.get_task_mgmt_info import get_task_id_list


def save_result(task_id, ins_node_list):
    """
    OpMate Task 수행 결과 저장 처리.
    :param task_id:
    :param ins_node_list:
    :return True or False:
    """
    # 1. Task 수행결과 전체 노드에 대해 수집 (Restful)
    viewrunall_result_list = get_viewrun_result_list(ins_node_list)

    for idx in range(0, len(viewrunall_result_list)):
        # 2. Task 결과 파일 생성
        save_viewrun_result_file(viewrunall_result_list[idx])

        # 3. Task 상세(노드별) 결과 파일 parsing
        result_list = dailycheck_result_parsing(viewrunall_result_list[idx]['filepath'])

        # 4.노드별 Task 수행결과 DB Insert (TASK_RUN_LIST table)
        run_insert_rst, task_result_no = save_task_run_list(task_id,
                                                            viewrunall_result_list[idx]['instanceNo'],
                                                            viewrunall_result_list[idx]['nodeId'],
                                                            "scheduler")

        if run_insert_rst is True:
            if viewrunall_result_list[idx]['status'] == 'Complete':
                # 4. Task 수행결과 상세정보 DB Insert (TASK_RUN_LIST_DTL table)
                save_dtl_result = save_dailycheck_result_list_dtl(result_list, task_result_no)

                # 5. 점검 결과가 모두 OK인지 여부 check 및 TASK_RUN_LIST 테이블에 update
                if save_dtl_result is True:
                    check_result = check_dailycheck_result_okyn(task_result_no, viewrunall_result_list[idx])

                    # 6. (모든 처리 성공 시) 결과 파일 삭제
                    if check_result is True:
                        delete_viewrun_result_file(viewrunall_result_list[idx]['filepath'])
                    else:
                        current_app.logger.error("Failed Update table [TASK_RUN_LIST]")
                        return False
                else:
                    current_app.logger.error("Failed insert table [TASK_RUN_LIST_DTL]")
                    return False
            # status가 Ready 인 경우
            else:
                update_dailycheck_result_error(task_result_no)
                save_dailycheck_result_error(task_result_no, 'Error occurred while performing Task')
        else:
            current_app.logger.error("Failed insert table [TASK_RUN_LIST]")
            return False
    return True


def load_job(*args):
    """
    Opmate task 수행 처리 등록.
    :param args:
    :return:
    """
    # for arg in args:
    #     current_app.logger.debug("arg: <%r>" % arg)

    # task_id = args[0]

    # current_app.logger.debug("#"*50)
    # current_app.logger.debug("task_id : [%r]" % task_id)

    # 일일점검용 task_id 목록조회
    task_id_list = get_task_id_list()

    # task_id 별 결과 저장
    for task_id in task_id_list:
        current_app.logger.debug("task_id : [%r]" % task_id)

        # 1. Task 수행결과 전체 노드에 대해 수집 (Restful)
        api_result, ins_node_list = call_api.opmate_task_viewrunall(task_id)

        if api_result:
            if save_result(task_id, ins_node_list) is False:
                return False
            # viewrunall_result_list = get_viewrun_result_list(ins_node_list)
            #
            # for idx in range(0, len(viewrunall_result_list)):
            #     # 2. Task 결과 파일 생성
            #     save_viewrun_result_file(viewrunall_result_list[idx])
            #
            #     # 3. Task 상세(노드별) 결과 파일 parsing
            #     result_list = dailycheck_result_parsing(viewrunall_result_list[idx]['filepath'])
            #
            #     # 4.노드별 Task 수행결과 DB Insert (TASK_RUN_LIST table)
            #     run_insert_rst, task_result_no = save_task_run_list(task_id,
            #                                                         viewrunall_result_list[idx]['instanceNo'],
            #                                                         viewrunall_result_list[idx]['nodeId'],
            #                                                         "scheduler")
            #
            #     if run_insert_rst:
            #         if viewrunall_result_list[idx]['status'] == 'Complete':
            #             # 4. Task 수행결과 상세정보 DB Insert (TASK_RUN_LIST_DTL table)
            #             save_dtl_result = save_dailycheck_result_list_dtl(result_list, task_result_no)
            #
            #             # 5. 점검 결과가 모두 OK인지 여부 check 및 TASK_RUN_LIST 테이블에 update
            #             if save_dtl_result:
            #                 check_result = check_dailycheck_result_okyn(task_result_no, viewrunall_result_list[idx])
            #
            #                 # 6. (모든 처리 성공 시) 결과 파일 삭제
            #                 if check_result:
            #                     delete_viewrun_result_file(viewrunall_result_list[idx]['filepath'])
            #                 else:
            #                     current_app.logger.error("Failed Update table [TASK_RUN_LIST]")
            #                     return check_result
            #
            #             else:
            #                 current_app.logger.error("Failed insert table [TASK_RUN_LIST_DTL]")
            #                 return save_dtl_result
            #
            #         # status가 Ready 인 경우
            #         else:
            #             update_dailycheck_result_error(task_result_no)
            #             save_dailycheck_result_error(task_result_no, 'Error occurred while performing Task')
            #
            #     else:
            #         current_app.logger.error("Failed insert table [TASK_RUN_LIST]")
            #         return run_insert_rst
        else:
            current_app.logger.error("viewrunall api call fail <task_id:%r>" % task_id)
            return api_result

    current_app.logger.debug("##### task_opmw_daily success!!")
    return


def run_job(*args):
    """
    Opmate task 호출.
    :param args:
    :return:
    """
    import manage as mg
    result = mg.do_task_opmw_daily.delay(*args)

    return result.id
