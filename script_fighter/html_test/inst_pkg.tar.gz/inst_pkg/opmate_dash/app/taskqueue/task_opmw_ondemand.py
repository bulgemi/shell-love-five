# _*_ coding: utf-8 _*_
__author__ = 'kim dong-hun'
from flask import current_app
from app.opmw.api import call_api, ondemand_run_hist_save, ondemand_run_hist_edit
from app.opmw.fileio.result_file_parsing import dailycheck_result_parsing
from app.opmw.fileio.result_file_div import save_viewrun_result_file, get_viewrun_result_list, delete_viewrun_result_file
from app.opmw.dao.insert_task_run_list import save_dailycheck_result_list_dtl, save_task_run_list, save_dailycheck_result_error
from app.opmw.dao.update_task_run_list import update_dailycheck_result_error
from app.opmw.dailycheck.dailycheck_api import check_dailycheck_result_okyn
from time import sleep
from app.opmw.api import call_api

def load_job(*args):
    """
    Opmate task 수행 처리 등록.
    :param args:
    :return:
    """
    # current_app.logger.debug("args: <%r>" % args)
    # param = args[0]

    for arg in args:
        current_app.logger.debug("ondemand load_job arg: <%r>" % arg)

    task_id = args[0]
    instance_no = args[1]
    node_id = args[2]
    runner_id = args[3]

    # 1. Task ondemand 수행 이력 및 Task 수행 결과 DB Insert
    run_insert_rst, task_result_no = save_task_run_list(task_id, instance_no, node_id, runner_id)

    if run_insert_rst:
        insert_rst, ondemand_no = ondemand_run_hist_save.save_ondemand_run_hist(instance_no, node_id, runner_id, task_result_no)
        print(ondemand_no)
    else:
        current_app.logger.error("Failed insert table [TASK_RUN_LIST]")

    # 2. Task 재수행 요청(Restful)
    if insert_rst:
        rerun_rst, rerun_result = call_api.opmate_task_rerun(instance_no, node_id)
    else:
        current_app.logger.error("rerun Fail <ondemand_no:%r>" % str(ondemand_no))
        return insert_rst

    # 3. Task 결과 수집 (Restful)
    if rerun_rst:
        current_app.logger.debug("rerun successfully <resultCode:%r> <resultMsg:%r>" % (rerun_result['resultCode'], rerun_result['resultMsg']))
        status_flag = True
        timeout = int(current_app.config['OPMATE_RESULT_TIMEOUT'])

        while status_flag:
            view_rst, viewrun_result = call_api.opmate_task_viewrun(instance_no, node_id)
            # current_app.logger.debug("viewrun opmate_task_viewrun <viewrun_result:%r>" % ( viewrun_result))

            # 4. Task 수행 결과에서 데이터 가져오기
            if view_rst:
                viewrun_result_list = get_viewrun_result_list(viewrun_result)

                for idx in range(0, len(viewrun_result_list)):
                    if viewrun_result_list[idx]['status'] == 'Complete':
                        # 5. Task 상세(노드별) 결과 파일 생성
                        save_viewrun_result_file(viewrun_result_list[idx])

                        # 6. Task 상세(노드별) 결과 파일 parsing
                        result_list = dailycheck_result_parsing(viewrun_result_list[idx]['filepath'])

                        # 7.Task 상세(노드별) 결과 DB Insert (TASK_RUN_LIST_DTL table)
                        save_result = save_dailycheck_result_list_dtl(result_list, task_result_no)

                        # 8. 점검 결과가 모두 OK인지 여부 check 및 TASK_RUN_LIST 테이블에 update
                        if save_result:
                            # check_result = check_dailycheck_result_okyn(task_result_no)
                            check_result = check_dailycheck_result_okyn(task_result_no, viewrun_result_list[idx])

                            # 9. (모든 처리 성공 시) 결과 파일 삭제
                            if check_result:
                                delete_viewrun_result_file(viewrun_result_list[idx]['filepath'])

                        status_flag = False
                        break

                    # 2018.11.22 KYM added. 정해진 시간 내에 응답이 오지 않으면 timeout 처리
                    if timeout <= 0:
                        update_dailycheck_result_error(task_result_no)
                        save_dailycheck_result_error(task_result_no, 'Timeout occurred while performing Task')

                        status_flag = False
                        break

                    else:
                        # 2018.11.22 KYM Modified. 정해진 시간 내에 응답이 오지 않으면 timeout 처리
                        if timeout > 0:
                            current_app.logger.debug("viewrun <status:%r> ....... retry.........timeout : [%r]" % (viewrun_result_list[idx]['status'], timeout))
                            sleep(5)
                            timeout -= 5
                            continue

            else:
                current_app.logger.error("viewrun api call fail <task_id:%r> <instance_no:%r> <node_id:%r>" % (task_id, instance_no, node_id))

                # 2018.11.20 KYM added.
                update_dailycheck_result_error(task_result_no)
                save_dailycheck_result_error(task_result_no, viewrun_result['resultMsg'])
                ondemand_run_hist_edit.update_ondemand_run_hist(ondemand_no)
                return view_rst
                # break

        # print(view_rst)
    else:
        current_app.logger.error("rerun api call Fail <resultCode:%r> <resultMsg:%r>" % (rerun_result['resultCode'], rerun_result['resultMsg']))

        # 2018.11.20 KYM added.
        update_dailycheck_result_error(task_result_no)
        save_dailycheck_result_error(task_result_no, rerun_result['resultMsg'])
        ondemand_run_hist_edit.update_ondemand_run_hist(ondemand_no)
        return rerun_rst

    # 10. Task ondemand 수행 이력 DB Update
    update_rst = ondemand_run_hist_edit.update_ondemand_run_hist(ondemand_no)

    if update_rst:
        return 'Ondemand Daily Check Success^^'
    else:
        return 'Ondemand Daily Check Fail-_-'


def run_job(*args):
    """
    Opmate task 호출.
    :param args:
    :return:
    """
    import manage as mg
    result = mg.do_task_opmw_ondemand.delay(*args)

    return result.id
