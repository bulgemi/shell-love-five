# _*_ coding: utf-8 _*_

from flask import Flask
from flask_script import Manager
import logging.handlers
import logging


app = Flask(__name__)
app.config.update(DEBUG=True)
manager = Manager(app)

file_log_format = logging.Formatter("%(levelname)s in %(module)s [%(lineno)d]: %(message)s")

file_logger = logging.handlers.RotatingFileHandler("cellar.log", mode='a',
                                     maxBytes=1024*1024, backupCount=5,
                                     encoding='utf-8', delay=False)

# file_logger = logging.FileHandler("cellar.log")
# file_logger.setLevel(logging.DEBUG)
# file_logger.setLevel(logging.INFO)
# file_logger.setLevel(logging.WARNING)
# file_logger.setLevel(logging.ERROR)
file_logger.setLevel(logging.CRITICAL)

file_logger.setFormatter(file_log_format)
app.logger.addHandler(file_logger)


@app.route("/")
def hello():
    app.logger.debug("debug log.")
    app.logger.debug(u"디버그 로그입니다.")
    app.logger.info("info log.")
    app.logger.info(u"인포 로그입니다.")
    app.logger.warning("warning log.")
    app.logger.warning(u"워닝 로그입니다.")
    app.logger.error("error log.")
    app.logger.error(u"에러 로그입니다.")
    app.logger.critical("critical log.")
    app.logger.critical(u"크리티컬 로그입니다.")

    return "Hello World!<br/>환영합니다!"


if __name__ == "__main__":
    # app.run()
    manager.run()
