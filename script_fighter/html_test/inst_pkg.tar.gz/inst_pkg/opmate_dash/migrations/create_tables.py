# _*_ coding: utf-8 _*_

import sys
import os
import pymysql.cursors
import yaml
import codecs
import tables_stap2
# import tables_mpcr
import tables_opmw

sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

from app.cipher.crypto_util import AESCipher


aes = AESCipher()

# load config file
config_file = os.path.dirname(os.getcwd()) + "/app/config/cellar.yml"
cellar_config = yaml.load(codecs.open(config_file, "r", "euc-kr"))
database_config = cellar_config['Database']

db_host = database_config['Host']
db_port = database_config['Port']
db_name = database_config['DB']
db_user = database_config['User']
db_password = aes.decrypt(database_config['Password'])

# Connect to the database
connection = pymysql.connect(host=db_host,
                             port=int(db_port),
                             user=db_user,
                             password=db_password,
                             db=db_name,
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)


# TOMS연동이력[TOMS_MIG_HIST] table 생성.
def create_toms_mig_hist():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE TOMS_MIG_HIST (
            INIT_DTM VARCHAR(14) NOT NULL,
            DONE_DTM VARCHAR(14) NOT NULL,
            STATUS CHAR(1) NOT NULL,
            CONSTRAINT TOMS_MIG_HIST_PK PRIMARY KEY (INIT_DTM)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TOMS_MIG_HIST]")


# 사용자정의항목값[USR_DEF_ITM_VAL] table 생성.
def create_usr_def_itm_val():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE USR_DEF_ITM_VAL (
            ITM_ID VARCHAR(10) NOT NULL,
            VLD_VAL_SEQ INT(11) UNSIGNED NOT NULL,
            VLD_VAL VARCHAR(4000) NOT NULL,
            CONSTRAINT USR_DEF_ITM_VAL_PK PRIMARY KEY (ITM_ID, VLD_VAL_SEQ)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[USR_DEF_ITM_VAL]")


# 사용자정의항목[USR_DEF_ITM] table 생성.
def create_usr_def_itm():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE USR_DEF_ITM (
            ITM_ID VARCHAR(10) NOT NULL,
            ITM_TYP_CL_CD VARCHAR(10) NOT NULL,
            ITM_LEN INT(11) NOT NULL,
            CRE_USR VARCHAR(30) NOT NULL,
            UPD_USR VARCHAR(30) NOT NULL,
            CRE_DTM VARCHAR(14) NOT NULL,
            UPD_DTM VARCHAR(14) NOT NULL,
            CONSTRAINT USR_DEF_ITM_PK PRIMARY KEY (ITM_ID)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[USR_DEF_ITM]")


# Cellar사용자북마크[CELLAR_USER_BOOK_MARK] table 생성.
def create_cellar_user_book_mark():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE CELLAR_USER_BOOK_MARK (
            USR_ID VARCHAR(30) NOT NULL,
            BOOK_MARK_SEQ INT(11) UNSIGNED NOT NULL,
            RPT_ID VARCHAR(10) NOT NULL,
            CONSTRAINT CELLAR_USER_BOOK_MARK_PK PRIMARY KEY (USR_ID, RPT_ID)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[CELLAR_USER_BOOK_MARK]")


# 공통코드관리[COMM_CD_LST] table 생성.
def create_comm_cd_lst():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE COMM_CD_LST (
            COMM_CD_ID VARCHAR(10) NOT NULL,
            COMM_CD_NM VARCHAR(30) NOT NULL,
            COMM_CD_DESC VARCHAR(500) NOT NULL,
            CONSTRAINT COMM_CD_LST_PK PRIMARY KEY (COMM_CD_ID)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[COMM_CD_LST]")


# 공통코드상세[COMM_CD_DTL] table 생성.
def create_comm_cd_dtl():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE COMM_CD_DTL (
            COMM_CD_ID VARCHAR(10) NOT NULL,
            COMM_CD_VAL VARCHAR(10) NOT NULL,
            COMM_CD_VAL_NM VARCHAR(30) NOT NULL,
            COMM_CD_VAL_ENG_NM VARCHAR(30) NOT NULL,
            COMM_CD_VAL_DESC VARCHAR(500) NOT NULL,
            CONSTRAINT COMM_CD_DTL_PK PRIMARY KEY (COMM_CD_ID, COMM_CD_VAL)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[COMM_CD_DTL]")


# 항목관리[ITM_MGMT] table 생성.
def create_itm_mgmt():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE ITM_MGMT (
            ITM_ID VARCHAR(10) NOT NULL,
            ITM_CL_CD VARCHAR(10) NOT NULL,
            ITM_DTL_CL_CD VARCHAR(10) NOT NULL,
            ITM_NM VARCHAR(200) NOT NULL,
            ITM_ENG_NM VARCHAR(200),
            USR_DEF_ITM_REF VARCHAR(10) NOT NULL,
            ITM_STAT_CD VARCHAR(10) NOT NULL,
            ITM_STAT_DESC VARCHAR(50),
            CONSTRAINT ITM_MGMT_PK PRIMARY KEY (ITM_ID)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[ITM_MGMT]")


# 과제이력[RPT_HIST] table 생성.
def create_rpt_hist():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE RPT_HIST (
            RPT_ID VARCHAR(10) NOT NULL,
            RPT_NM VARCHAR(200) NOT NULL,
            RPT_STAT_CD VARCHAR(10) NOT NULL,
            RPT_DUE_DTM VARCHAR(14) NOT NULL,
            OWNR_ID VARCHAR(30) NOT NULL,
            RPT_CRE_DTM VARCHAR(14) NOT NULL,
            RPT_UPD_DTM VARCHAR(14) NOT NULL,
            RPT_FILE_NM VARCHAR(200) NOT NULL,
            RPT_FILE_DIR VARCHAR(500) NOT NULL,
            RPT_DESC VARCHAR(500),
            CONSTRAINT RPT_HIST_PK PRIMARY KEY (RPT_ID)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[RPT_HIST]")


# 과제이력작성자[RPT_HIST_WRKR] table 생성.
def create_rpt_hist_wrkr():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE RPT_HIST_WRKR (
            RPT_ID VARCHAR(10) NOT NULL,
            WRKR_SEQ int NOT NULL,
            WRKR_ID VARCHAR(30) NOT NULL,
            WRK_STAT_CD VARCHAR(10) NOT NULL,
            WRKR_RQST_DESC VARCHAR(500),
            CONSTRAINT RPT_HIST_WRKR_PK PRIMARY KEY (RPT_ID, WRKR_SEQ)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[RPT_HIST_WRKR]")


# 과제이력조회조건[RPT_HIST_SEL_COND] table 생성.
def create_rpt_hist_sel_cond():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE RPT_HIST_SEL_COND (
            RPT_ID VARCHAR(10) NOT NULL,
            COND_SEQ int NOT NULL,
            ITM_ID VARCHAR(10) NOT NULL,
            OP_CL_CD VARCHAR(10) NOT NULL,
            OPRND_VAL_1 VARCHAR(100),
            OPRND_VAL_2 VARCHAR(100),
            OPRND_VAL_3 VARCHAR(100),
            OPRND_VAL_4 VARCHAR(100),
            OPRND_VAL_5 VARCHAR(100),
            OPRND_VAL_6 VARCHAR(100),
            OPRND_VAL_7 VARCHAR(100),
            OPRND_VAL_8 VARCHAR(100),
            OPRND_VAL_9 VARCHAR(100),
            OPRND_VAL_10 VARCHAR(100),
            CONSTRAINT RPT_HIST_SEL_COND_PK PRIMARY KEY (RPT_ID, COND_SEQ)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[RPT_HIST_SEL_COND]")


# 과제이력출력항목[RPT_HIST_OUT_ITM] table 생성.
def create_rpt_hist_out_itm():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE RPT_HIST_OUT_ITM (
            RPT_ID VARCHAR(10) NOT NULL,
            ITM_SEQ int NOT NULL,
            ITM_ID VARCHAR(10) NOT NULL,
            CONSTRAINT RPT_HIST_OUT_ITM_PK PRIMARY KEY (RPT_ID, ITM_SEQ)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[RPT_HIST_OUT_ITM]")


# TOMS이관데이터[TOMS_MIG_DATA] table 생성.
def create_toms_mig_data():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE TOMS_MIG_DATA (
            RPT_ID VARCHAR(10) NOT NULL,
            ASST_MGMT_NUM VARCHAR(40),
            COMP_MGMT_NUM VARCHAR(10) NOT NULL,
            TOWER VARCHAR(10),
            DEV_CL VARCHAR(400),
            PART_YN CHAR(1),
            BOX_MDL_CL CHAR(1),
            BOX_ASST_MGMG_NUM VARCHAR(40),
            CUST_CORP VARCHAR(400),
            PROD_CORP VARCHAR(200),
            MDL_NM VARCHAR(200),
            SERIAL_NUM VARCHAR(1000),
            DEV_USE VARCHAR(200),
            ASST_STAT VARCHAR(400),
            NOCOST_MAINTN_PERIOD INT(11) UNSIGNED,
            INST_DT VARCHAR(8),
            FIRST_INST_DT VARCHAR(8),
            ADMIN_DEPT VARCHAR(200),
            ADMIN_1_CORP_NUM VARCHAR(10),
            ADMIN_1_NM VARCHAR(30),
            ADMIN_1_TEL VARCHAR(200),
            ADMIN_2_CORP_NUM VARCHAR(10),
            ADMIN_2_NM VARCHAR(30),
            ADMIN_2_TEL VARCHAR(200),
            DEV_OPER_CL VARCHAR(400),
            DOMAIN VARCHAR(400),
            PROV_SERV VARCHAR(400),
            HOST_NM VARCHAR(100),
            HOST_NICK_NM VARCHAR(100),
            SVR_USE VARCHAR(30),
            OS_NM VARCHAR(100),
            OS_VER VARCHAR(100),
            SVR_TYP VARCHAR(8),
            PRMRY_IP_ADDR VARCHAR(20),
            IP_ADDR VARCHAR(400),
            CPU_INST_TOT_CAPA VARCHAR(40),
            CPU_INST_EACH_CAPA VARCHAR(40),
            CPU_INST_QTY VARCHAR(40),
            EACH_CPU_CORE_QTY VARCHAR(40),
            TOT_USE_CPU_CORE_QTY VARCHAR(40),
            MAX_CPU_SLOT_QTY VARCHAR(40),
            CPU_TPY VARCHAR(20),
            MEM_INST_TOT_CAPA VARCHAR(40),
            MAX_MEM_CAPA VARCHAR(40),
            IN_DISK_INST_TOT_CAPA VARCHAR(40),
            IN_DISK_INST_QTY VARCHAR(400),
            MAX_DISK_SLOT_QTY VARCHAR(40),
            OUT_DISK_INST_TOT_CAPA VARCHAR(40),
            HA_YN CHAR(1),
            HA_TARGET_SVR_NM VARCHAR(400),
            HA_RELATION VARCHAR(20),
            PHYSI_CAPA VARCHAR(40),
            USABL_CAPA VARCHAR(40),
            COMP_MODE VARCHAR(20),
            DISK_INFO VARCHAR(400),
            RAID_TYP VARCHAR(10),
            TOT_PORT_QTY VARCHAR(40),
            USE_PORT_QTY VARCHAR(40),
            LICENSE_PORT_QTY VARCHAR(40),
            USABL_PORT_QTY VARCHAR(40),
            BAK_DEV_TOT_CAPA VARCHAR(40),
            BAK_DEV_QTY VARCHAR(40),
            HW_GRADE VARCHAR(400),
            NODE_NM VARCHAR(100),
            NETWORK_IP_ADDR VARCHAR(20),
            NETWORK_SW_VER VARCHAR(100),
            ASST_REVIEW VARCHAR(2000),
            CENTER_CL VARCHAR(200),
            INST_LOCATION VARCHAR(200),
            INST_FLOOR VARCHAR(200),
            INST_COORDINAT VARCHAR(40),
            INST_ADDR VARCHAR(500),
            SW_MID_CL VARCHAR(100),
            SW_SMAL_CL VARCHAR(100),
            SW_VER VARCHAR(200),
            LICENSE_TYP VARCHAR(50),
            LICENSE_TOT_QTY VARCHAR(30),
            LICENSE_USE_QTY VARCHAR(30),
            LICENSE_USABLE_QTY VARCHAR(40),
            CONSTRAINT TOMS_MIG_DATA_PK PRIMARY KEY (RPT_ID, COMP_MGMT_NUM)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TOMS_MIG_DATA]")


# 사용자정의데이터[USR_DEF_DATA] table 생성.
def create_usr_def_data():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE USR_DEF_DATA (
            DATA_TYP_CL_CD VARCHAR(10) NOT NULL,
            ITM_ID VARCHAR(10) NOT NULL,
            USR_DEF_DATA_KEY VARCHAR(50) NOT NULL,
            ITM_VAL VARCHAR(500) NOT NULL,
            ITM_VAL_ETC VARCHAR(500),
            CONSTRAINT USR_DEF_DATA_PK PRIMARY KEY (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY)
            ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[USR_DEF_DATA]")


# Cellar사용자[CELLAR_USER] table 생성.
def create_cellar_user():
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE CELLAR_USER (
            USR_ID VARCHAR(30) NOT NULL,
            USR_PW VARCHAR(500) NOT NULL,
            USR_NM VARCHAR(30) NOT NULL,
            USR_CORP_NUM VARCHAR(30) NOT NULL,
            DEPT_CL_CD VARCHAR(10) NOT NULL,
            SM_CL_CD VARCHAR(10) NOT NULL,
            DOMAIN_CL_CD VARCHAR(10) NOT NULL,
            FUNC_CL_CD VARCHAR(10) NOT NULL,
            JOIN_DTM VARCHAR(14) NOT NULL,
            EXPRD_DTM VARCHAR(14) NOT NULL,
            BOOK_MARK_QTY INT(11) UNSIGNED NOT NULL,
            ROLL_CL_CD VARCHAR(10) NOT NULL,
            USR_STAT_CD VARCHAR(10) NOT NULL,
            USR_STAT_DESC VARCHAR(500) NULL,
            MEMO VARCHAR(500) NULL,
            CONSTRAINT CELLAR_USER_PK PRIMARY KEY (USR_ID)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[CELLAR_USER]")


# TOMS연동이력[TOMS_MIG_HIST] table 삭제.
def drop_toms_mig_hist():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE TOMS_MIG_HIST CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[TOMS_MIG_HIST]")
    except:
        pass


# 사용자정의항목값[USR_DEF_ITM_VAL] table 삭제.
def drop_usr_def_itm_val():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE USR_DEF_ITM_VAL CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[USR_DEF_ITM_VAL]")
    except:
        pass


# 사용자정의항목[USR_DEF_ITM] table 삭제.
def drop_usr_def_itm():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE USR_DEF_ITM CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[USR_DEF_ITM]")
    except:
        pass


# Cellar사용자북마크[CELLAR_USER_BOOK_MARK] table 삭제.
def drop_cellar_user_book_mark():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE CELLAR_USER_BOOK_MARK CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[CELLAR_USER_BOOK_MARK]")
    except:
        pass


# Cellar사용자[CELLAR_USER] table 삭제.
def drop_cellar_user():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE CELLAR_USER CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[CELLAR_USER]")
    except:
        pass


# 사용자정의데이터[USR_DEF_DATA] table 삭제.
def drop_usr_def_data():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE USR_DEF_DATA CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[USR_DEF_DATA]")
    except:
        pass


# TOMS이관데이터[TOMS_MIG_DATA] table 삭제.
def drop_toms_mig_data():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE TOMS_MIG_DATA CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[TOMS_MIG_DATA]")
    except:
        pass


# 과제이력출력항목[RPT_HIST_OUT_ITM] table 삭제.
def drop_rpt_hist_out_itm():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE RPT_HIST_OUT_ITM CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[RPT_HIST_OUT_ITM]")
    except:
        pass


# 과제이력조회조건[RPT_HIST_SEL_COND] table 삭제.
def drop_rpt_hist_sel_cond():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE RPT_HIST_SEL_COND CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[RPT_HIST_SEL_COND]")
    except:
        pass


# 과제이력작성자[RPT_HIST_WRKR] table 삭제.
def drop_rpt_hist_wrkr():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE RPT_HIST_WRKR CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[RPT_HIST_WRKR]")
    except:
        pass


# 과제이력[RPT_HIST] table 삭제.
def drop_rpt_hist():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE RPT_HIST CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[RPT_HIST]")
    except:
        pass


# 항목관리[ITM_MGMT] table 삭제.
def drop_itm_mgmt():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE ITM_MGMT CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[ITM_MGMT]")
    except:
        pass


# 공통코드관리[COMM_CD_LST] table 삭제.
def drop_comm_cd_lst():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
        DROP TABLE COMM_CD_LST CASCADE
        '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[COMM_CD_LST]")
    except:
        pass


# 공통코드상세[COMM_CD_DTL] table 삭제.
def drop_comm_cd_dtl():
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
        DROP TABLE COMM_CD_DTL CASCADE
        '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[COMM_CD_DTL]")
    except:
        pass


# 사용자정의항목값[USR_DEF_ITM_VAL] table 초기 데이터 적재
def init_usr_def_itm_val():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE USR_DEF_ITM_VAL;
        INSERT INTO USR_DEF_ITM_VAL (ITM_ID, VLD_VAL_SEQ, VLD_VAL) VALUES ('ITM3000002', 1, 'Y');
        INSERT INTO USR_DEF_ITM_VAL (ITM_ID, VLD_VAL_SEQ, VLD_VAL) VALUES ('ITM3000002', 2, 'N');
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[USR_DEF_ITM_VAL]")
    except:
        print("[Error] Insert Data[USR_DEF_ITM_VAL]")


# 사용자정의항목[USR_DEF_ITM] table 초기 데이터 적재
def init_usr_def_itm():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE USR_DEF_ITM;
        INSERT INTO USR_DEF_ITM (ITM_ID, ITM_TYP_CL_CD, ITM_LEN, CRE_USR, UPD_USR, CRE_DTM, UPD_DTM) VALUES ('ITM3000001', 'TYP_D_0000', 100, 'kim@sk.com', 'kim@sk.com', '20171013153102', '20171013153102');
        INSERT INTO USR_DEF_ITM (ITM_ID, ITM_TYP_CL_CD, ITM_LEN, CRE_USR, UPD_USR, CRE_DTM, UPD_DTM) VALUES ('ITM3000002', 'TYP_D_0001', -1, 'hong@sk.com', 'lim@sk.com', '20171015172112', '20171213115142');
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[USR_DEF_ITM]")
    except:
        print("[Error] Insert Data[USR_DEF_ITM]")


# Cellar사용자북마크[CELLAR_USER_BOOK_MARK] table 초기 데이터 적재
def init_cellar_user_book_mark():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE CELLAR_USER_BOOK_MARK;
        INSERT INTO CELLAR_USER_BOOK_MARK (USR_ID, BOOK_MARK_SEQ, RPT_ID) VALUES ('kim@sk.com', 1, 'RPT00001');
        INSERT INTO CELLAR_USER_BOOK_MARK (USR_ID, BOOK_MARK_SEQ, RPT_ID) VALUES ('kim@sk.com', 2, 'RPT00012');
        INSERT INTO CELLAR_USER_BOOK_MARK (USR_ID, BOOK_MARK_SEQ, RPT_ID) VALUES ('kim@sk.com', 3, 'RPT00043');
        INSERT INTO CELLAR_USER_BOOK_MARK (USR_ID, BOOK_MARK_SEQ, RPT_ID) VALUES ('kim@sk.com', 4, 'RPT00024');
        INSERT INTO CELLAR_USER_BOOK_MARK (USR_ID, BOOK_MARK_SEQ, RPT_ID) VALUES ('lee@sk.com', 1, 'RPT00029');
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[CELLAR_USER_BOOK_MARK]")
    except:
        print("[Error] Insert Data[CELLAR_USER_BOOK_MARK]")


# Cellar사용자[CELLAR_USER] table 초기 데이터 적재
def init_cellar_user():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE CELLAR_USER;
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC)
        VALUES ('kim@sk.com', '1234', '김희선', 'P117500', 'TEAM001', 'SMR_U_0001', 'DMN_U_0001', 'FUNC000001', '20170405164108', '99999999999999', 9, 'ROLL001', 'STAT001', '');
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC)
        VALUES ('lee@sk.com', '1111', '이효리', 'P117501', 'TEAM001', 'SMR_U_0001', 'DMN_U_0002', 'FUNC000003', '20170406122311', '99999999999999', 4, 'ROLL002', 'STAT001', '');
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC)
        VALUES ('oh@sk.com', 'qwer', '오현경', 'P117502', 'TEAM001', 'SMR_U_0002', 'DMN_U_0001', 'FUNC000002', '20170407211056', '20171020211056', 0, 'ROLL002', 'STAT002', '퇴사로 인한 만료');
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC)
        VALUES ('ko@sk.com', 'qwer', '고현정', 'P117503', 'TEAM001', 'SMR_U_0004', 'DMN_U_0003', 'FUNC000001', '20170407211056', '20170407211056', 0, 'ROLL003', 'STAT002', '가입 승인 보류');
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('shon02@sk.com'          , '1234', '황오현', '04425', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('erickim@sk.com'         , '1234', '김지한', '04190', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('inmoya@sk.com'          , '1234', '강인모', '07099', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('khmhul@sk.com'          , '1234', '구항모', '07103', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('cybaster@sk.com'        , '1234', '권용규', '06683', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('kamza81@sk.com'         , '1234', '김경화', '05825', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('kyhe22@sk.com'          , '1234', '김경희', '06221', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('mylovs@sk.com'          , '1234', '김동욱', '06015', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('donghun_kim@sk.com'     , '1234', '김동훈', '08126', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('gale@sk.com'            , '1234', '김봉남', '05889', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('purecap@sk.com'         , '1234', '김상경', '07297', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('narodo71@sk.com'        , '1234', '김성곤', '04268', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('nnight@sk.com'          , '1234', '김성완', '02709', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('youngme_kim@sk.com'     , '1234', '김영미', '08659', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('daimang@sk.com'         , '1234', '김영석', '08215', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('perfectdragon@sk.com'   , '1234', '김완용', '07621', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('wow1027@sk.com'         , '1234', '김준범', '08568', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('kimhc@sk.com'           , '1234', '김현철', '07867', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('whityhj@sk.com'         , '1234', '김희진', '03897', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('crazyhacker@sk.com'     , '1234', '류한나', '05834', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('jjubai@sk.com'          , '1234', '박주원', '06479', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('yr.ban@sk.com'          , '1234', '반영란', '06454', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('kkbaek@sk.com'          , '1234', '백경기', '03261', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('taeeyoul@sk.com'        , '1234', '서태열', '07456', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('aerans@sk.com'          , '1234', '선애란', '04375', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('phuchi@sk.com'          , '1234', '송현호', '06506', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('heesub.song@sk.com'     , '1234', '송희섭', '04212', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('SHB@sk.com'             , '1234', '신항범', '04270', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('sm.ahn@sk.com'          , '1234', '안성민', '07026', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('jinyoung.yang@sk.com'   , '1234', '양진영', '04773', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('joonsik@sk.com'         , '1234', '엄준식', '07715', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('ekyeo@sk.com'           , '1234', '여은경', '09449', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('jswon82@sk.com'         , '1234', '원종성', '09598', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('needlethief@sk.com'     , '1234', '유두현', '07202', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('ghostsai@sk.com'        , '1234', '유석민', '06068', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('andy.cindy@sk.com'      , '1234', '이건춘', '03130', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('bclee@sk.com'           , '1234', '이범철', '03956', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('anabaral@sk.com'        , '1234', '이상은', '04226', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('shlee35@sk.com'         , '1234', '이석훈', '06971', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('ukyung@sk.com'          , '1234', '이유경', '05580', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('ljy616@sk.com'          , '1234', '이진용', '05087', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('hjlee10@sk.com'         , '1234', '이훈주', '04232', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('Meditch05@sk.com'       , '1234', '장영오', '05599', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('yungsoocho@sk.com'      , '1234', '조영수', '05796', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('maybe96@sk.com'         , '1234', '최정희', '05374', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('goodleo@sk.com'         , '1234', '한상현', '06117', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('bh.hwang@sk.com'        , '1234', '황병훈', '02863', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('neo1220@sk.com'         , '1234', '황제영', '05626', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('minskcc@sk.com'         , '1234', '강민'  , '08769', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('ysko@sk.com'            , '1234', '고영석', '09157', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('narae_kim@sk.com'       , '1234', '김나래', '08332', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('bjkim@sk.com'           , '1234', '김범종', '09162', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('thoowoo@sk.com'         , '1234', '김수우', '09679', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('kimsw89@sk.com'         , '1234', '김승원', '09251', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('inbum85@sk.com'         , '1234', '김인범', '07627', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('kimju8874@sk.com'       , '1234', '김주영', '08800', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('jintaekim@sk.com'       , '1234', '김진태', '09263', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('kimheejin@sk.com'       , '1234', '김희진', '08811', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('liby@sk.com'            , '1234', '박혜진', '09012', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('kayoungbae@sk.com'      , '1234', '배가영', '08835', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('syk@sk.com'             , '1234', '상용규', '08405', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('dh_song@sk.com'         , '1234', '송동환', '07694', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('simhc@sk.com'           , '1234', '심현철', '09296', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('eomht@sk.com'           , '1234', '엄희태', '09299', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('elnacro@sk.com'         , '1234', '오성환', '08433', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('amlove@sk.com'          , '1234', '원장희', '09459', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('venesa@sk.com'          , '1234', '윤여선', '06672', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('irockyou@sk.com'        , '1234', '이병욱', '08459', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('bonny@sk.com'           , '1234', '이보원', '09320', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('sk7365@sk.com'          , '1234', '이유정', '09179', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('seslee3@sk.com'         , '1234', '이휘웅', '07753', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('serendipity1205@sk.com' , '1234', '정동일', '09517', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('eternallover@sk.com'    , '1234', '정용민', '08096', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
        INSERT INTO CELLAR_USER (USR_ID, USR_PW, USR_NM, USR_CORP_NUM, DEPT_CL_CD, SM_CL_CD, DOMAIN_CL_CD, FUNC_CL_CD, JOIN_DTM, EXPRD_DTM, BOOK_MARK_QTY, ROLL_CL_CD, USR_STAT_CD, USR_STAT_DESC) VALUES ('junwoocho@sk.com'       , '1234', '조준우', '82192', 'TEM_U_0000', 'SMR_U_0099', 'DMN_U_0099', 'FUC_U_0099', '20180116170000', '99999999235959', 0, 'ROL_U_0002', 'USR_S_0000', NULL );
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[CELLAR_USER]")
    except:
        print("[Error] Insert Data[CELLAR_USER]")


# 사용자정의데이터[USR_DEF_DATA] table 초기 데이터 적재
def init_usr_def_data():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE USR_DEF_DATA;
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000001', 'SV147400', '201701', '');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000001', 'SV148097', '201112', '');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000001', 'SV148098', '202012', '');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000001', 'SV148100', '기타', '방화벽문제로 서버접근불가');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000001', 'SV148101', '201712', '');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000002', 'SV147400', '20170103', '');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000002', 'SV148097', '20170930', '');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000002', 'SV148098', '기타', '해당사항없음.');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000002', 'SV148100', '기타', '해당사항없음.');
        INSERT INTO USR_DEF_DATA (DATA_TYP_CL_CD, ITM_ID, USR_DEF_DATA_KEY, ITM_VAL, ITM_VAL_ETC) VALUES ('ORG_D_0000', 'ITM3000002', 'SV148101', '20150405', '');
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[USR_DEF_DATA]")
    except:
        print("[Error] Insert Data[USR_DEF_DATA]")


# TOMS이관데이터[TOMS_MIG_DATA] table 초기 데이터 적재
def init_toms_mig_data():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE TOMS_MIG_DATA;
        INSERT INTO TOMS_MIG_DATA (	RPT_ID,	ASST_MGMT_NUM,	COMP_MGMT_NUM,	TOWER,	DEV_CL,
            PART_YN, CUST_CORP,	PROD_CORP,	MDL_NM,	SERIAL_NUM,
            DEV_USE, ASST_STAT, NOCOST_MAINTN_PERIOD, INST_DT, FIRST_INST_DT,
            ADMIN_DEPT,	ADMIN_1_CORP_NUM, ADMIN_1_NM, ADMIN_1_TEL, ADMIN_2_CORP_NUM,
            ADMIN_2_NM, ADMIN_2_TEL, DEV_OPER_CL, DOMAIN,	PROV_SERV,
            HOST_NM, HOST_NICK_NM, SVR_USE, OS_NM, OS_VER,
            SVR_TYP, PRMRY_IP_ADDR, CPU_INST_TOT_CAPA, CPU_INST_EACH_CAPA, CPU_INST_QTY,
            EACH_CPU_CORE_QTY, TOT_USE_CPU_CORE_QTY, MAX_CPU_SLOT_QTY, CPU_TPY, MEM_INST_TOT_CAPA,
            IN_DISK_INST_TOT_CAPA, MAX_DISK_SLOT_QTY, HA_YN, CENTER_CL, INST_LOCATION,
            INST_FLOOR, INST_COORDINAT, INST_ADDR
        )
        VALUES (
            'MASTER0000', 'HW-EH-APF-160133', 'SV147400', 'Server', '기타',
            'N', 'SK텔레콤', '닉스테크', 'SafePC 관리전용서버', 'SKT-20161221_02',
            'SafePC 5.0 서버', '사용중', 12, '20161124', '20161124',
            'IT Infra본부 IT Architect팀', 'P042250', '한희태', '', 'BB40483',
            '고호선', '02-6100-0656', '운영', '보안', '유통망 네트워크 보안 정책',
            'SKT-SAFEPCAPDB-2', 'SKT-SAFEPCAPDB-2', 'DB+Application Server', '기타', 'CentOS 7.1',
            'Rack', '90.3.1.81', '28.8', '2.4', '2',
            '6', '12', '2', 'Xeon', '32',
            '0', '8', 'N', '보라매센타', 'SKT보라매빌딩',
            '6층 A동', '', '서울특별시 관악구 보라매로5길 1 (봉천동, SK텔레콤빌딩)'
        );
        INSERT INTO TOMS_MIG_DATA (
            RPT_ID, ASST_MGMT_NUM, COMP_MGMT_NUM, TOWER, DEV_CL,
            PART_YN, CUST_CORP, PROD_CORP, MDL_NM, SERIAL_NUM,
            DEV_USE, ASST_STAT, NOCOST_MAINTN_PERIOD, INST_DT, FIRST_INST_DT,
            ADMIN_DEPT, ADMIN_1_CORP_NUM, ADMIN_1_NM, ADMIN_1_TEL, ADMIN_2_CORP_NUM,
            ADMIN_2_NM, ADMIN_2_TEL, DEV_OPER_CL, DOMAIN, PROV_SERV,
            HOST_NM, HOST_NICK_NM, SVR_USE, OS_NM, OS_VER,
            SVR_TYP, PRMRY_IP_ADDR, CPU_INST_TOT_CAPA, CPU_INST_EACH_CAPA, CPU_INST_QTY,
            EACH_CPU_CORE_QTY, TOT_USE_CPU_CORE_QTY, MAX_CPU_SLOT_QTY, CPU_TPY, MEM_INST_TOT_CAPA,
            IN_DISK_INST_TOT_CAPA, MAX_DISK_SLOT_QTY, HA_YN, CENTER_CL, INST_LOCATION,
            INST_FLOOR, INST_COORDINAT, INST_ADDR
        )
        VALUES (
            'MASTER0000', 'HW-EH-APF-164552', 'SV148097', 'Server', '기타',
            'N', 'SK텔레콤', 'AVAYA', 'Avaya DL360p', '15AT52610011',
            '서부 CM 운영', '사용중', 12, '20161201', '20161201',
            '통신인프라서비스팀', '08332', '김나래', '02-6343-9305', '115781',
            '김성식', '02-6343-9306', '운영', '', '상담채널_CTI통합관리_고객센터',
            'SKT-CM0PAP41', 'SKT-CM0PAP41', 'Appliance Sever', 'Red Hat Enterprise Linux', '5.3',
            'Rack', '172.22.61.151', '6.9', '2.3', '1',
            '3', '3', '2', 'Xeon', '16',
            '600', '8', 'N', '고객센터', 'SKT광주송정사옥',
            '2층', 'SB2-1', '광주광역시 광산구 송도로 308 (송정동)SK텔레콤'
        );
        INSERT INTO TOMS_MIG_DATA (
            RPT_ID, ASST_MGMT_NUM, COMP_MGMT_NUM, TOWER, DEV_CL,
            PART_YN, CUST_CORP, PROD_CORP, MDL_NM, SERIAL_NUM,
            DEV_USE, ASST_STAT, NOCOST_MAINTN_PERIOD, INST_DT, FIRST_INST_DT,
            ADMIN_DEPT, ADMIN_1_CORP_NUM, ADMIN_1_NM, ADMIN_1_TEL, ADMIN_2_CORP_NUM,
            ADMIN_2_NM, ADMIN_2_TEL, DEV_OPER_CL, DOMAIN, PROV_SERV,
            HOST_NM, HOST_NICK_NM, SVR_USE, OS_NM, OS_VER,
            SVR_TYP, PRMRY_IP_ADDR, CPU_INST_TOT_CAPA, CPU_INST_EACH_CAPA, CPU_INST_QTY,
            EACH_CPU_CORE_QTY, TOT_USE_CPU_CORE_QTY, MAX_CPU_SLOT_QTY, CPU_TPY, MEM_INST_TOT_CAPA,
            IN_DISK_INST_TOT_CAPA, MAX_DISK_SLOT_QTY, HA_YN, CENTER_CL, INST_LOCATION,
            INST_FLOOR, INST_COORDINAT, INST_ADDR
        )
        VALUES (
            'MASTER0000', 'HW-EH-APF-164553', 'SV148098', 'Server', '기타',
            'N', 'SK텔레콤', 'AVAYA', 'Avaya DL360p', '15AT52610007',
            '서부 CM 운영', '사용중', 12, '20161201', '20161201',
            '통신인프라서비스팀', '08332', '김나래', '02-6343-9305', '115781',
            '김성식', '02-6343-9306', '운영', '', '상담채널_CTI통합관리_고객센터',
            'SKT-CM0PAP42', 'SKT-CM0PAP42', 'Appliance Sever', 'Red Hat Enterprise Linux', '5.3',
            'Rack', '172.22.61.152', '6.9', '2.3', '1',
            '3', '3', '2', 'Xeon', '16',
            '600', '8', 'N', '고객센터', 'SKT광주송정사옥',
            '2층', 'SB2-1', '광주광역시 광산구 송도로 308 (송정동)SK텔레콤'
        );
        INSERT INTO TOMS_MIG_DATA (
            RPT_ID, ASST_MGMT_NUM, COMP_MGMT_NUM, TOWER, DEV_CL,
            PART_YN, CUST_CORP, PROD_CORP, MDL_NM, SERIAL_NUM,
            DEV_USE, ASST_STAT, NOCOST_MAINTN_PERIOD, INST_DT, FIRST_INST_DT,
            ADMIN_DEPT, ADMIN_1_CORP_NUM, ADMIN_1_NM, ADMIN_1_TEL, ADMIN_2_CORP_NUM,
            ADMIN_2_NM, ADMIN_2_TEL, DEV_OPER_CL, DOMAIN, PROV_SERV,
            HOST_NM, HOST_NICK_NM, SVR_USE, OS_NM, OS_VER,
            SVR_TYP, PRMRY_IP_ADDR, CPU_INST_TOT_CAPA, CPU_INST_EACH_CAPA, CPU_INST_QTY,
            EACH_CPU_CORE_QTY, TOT_USE_CPU_CORE_QTY, MAX_CPU_SLOT_QTY, CPU_TPY, MEM_INST_TOT_CAPA,
            IN_DISK_INST_TOT_CAPA, MAX_DISK_SLOT_QTY, HA_YN, CENTER_CL, INST_LOCATION,
            INST_FLOOR, INST_COORDINAT, INST_ADDR
        )
        VALUES (
            'MASTER0000', 'HW-EH-APF-164555', 'SV148100', 'Server', '기타',
            'N', 'SK텔레콤', 'AVAYA', 'Avaya DL360p', '15AE32300022',
            '서부 AES 운영', '사용중', 12, '20161201', '20161201',
            '통신인프라서비스팀', '08332', '김나래', '02-6343-9305', '115781',
            '김성식', '02-6343-9306', '운영', '', '상담채널_CTI통합관리_고객센터',
            'SKT-AESPAP42', 'SKT-AESPAP42', 'Appliance Sever', 'Red Hat Enterprise Linux', '5.1',
            'Rack', '172.22.61.158', '13.8', '2.3', '1',
            '6', '6', '2', 'Xeon', '32',
            '600', '8', 'N', '고객센터', 'SKT광주송정사옥',
            '2층', 'SB2-1', '광주광역시 광산구 송도로 308 (송정동)SK텔레콤'
        );
        INSERT INTO TOMS_MIG_DATA (
            RPT_ID, ASST_MGMT_NUM, COMP_MGMT_NUM, TOWER, DEV_CL,
            PART_YN, CUST_CORP, PROD_CORP, MDL_NM, SERIAL_NUM,
            DEV_USE, ASST_STAT, NOCOST_MAINTN_PERIOD, INST_DT, FIRST_INST_DT,
            ADMIN_DEPT, ADMIN_1_CORP_NUM, ADMIN_1_NM, ADMIN_1_TEL, ADMIN_2_CORP_NUM,
            ADMIN_2_NM, ADMIN_2_TEL, DEV_OPER_CL, DOMAIN, PROV_SERV,
            HOST_NM, HOST_NICK_NM, SVR_USE, OS_NM, OS_VER,
            SVR_TYP, PRMRY_IP_ADDR, CPU_INST_TOT_CAPA, CPU_INST_EACH_CAPA, CPU_INST_QTY,
            EACH_CPU_CORE_QTY, TOT_USE_CPU_CORE_QTY, MAX_CPU_SLOT_QTY, CPU_TPY, MEM_INST_TOT_CAPA,
            IN_DISK_INST_TOT_CAPA, MAX_DISK_SLOT_QTY, HA_YN, CENTER_CL, INST_LOCATION,
            INST_FLOOR, INST_COORDINAT, INST_ADDR
        )
        VALUES (
            'MASTER0000', 'HW-EH-APF-164556', 'SV148101', 'Server', '기타',
            'N', 'SK텔레콤', 'Audiocodes', 'Mediant 4000B', 'FT2710086',
            '부산 SBC 운영', '사용중', 12, '20161201', '20161201',
            '통신인프라서비스팀', '08332', '김나래', '02-6343-9305', '115781',
            '김성식', '02-6343-9306', '운영', '', '상담채널_CTI통합관리_고객센터',
            'SKT-SBSPAP22', 'SKT-SBSPAP22', 'Appliance Sever', '기타', 'Linux',
            'Rack', '172.22.200.167', '1.25', '1.25', '1',
            '1', '1', '1', 'Xeon', '0',
            '0', '0', 'N', '고객센터', 'SKT부산센텀사옥',
            '2층', 'PS1-1', '부산광역시 해운대구 센텀중앙로 70 (우동)SK텔레콤부산데이타센타'
        );
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[TOMS_MIG_DATA]")
    except:
        print("[Error] Insert Data[TOMS_MIG_DATA]")


# 과제이력출력항목[RPT_HIST_OUT_ITM] table 초기 데이터 적재
def init_rpt_hist_out_itm():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE RPT_HIST_OUT_ITM;
        INSERT INTO RPT_HIST_OUT_ITM (RPT_ID, ITM_SEQ, ITM_ID) VALUES ('RPT00001', 1, 'ITM0000001');
        INSERT INTO RPT_HIST_OUT_ITM (RPT_ID, ITM_SEQ, ITM_ID) VALUES ('RPT00001', 2, 'ITM0000023');
        INSERT INTO RPT_HIST_OUT_ITM (RPT_ID, ITM_SEQ, ITM_ID) VALUES ('RPT00001', 3, 'ITM0000007');
        INSERT INTO RPT_HIST_OUT_ITM (RPT_ID, ITM_SEQ, ITM_ID) VALUES ('RPT00001', 4, 'ITM3000001');
        INSERT INTO RPT_HIST_OUT_ITM (RPT_ID, ITM_SEQ, ITM_ID) VALUES ('RPT00002', 1, 'ITM0000001');
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[RPT_HIST_OUT_ITM]")
    except:
        print("[Error] Insert Data[RPT_HIST_OUT_ITM]")


# 과제이력조회조건[RPT_HIST_SEL_COND] table 초기 데이터 적재
def init_rpt_hist_sel_cond():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE RPT_HIST_SEL_COND;
        INSERT INTO RPT_HIST_SEL_COND (RPT_ID, COND_SEQ, ITM_ID, OP_CL_CD, OPRND_VAL_1) VALUES ('RPT00001', 1, 'ITM0000001', 'OPT0001', 'HBC00%');
        INSERT INTO RPT_HIST_SEL_COND (RPT_ID, COND_SEQ, ITM_ID, OP_CL_CD, OPRND_VAL_1, OPRND_VAL_2, OPRND_VAL_3) VALUES ('RPT00001', 2, 'ITM0000027', 'OPT0005', 'Linux', 'AIX', 'HPUX');
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[RPT_HIST_SEL_COND]")
    except:
        print("[Error] Insert Data[RPT_HIST_SEL_COND]")


# 과제이력작성자[RPT_HIST_WRKR] table 초기 데이터 적재
def init_rpt_hist_wrkr():
    pass


# 과제이력[RPT_HIST] table 초기 데이터 적재
def init_rpt_hist():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE RPT_HIST;
        INSERT INTO RPT_HIST (RPT_ID, RPT_NM, RPT_STAT_CD, RPT_DUE_DTM, OWNR_ID, RPT_CRE_DTM, RPT_UPD_DTM, RPT_FILE_NM, RPT_FILE_DIR, RPT_DESC) VALUES ('RPT00001', '서버별OS확인', 'RPT_S_0000', '20170103120000', 'P117500', '20170101144307', '20170101205011', '서버별OS확인_20170101205011.xls', '/home/cellar/dat/201701', '홍길동M 요청으로 생성');
        INSERT INTO RPT_HIST (RPT_ID, RPT_NM, RPT_STAT_CD, RPT_DUE_DTM, OWNR_ID, RPT_CRE_DTM, RPT_UPD_DTM, RPT_FILE_NM, RPT_FILE_DIR, RPT_DESC) VALUES ('RPT00002', '서버별SW확인', 'RPT_S_0001', '20171225233100', 'P117500', '20171212233100', '20171212233100', '서버별SW확인_20171225233100.xls', '/home/cellar/dat/201712', '임꺽정A 요청으로 생성');
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[RPT_HIST]")
    except:
        print("[Error] Insert Data[RPT_HIST]")


# 항목관리[ITM_MGMT] table 초기 데이터 적재
def init_itm_mgmt():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = """
        TRUNCATE TABLE ITM_MGMT;
        INSERT INTO ITM_MGMT (ITM_ID, ITM_CL_CD, ITM_DTL_CL_CD, ITM_NM, ITM_ENG_NM, USR_DEF_ITM_REF, ITM_STAT_CD, ITM_STAT_DESC) VALUES ('ITM0000001', 'ORG_I_0001', 'TWR_I_0001', '자산관리번호', 'ASST_MGMT_NUM', 'ITM0000000', '01', '');
        INSERT INTO ITM_MGMT (ITM_ID, ITM_CL_CD, ITM_DTL_CL_CD, ITM_NM, ITM_ENG_NM, USR_DEF_ITM_REF, ITM_STAT_CD, ITM_STAT_DESC) VALUES ('ITM0000002', 'ORG_I_0001', 'TWR_I_0002', '자산관리번호', 'ASST_MGMT_NUM', 'ITM0000000', '01', '');
        INSERT INTO ITM_MGMT (ITM_ID, ITM_CL_CD, ITM_DTL_CL_CD, ITM_NM, ITM_ENG_NM, USR_DEF_ITM_REF, ITM_STAT_CD, ITM_STAT_DESC) VALUES ('ITM0000027', 'ORG_I_0001', 'TWR_I_0002', '고객사', 'CUST_CORP', 'ITM0000000', '01', '');
        INSERT INTO ITM_MGMT (ITM_ID, ITM_CL_CD, ITM_DTL_CL_CD, ITM_NM, ITM_ENG_NM, USR_DEF_ITM_REF, ITM_STAT_CD, ITM_STAT_DESC) VALUES ('ITM3000001', 'ORG_I_0000', 'TWR_I_0000', '장비내구연한', '', 'ITM9999999', '01', '');
        INSERT INTO ITM_MGMT (ITM_ID, ITM_CL_CD, ITM_DTL_CL_CD, ITM_NM, ITM_ENG_NM, USR_DEF_ITM_REF, ITM_STAT_CD, ITM_STAT_DESC) VALUES ('ITM3000002', 'ORG_I_0000', 'TWR_I_0000', '장비내구연한_기타', '', 'ITM3000001', '01', '');
        INSERT INTO ITM_MGMT (ITM_ID, ITM_CL_CD, ITM_DTL_CL_CD, ITM_NM, ITM_ENG_NM, USR_DEF_ITM_REF, ITM_STAT_CD, ITM_STAT_DESC) VALUES ('ITM3000003', 'ORG_I_0000', 'TWR_I_0000', '라이센스교체일', '', 'ITM9999999', '02', '라이센스만료일만 관리하면 되므로 필요없어짐. 요청자:코코몽, 요청일:20171108');
        INSERT INTO ITM_MGMT (ITM_ID, ITM_CL_CD, ITM_DTL_CL_CD, ITM_NM, ITM_ENG_NM, USR_DEF_ITM_REF, ITM_STAT_CD, ITM_STAT_DESC) VALUES ('ITM3000004', 'ORG_I_0000', 'TWR_I_0000', '라이센스교체일_기타', '', 'ITM3000003', '02', '라이센스만료일만 관리하면 되므로 필요없어짐. 요청자:코코몽, 요청일:20171108');
            """
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[ITM_MGMT]")
    except:
        print("[Error] Insert Data[ITM_MGMT]")


# 공통코드상세[COMM_CD_DTL] table 초기 데이터 적재
def init_comm_cd_dtl():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = '''
        TRUNCATE TABLE COMM_CD_DTL;
        -- 팀구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000001', 'TEM_U_0000', '통신인프라서비스팀', 'Tel. Infra Service Team', '통신인프라서비스팀');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000001', 'TEM_U_0001', '인프라기술혁신팀', 'Infra Tech. Innovation Team', '인프라기술혁신팀');
        -- Domain구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0000', '시스템', 'System', '시스템');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0001', '미들웨어', 'Middleware', '미들웨어');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0002', '데이터베이스', 'Database', '데이터베이스');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0003', 'TA', 'Tech. Architecture', 'Technical Architecture');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0004', '고객센터', 'Customer Center', '고객센터');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0005', 'SKB', 'SKB', 'SK Broadband');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0006', '백업', 'Backup', '백업');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0007', '소프트웨어', 'Software', '소프트웨어');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0008', 'PAAS사업개발', 'PAAS사업개발', 'PAAS사업개발');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0009', '플랫폼사업개발', '플랫폼사업개발', '플랫폼사업개발');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0010', '통신인프라성장전략UNIT관리', '통신인프라성장전략UNIT관리', '통신인프라성장전략UNIT관리');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000002', 'DMN_U_0099', '기타', 'Etc.', '기타');
        
        -- SM구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0000', '센터SM', 'Center SM', '센터SM');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0001', '사업SM', 'Biz. SM', '사업SM');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0002', 'SwingSM', 'Swing SM', 'SwingSM');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0003', '온라인SM', 'Online SM', '온라인SM');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0004', '과금SM', 'Billing SM', '과금SM');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0005', 'DT추진SM', 'DT SM', 'DT추진SM');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0006', 'PAAS사업개발', 'PAAS사업개발', 'PAAS사업개발');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0007', '플랫폼사업개발', '플랫폼사업개발', '플랫폼사업개발');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0008', '통신인프라성장전략UNIT관리', '통신인프라성장전략UNIT관리', '통신인프라성장전략UNIT관리');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000003', 'SMR_U_0099', '기타', 'Etc.', '기타');
        -- 연산자구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000004', 'OPR_D_0000', 'EQUAL'             , 'EQUAL'                      , 'EQUAL'                 );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000004', 'OPR_D_0001', 'NOT EQUAL'         , 'NOT EQUAL'                  , 'NOT EQUAL'             );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000004', 'OPR_D_0002', 'LIKE'              , 'LIKE'                       , 'LIKE'                  );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000004', 'OPR_D_0003', 'NOT LIKE'          , 'NOT LIKE'                   , 'NOT LIKE'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000004', 'OPR_D_0004', 'IN'                , 'IN'                         , 'IN'                    );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000004', 'OPR_D_0005', 'NOT IN'            , 'NOT IN'                     , 'NOT IN'                );
        -- 항목타입구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000005', 'TYP_D_0000', 'INPUT BOX'         , 'INPUT BOX'                  , 'INPUT BOX'             );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000005', 'TYP_D_0001', 'SELECT BOX'        , 'SELECT BOX'                 , 'SELECT BOX'            );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000005', 'TYP_D_0002', 'CALENDAR(YYYYMMDD)', 'CALENDAR(YYYYMMDD)'         , 'CALENDAR(YYYYMMDD)'    );
        -- 항목상태구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000006', 'ITM_S_0000', 'Reserved'          , 'Reserved'                   , 'Reserved'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000006', 'ITM_S_0001', 'Expired'           , 'Expired'                    , 'Expired'               );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000006', 'ITM_S_0002', 'Available'         , 'Available'                  , 'Available'             );
        -- 현황조사 상태코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000007', 'RPT_S_0000', '저장'              , 'Save'                       , '저장'                  );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000007', 'RPT_S_0001', '작성중'            , 'Editing'                    , '작성중'                );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000007', 'RPT_S_0002', '작성완료'          , 'Edited'                     , '작성완료'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000007', 'RPT_S_0003', '보고완료'          , 'Completed'                  , '보고완료'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000007', 'RPT_S_0004', '지연'              , 'Delayed'                    , '지연'                  );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000007', 'RPT_S_0005', '폐기'              , 'Discard'                    , '폐기'                  );
        -- 작성상태코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000008', 'WRK_S_0000', '작성중'            , 'Editing'                    , '작성중'                );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000008', 'WRK_S_0001', '작성완료'          , 'Edited'                     , '작성완료'              );
        -- 컬럼원천구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000009', 'ORG_I_0000', '사용자정의컬럼'    , 'User Defined'               , '사용자정의컬럼'        );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000009', 'ORG_I_0001', 'TOMS 이관컬럼'     , 'TOMS Mig.'                  , 'TOMS 이관컬럼'         );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000009', 'ORG_I_0002', 'MW 컬럼'           , 'Middleware'                 , 'MW 컬럼'               );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000009', 'ORG_I_0003', 'DB 컬럼'           , 'Database'                   , 'DB 컬럼'               );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000009', 'ORG_I_0004', '센터SM 컬럼'       , 'CenterSM'                   , '센터SM 컬럼'           );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000009', 'ORG_I_0005', 'OpMate 컬럼'       , 'OpMate'                   , 'OpMate 컬럼'           );
        -- 타워구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0000', '사용자정의컬럼'      , 'User Defined'             , '사용자정의컬럼'        );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0001', 'Server'              , 'Server'                   , 'Server'                );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0002', 'Software'            , 'Software'                 , 'Software'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0003', 'Storage'             , 'Storage'                  , 'Storage'               );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0004', 'Network'             , 'Network'                  , 'Network'               );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0005', 'Backup'              , 'Backup'                   , 'Backup'                );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0006', 'Facility'            , 'Facility'                 , 'Facility'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0007', 'Middleware'          , 'Middleware'               , 'Middleware'            );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0008', 'Database'            , 'Database'                 , 'Database'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0009', 'Title'               , 'Title'                    , 'Title'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0010', 'Result'              , 'Result'                   , 'Result'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0011', 'Value'               , 'Value'                    , 'Value'              );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000010', 'TWR_I_0012', 'Task 수행 결과 오류 컬럼'   , 'Task Error'  , 'Task 수행 결과 오류 컬럼'              );
        -- Function 구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0000', '시스템', 'System', '시스템');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0001', '미들웨어', 'Middleware', '미들웨어');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0002', '데이터베이스', 'Database', '데이터베이스');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0003', 'TA'          , 'Tech. Architecture', 'Technical Architecture' );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0004', '고객센터', 'Customer Center', '고객센터');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0005', 'SKB', 'SKB', 'SK Broadband');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0006', '백업', 'Backup', '백업');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0007', '소프트웨어', 'Software', '소프트웨어');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0008', 'PAAS사업개발', 'PAAS사업개발', 'PAAS사업개발');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0009', '플랫폼사업개발', '플랫폼사업개발', '플랫폼사업개발');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0010', '통신인프라성장전략UNIT관리', '통신인프라성장전략UNIT관리', '통신인프라성장전략UNIT관리');
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000011', 'FUC_U_0099', '기타', 'Etc.', '기타');
        -- 역할구분코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000012', 'ROL_U_0000', '관리자'      , 'Admin'             , '관리자'                 );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000012', 'ROL_U_0001', '일반사용자'  , 'Nomal User'        , '일반사용자'             );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000012', 'ROL_U_0002', '방문자'      , 'Guest'             , '방문자'                 );
        -- 사용자상태코드
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000013', 'USR_U_0000', '활성'        , 'Active'            , '활성'                   );
        INSERT INTO COMM_CD_DTL (COMM_CD_ID, COMM_CD_VAL, COMM_CD_VAL_NM, COMM_CD_VAL_ENG_NM, COMM_CD_VAL_DESC) VALUES ('0000000013', 'USR_U_0001', '비활성'      , 'Inactive'          , '비활성'                 );
        '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[COMM_CD_DTL]")
    except:
        print("[Error] Insert Data[COMM_CD_DTL]")


# 공통코드관리[COMM_CD_LST] table 초기 데이터 적재
def init_comm_cd_lst():
    try:
        with connection.cursor() as cursor:
            # Insert Data
            sql = '''
        TRUNCATE TABLE COMM_CD_LST;
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000001', '팀구분코드'      , '팀구분코드'              );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000002', 'Domain구분코드'  , 'Domain구분코드'          );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000003', 'SM구분코드'      , 'SM구분코드'              );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000004', '연산자구분코드'  , '연산자(Operator)구분코드');
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000005', '항목타입구분코드', '항목타입구분코드'        );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000006', '항목상태구분코드', '항목상태구분코드'        );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000007', '현황조사 상태코드', '현황조사 상태코드'        );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000008', '작성상태코드'    , '작성상태코드'            );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000009', '컬럼원천구분코드', '컬럼원천구분코드'        );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000010', '타워구분코드'    , '타워구분코드'            );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000011', 'Function구분코드', 'Function구분코드');
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000012', '역할구분코드'    , '역할구분코드'    );
        INSERT INTO COMM_CD_LST (COMM_CD_ID, COMM_CD_NM, COMM_CD_DESC) VALUES ('0000000013', '사용자상태코드'  , '사용자상태코드'  );
        '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[COMM_CD_LST]")
    except:
        print("[Error] Insert Data[COMM_CD_LST]")


def close_db():
    connection.close()


def create_db():
    create_comm_cd_lst()
    create_comm_cd_dtl()
    create_itm_mgmt()
    create_rpt_hist()
    create_rpt_hist_wrkr()
    create_rpt_hist_sel_cond()
    create_rpt_hist_out_itm()
    create_toms_mig_data()
    create_usr_def_data()
    create_cellar_user()
    create_cellar_user_book_mark()
    create_usr_def_itm()
    create_usr_def_itm_val()
    create_toms_mig_hist()
    # cellar step 2, add 2018.04.12. kim dong-hun
    tables_stap2.create_general_survey_book_mark(connection)
    tables_stap2.create_general_survey_data(connection)
    tables_stap2.create_general_survey_hist(connection)
    tables_stap2.create_general_survey_hist_out_itm(connection)
    tables_stap2.create_general_survey_hist_wrkr(connection)
    # cellar step 2 mpcr, add 2018.05.24. kim dong-hun
    # tables_mpcr.create_mpcr_category(connection)
    # tables_mpcr.create_mpcr_element(connection)
    # tables_mpcr.create_mpcr_hist(connection)
    # tables_mpcr.create_mpcr_item(connection)
    # tables_mpcr.create_mpcr_form(connection)
    # tables_mpcr.create_mpcr_data(connection)
    # tables_mpcr.create_mpcr_macro_input_param(connection)
    # opmw, add 2019.03.14. kim dong-hun
    tables_opmw.create_task_run_list(connection)
    tables_opmw.create_task_run_list_dtl(connection)
    tables_opmw.create_ondemand_run_hist(connection)
    tables_opmw.create_task_mgmt(connection)
    tables_opmw.create_tree_cat_mgmt(connection)
    tables_opmw.create_tree_node_mgmt(connection)
    tables_opmw.create_node_list(connection)


def drop_db():
    drop_comm_cd_lst()
    drop_comm_cd_dtl()
    drop_itm_mgmt()
    drop_rpt_hist()
    drop_rpt_hist_wrkr()
    drop_rpt_hist_sel_cond()
    drop_rpt_hist_out_itm()
    drop_toms_mig_data()
    drop_usr_def_data()
    drop_cellar_user()
    drop_cellar_user_book_mark()
    drop_usr_def_itm()
    drop_usr_def_itm_val()
    drop_toms_mig_hist()
    # cellar step 2, add 2018.04.12. kim dong-hun
    tables_stap2.drop_general_survey_book_mark(connection)
    tables_stap2.drop_general_survey_data(connection)
    tables_stap2.drop_general_survey_hist(connection)
    tables_stap2.drop_general_survey_hist_out_itm(connection)
    tables_stap2.drop_general_survey_hist_wrkr(connection)
    # cellar step 2 mpcr, add 2018.05.24. kim dong-hun
    # tables_mpcr.drop_mpcr_category(connection)
    # tables_mpcr.drop_mpcr_data(connection)
    # tables_mpcr.drop_mpcr_element(connection)
    # tables_mpcr.drop_mpcr_form(connection)
    # tables_mpcr.drop_mpcr_hist(connection)
    # tables_mpcr.drop_mpcr_item(connection)
    # tables_mpcr.drop_mpcr_macro_input_param(connection)
    tables_opmw.drop_task_run_list(connection)
    tables_opmw.drop_task_run_list_dtl(connection)
    tables_opmw.drop_ondemand_run_hist(connection)
    tables_opmw.drop_task_mgmt(connection)
    tables_opmw.drop_tree_cat_mgmt(connection)
    tables_opmw.drop_tree_node_mgmt(connection)
    tables_opmw.drop_node_list(connection)


def init_db():
    init_comm_cd_lst()
    init_comm_cd_dtl()
    init_itm_mgmt()
    init_rpt_hist()
    init_rpt_hist_wrkr()
    init_rpt_hist_sel_cond()
    init_rpt_hist_out_itm()
    init_toms_mig_data()
    init_usr_def_data()
    init_cellar_user()
    init_cellar_user_book_mark()
    init_usr_def_itm()
    init_usr_def_itm_val()
    # cellar step 2, add 2018.04.12. kim dong-hun
    tables_stap2.init_general_survey_book_mark(connection)
    tables_stap2.init_general_survey_data(connection)
    tables_stap2.init_general_survey_hist(connection)
    tables_stap2.init_general_survey_hist_out_itm(connection)
    tables_stap2.init_general_survey_hist_wrkr(connection)
    # cellar step 2 mpcr, add 2018.05.24. kim dong-hun
    # tables_mpcr.init_mpcr_category(connection)
    # tables_mpcr.init_mpcr_element(connection)
    # tables_mpcr.init_mpcr_form(connection)
    # tables_mpcr.init_mpcr_hist(connection)
    # tables_mpcr.init_mpcr_item(connection)


def all_db():
    drop_db()
    create_db()
    init_db()


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Usage: %s [create|drop|init|all]' % sys.argv[0])
        exit(0)

    if str(sys.argv[1]).upper() == 'CREATE':
        create_db()
    elif str(sys.argv[1]).upper() == 'DROP':
        drop_db()
    elif str(sys.argv[1]).upper() == 'INIT':
        init_db()
    else:
        all_db()

    close_db()
