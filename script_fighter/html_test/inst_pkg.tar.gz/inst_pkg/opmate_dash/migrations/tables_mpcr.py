# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'


# 월간 성능/용량 보고서 이력[MPCR_HIST] table 생성.
def create_mpcr_hist(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE MPCR_HIST (
            YEARMONTH  VARCHAR(6) NOT NULL,
            CATEGORY_CD VARCHAR(10) NOT NULL,
            CRE_DTM VARCHAR(14) NOT NULL,
            UPD_DTM VARCHAR(14) NOT NULL,
            UPD_USR VARCHAR(30) NOT NULL,
            STAT_CD VARCHAR(10) NOT NULL,
            FILE_NM VARCHAR(200) NOT NULL,
            FILE_DIR VARCHAR(500) NOT NULL,
            FINAL_OPINION_PERFORMANCE TEXT,
            FINAL_OPINION_CAPACITY TEXT,
            CONSTRAINT MPCR_HIST_PK PRIMARY KEY (YEARMONTH, CATEGORY_CD)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[MPCR_HIST]")


# 월간 성능/용략 보고서 이력[MPCR_HIST] table 삭제.
def drop_mpcr_hist(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE MPCR_HIST CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[MPCR_HIST]")
    except:
        pass


# 월간 성능/용량 보고서 이력[MPCR_HIST] table 초기 데이터 적재
def init_mpcr_hist(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE MPCR_HIST;
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO MPCR_HIST (
            YEARMONTH,
            CATEGORY_CD,
            CRE_DTM,
            UPD_DTM,
            UPD_USR,
            STAT_CD,
            FILE_NM,
            FILE_DIR
        ) VALUES (
            '201804',
            'INT_CSP',
            '20180501010000',
            '20180502133000',
            'donghun_kim@sk.com',
            'RPT_S_0001',
            'INT_CSP_201804.pptx',
            '/home/cellar/mpcr'
        );
            """
            cursor.execute(insert_sql_1)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[MPCR_HIST]")
    except:
        print("[Error] Insert Data[MPCR_HIST]")


# 월간 성능/용량 보고서 종류[MPCR_CATEGORY] table 생성.
def create_mpcr_category(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE MPCR_CATEGORY (
            CATEGORY_CD VARCHAR(10) NOT NULL,
            CATEGORY_NM_ENG VARCHAR(200) NOT NULL,
            CATEGORY_NM_KOR VARCHAR(500) NOT NULL,
            CATEGORY_STAT_CD VARCHAR(10) NOT NULL,
            CATEGORY_DESC VARCHAR(500),
            CONSTRAINT MPCR_CATEGORY_PK PRIMARY KEY (CATEGORY_CD)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[MPCR_CATEGORY]")


# 월간 성능/용략 보고서 종류[MPCR_CATEGORY] table 삭제.
def drop_mpcr_category(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE MPCR_CATEGORY CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[MPCR_CATEGORY]")
    except:
        pass


# 월간 성능/용량 보고서 종류[MPCR_CATEGORY] table 초기 데이터 적재
def init_mpcr_category(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE MPCR_CATEGORY;
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO MPCR_CATEGORY (
            CATEGORY_CD,
            CATEGORY_NM_ENG,
            CATEGORY_NM_KOR,
            CATEGORY_STAT_CD
        ) VALUES (
            'INT_CSP',
            'CSP',
            'CSP',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_1)

            # Insert Data
            insert_sql_2 = """
        INSERT INTO MPCR_CATEGORY (
            CATEGORY_CD,
            CATEGORY_NM_ENG,
            CATEGORY_NM_KOR,
            CATEGORY_STAT_CD
        ) VALUES (
            'ITF_MCG',
            'MCG',
            'MCG',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_2)

            # Insert Data
            insert_sql_3 = """
        INSERT INTO MPCR_CATEGORY (
            CATEGORY_CD,
            CATEGORY_NM_ENG,
            CATEGORY_NM_KOR,
            CATEGORY_STAT_CD
        ) VALUES (
            'INT_R2K',
            'R2K',
            'R2K',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_3)

            # Insert Data
            insert_sql_4 = """
        INSERT INTO MPCR_CATEGORY (
            CATEGORY_CD,
            CATEGORY_NM_ENG,
            CATEGORY_NM_KOR,
            CATEGORY_STAT_CD
        ) VALUES (
            'SWG_SMS',
            'SMS G/W',
            'SMS G/W',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_4)

            # Insert Data
            insert_sql_5 = """
        INSERT INTO MPCR_CATEGORY (
            CATEGORY_CD,
            CATEGORY_NM_ENG,
            CATEGORY_NM_KOR,
            CATEGORY_STAT_CD
        ) VALUES (
            'OSS_TRBS',
            'TRBS',
            'TRBS',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_5)

            # Insert Data
            insert_sql_6 = """
        INSERT INTO MPCR_CATEGORY (
            CATEGORY_CD,
            CATEGORY_NM_ENG,
            CATEGORY_NM_KOR,
            CATEGORY_STAT_CD
        ) VALUES (
            'SWG_SSO',
            'SSO',
            'SSO',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_6)

            # Insert Data
            insert_sql_7 = """
        INSERT INTO MPCR_CATEGORY (
            CATEGORY_CD,
            CATEGORY_NM_ENG,
            CATEGORY_NM_KOR,
            CATEGORY_STAT_CD
        ) VALUES (
            'SWG_USC',
            'U.Scan',
            'U.Scan',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_7)

            # Insert Data
            insert_sql_8 = """
        INSERT INTO MPCR_CATEGORY (
            CATEGORY_CD,
            CATEGORY_NM_ENG,
            CATEGORY_NM_KOR,
            CATEGORY_STAT_CD
        ) VALUES (
            'SWG_SWG',
            'Swing Infra',
            'Swing Infra',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_8)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[MPCR_CATEGORY]")
    except:
        print("[Error] Insert Data[MPCR_CATEGORY]")


# 월간 성능/용량 보고서 구성요소[MPCR_ELEMENT] table 생성.
def create_mpcr_element(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE MPCR_ELEMENT (
            ELEMENT_CD VARCHAR(10) NOT NULL,
            ELEMENT_NM_ENG VARCHAR(200) NOT NULL,
            ELEMENT_NM_KOR VARCHAR(500) NOT NULL,
            ELEMENT_STAT_CD VARCHAR(10) NOT NULL,
            ELEMENT_DESC VARCHAR(500),
            CONSTRAINT MPCR_ELEMENT_PK PRIMARY KEY (ELEMENT_CD)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[MPCR_ELEMENT]")


# 월간 성능/용략 보고서 구성요소[MPCR_ELEMENT] table 삭제.
def drop_mpcr_element(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE MPCR_ELEMENT CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[MPCR_ELEMENT]")
    except:
        pass


# 월간 성능/용량 보고서 구성요소[MPCR_ELEMENT] table 초기 데이터 적재
def init_mpcr_element(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE MPCR_ELEMENT;
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO MPCR_ELEMENT (
            ELEMENT_CD,
            ELEMENT_NM_ENG,
            ELEMENT_NM_KOR,
            ELEMENT_STAT_CD
        ) VALUES (
            'CCSI',
            'Composition Chart & System Info.',
            '구성도 및 시스템 정보',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_1)

            # Insert Data
            insert_sql_2 = """
        INSERT INTO MPCR_ELEMENT (
            ELEMENT_CD,
            ELEMENT_NM_ENG,
            ELEMENT_NM_KOR,
            ELEMENT_STAT_CD
        ) VALUES (
            'SSNS',
            'System Spec./Network Spec.',
            'System Spec./Network Spec.',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_2)

            # Insert Data
            insert_sql_3 = """
        INSERT INTO MPCR_ELEMENT (
            ELEMENT_CD,
            ELEMENT_NM_ENG,
            ELEMENT_NM_KOR,
            ELEMENT_STAT_CD
        ) VALUES (
            'MII',
            'Mandatory Inspection Items',
            '필수점검 항목',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_3)

            # Insert Data
            insert_sql_4 = """
        INSERT INTO MPCR_ELEMENT (
            ELEMENT_CD,
            ELEMENT_NM_ENG,
            ELEMENT_NM_KOR,
            ELEMENT_STAT_CD
        ) VALUES (
            'FO',
            'Final Opinion',
            '최종의견',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_4)

            # Insert Data
            insert_sql_5 = """
        INSERT INTO MPCR_ELEMENT (
            ELEMENT_CD,
            ELEMENT_NM_ENG,
            ELEMENT_NM_KOR,
            ELEMENT_STAT_CD
        ) VALUES (
            'BTA',
            'Business/Transaction Analysis',
            '업무/거래 분석',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_5)

            # Insert Data
            insert_sql_6 = """
        INSERT INTO MPCR_ELEMENT (
            ELEMENT_CD,
            ELEMENT_NM_ENG,
            ELEMENT_NM_KOR,
            ELEMENT_STAT_CD
        ) VALUES (
            'SVR',
            'Server',
            '서버',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_6)

            # Insert Data
            insert_sql_7 = """
        INSERT INTO MPCR_ELEMENT (
            ELEMENT_CD,
            ELEMENT_NM_ENG,
            ELEMENT_NM_KOR,
            ELEMENT_STAT_CD
        ) VALUES (
            'DB',
            'DB',
            'DB',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_7)

            # Insert Data
            insert_sql_8 = """
        INSERT INTO MPCR_ELEMENT (
            ELEMENT_CD,
            ELEMENT_NM_ENG,
            ELEMENT_NM_KOR,
            ELEMENT_STAT_CD
        ) VALUES (
            'STR',
            'Storage',
            'Storage',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_8)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[MPCR_ELEMENT]")
    except:
        print("[Error] Insert Data[MPCR_ELEMENT]")


# 월간 성능/용량 보고서 아이템[MPCR_ITEM] table 생성.
def create_mpcr_item(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE MPCR_ITEM (
            ITEM_CD VARCHAR(10) NOT NULL,
            ITEM_NM_ENG VARCHAR(200) NOT NULL,
            ITEM_NM_KOR VARCHAR(500) NOT NULL,
            ITEM_STAT_CD VARCHAR(10) NOT NULL,
            ITEM_DESC VARCHAR(500),
            CONSTRAINT MPCR_ITEM_PK PRIMARY KEY (ITEM_CD)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[MPCR_ITEM]")


# 월간 성능/용략 보고서 아이템[MPCR_ITEM] table 삭제.
def drop_mpcr_item(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE MPCR_ITEM CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[MPCR_ITEM]")
    except:
        pass


# 월간 성능/용량 보고서 아이템[MPCR_ITEM] table 초기 데이터 적재
def init_mpcr_item(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE MPCR_ITEM;
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'PCCICC',
            'Physical Composition Chart & Interface Composition Chart',
            'Physical 구성도 및 Interface 구성도',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_1)

            # Insert Data
            insert_sql_2 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'NCC',
            'Network Composition Chart',
            'N/W 구성도',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_2)

            # Insert Data
            insert_sql_3 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'SRU',
            'Server Resource Usage',
            '서버 Resource 사용량',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_3)

            # Insert Data
            insert_sql_4 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'SUSDUS',
            'Storage Usage Status/DB Usage Status',
            'Storage 사용현황/DB 사용현황',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_4)

            # Insert Data
            insert_sql_5 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'NUS',
            'Network Usage Status',
            'Network 사용현황',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_5)

            # Insert Data
            insert_sql_6 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'PR',
            'Performance Report',
            '성능 Report',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_6)

            # Insert Data
            insert_sql_7 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'LCC',
            'Logical Composition Chart',
            '논리 구성도',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_7)

            # Insert Data
            insert_sql_8 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'PCC',
            'Physical Composition Chart',
            '물리 구성도',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_8)

            # Insert Data
            insert_sql_9 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'MWP',
            'Performance-M/W',
            '성능-M/W',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_9)

            # Insert Data
            insert_sql_10 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'DBP',
            'Performance-DB',
            '성능-DB',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_10)

            # Insert Data
            insert_sql_11 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'STP',
            'Performance-Storage',
            '성능-Storage',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_11)

            # Insert Data
            insert_sql_12 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'TPRT',
            'Throughput & Response Time',
            '처리량 및 응답시간',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_12)

            # Insert Data
            insert_sql_13 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'AO',
            'Analytical Opinion',
            '분석의견',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_13)

            # Insert Data
            insert_sql_14 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'FUS',
            'F/S Usage Status',
            'F/S 사용현황',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_14)

            # Insert Data
            insert_sql_15 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'PFM',
            'Performance',
            '성능',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_15)

            # Insert Data
            insert_sql_16 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'RRTTP',
            'RAC Response Time/Throughput',
            'RAC 응답시간/Throughput',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_16)

            # Insert Data
            insert_sql_17 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'DBUA',
            'DB Usage Analysis',
            'DB 사용량 분석',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_17)

            # Insert Data
            insert_sql_18 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'TUS',
            'Tablespace Usage Status',
            'Tablespace 사용현황',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_18)

            # Insert Data
            insert_sql_19 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'US',
            'Usage Status',
            '사용현황',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_19)

            # Insert Data
            insert_sql_20 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'DS',
            'Disk Storage',
            'Disk Storage',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_20)

            # Insert Data
            insert_sql_21 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'SPS',
            'Storage Performance Summary',
            'Storage 성능요약',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_21)

            # Insert Data
            insert_sql_22 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'LUC',
            'Login Users Count',
            '로그인 사용자수',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_22)

            # Insert Data
            insert_sql_23 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'NWI',
            'Network Interval',
            'N/W 구간',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_23)

            # Insert Data
            insert_sql_24 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'ICNL',
            'Inter-Center Network Link',
            '센터간 N/W 연동구간',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_24)

            # Insert Data
            insert_sql_25 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'TPS',
            'TPS',
            'TPS',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_25)

            # Insert Data
            insert_sql_26 = """
        INSERT INTO MPCR_ITEM (
            ITEM_CD,
            ITEM_NM_ENG,
            ITEM_NM_KOR,
            ITEM_STAT_CD
        ) VALUES (
            'TOCS',
            'Timeout/Core',
            'Timeout/Core 현황',
            'ITM_S_0002'
        );
            """
            cursor.execute(insert_sql_26)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[MPCR_ITEM]")
    except:
        print("[Error] Insert Data[MPCR_ITEM]")


# 월간 성능/용량 보고서 양식[MPCR_FORM] table 생성.
def create_mpcr_form(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE MPCR_FORM (
            CATEGORY_CD VARCHAR(10) NOT NULL,
            ELEMENT_CD  VARCHAR(10) NOT NULL,
            ITEM_CD VARCHAR(10) NOT NULL,
            CATEGORY_SEQ INT NOT NULL,
            ELEMENT_SEQ INT NOT NULL,
            ITEM_SEQ INT NOT NULL,
            CONSTRAINT MPCR_FORM_PK PRIMARY KEY (CATEGORY_SEQ, ELEMENT_SEQ, ITEM_SEQ)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[MPCR_FORM]")


# 월간 성능/용략 보고서 양식[MPCR_HIST] table 삭제.
def drop_mpcr_form(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE MPCR_FORM CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[MPCR_FORM]")
    except:
        pass


# 월간 성능/용량 보고서 양식[MPCR_FORM] table 초기 데이터 적재
def init_mpcr_form(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE MPCR_FORM;
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO MPCR_FORM (
            CATEGORY_CD,
            ELEMENT_CD,
            ITEM_CD,
            CATEGORY_SEQ,
            ELEMENT_SEQ,
            ITEM_SEQ
        ) VALUES (
            'INT_CSP',
            'CCSI',
            'PCCICC',
            0,
            0,
            0
        );
            """
            cursor.execute(insert_sql_1)

            # Insert Data
            insert_sql_2 = """
        INSERT INTO MPCR_FORM (
            CATEGORY_CD,
            ELEMENT_CD,
            ITEM_CD,
            CATEGORY_SEQ,
            ELEMENT_SEQ,
            ITEM_SEQ
        ) VALUES (
            'INT_CSP',
            'CCSI',
            'NCC',
            0,
            0,
            1
        );
            """
            cursor.execute(insert_sql_2)

            # Insert Data
            insert_sql_3 = """
        INSERT INTO MPCR_FORM (
            CATEGORY_CD,
            ELEMENT_CD,
            ITEM_CD,
            CATEGORY_SEQ,
            ELEMENT_SEQ,
            ITEM_SEQ
        ) VALUES (
            'INT_CSP',
            'SSNS',
            '',
            0,
            1,
            -1
        );
            """
            cursor.execute(insert_sql_3)

            # Insert Data
            insert_sql_4 = """
        INSERT INTO MPCR_FORM (
            CATEGORY_CD,
            ELEMENT_CD,
            ITEM_CD,
            CATEGORY_SEQ,
            ELEMENT_SEQ,
            ITEM_SEQ
        ) VALUES (
            'INT_CSP',
            'MII',
            'SRU',
            0,
            2,
            0
        );
            """
            cursor.execute(insert_sql_4)

            # Insert Data
            insert_sql_5 = """
        INSERT INTO MPCR_FORM (
            CATEGORY_CD,
            ELEMENT_CD,
            ITEM_CD,
            CATEGORY_SEQ,
            ELEMENT_SEQ,
            ITEM_SEQ
        ) VALUES (
            'INT_CSP',
            'MII',
            'SUSDUS',
            0,
            2,
            1
        );
            """
            cursor.execute(insert_sql_5)

            # Insert Data
            insert_sql_6 = """
        INSERT INTO MPCR_FORM (
            CATEGORY_CD,
            ELEMENT_CD,
            ITEM_CD,
            CATEGORY_SEQ,
            ELEMENT_SEQ,
            ITEM_SEQ
        ) VALUES (
            'INT_CSP',
            'MII',
            'NUS',
            0,
            2,
            2
        );
            """
            cursor.execute(insert_sql_6)

            # Insert Data
            insert_sql_7 = """
        INSERT INTO MPCR_FORM (
            CATEGORY_CD,
            ELEMENT_CD,
            ITEM_CD,
            CATEGORY_SEQ,
            ELEMENT_SEQ,
            ITEM_SEQ
        ) VALUES (
            'INT_CSP',
            'MII',
            'PR',
            0,
            2,
            3
        );
            """
            cursor.execute(insert_sql_7)

            # Insert Data
            insert_sql_8 = """
        INSERT INTO MPCR_FORM (
            CATEGORY_CD,
            ELEMENT_CD,
            ITEM_CD,
            CATEGORY_SEQ,
            ELEMENT_SEQ,
            ITEM_SEQ
        ) VALUES (
            'INT_CSP',
            'FO',
            '',
            0,
            3,
            -1 
        );
            """
            cursor.execute(insert_sql_8)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[MPCR_FORM]")
    except:
        print("[Error] Insert Data[MPCR_FORM]")


# 월간 성능/용량 보고서 데이터[MPCR_DATA] table 생성.
def create_mpcr_data(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE MPCR_DATA (
            YEARMONTH  VARCHAR(6) NOT NULL,
            CATEGORY_CD VARCHAR(10) NOT NULL,
            ELEMENT_CD VARCHAR(10) NOT NULL,
            ITEM_CD VARCHAR(10) NOT NULL,
            DEPTH INT NOT NULL,
            SEQ INT NOT NULL,
            STAT_CD VARCHAR(10) NOT NULL,
            DATA VARCHAR(5000) NOT NULL,
            CONSTRAINT MPCR_HIST_PK PRIMARY KEY (YEARMONTH, CATEGORY_CD, ELEMENT_CD, ITEM_CD, DEPTH, SEQ)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[MPCR_DATA]")


# 월간 성능/용략 보고서 데이터[MPCR_DATA] table 삭제.
def drop_mpcr_data(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE MPCR_DATA CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[MPCR_DATA]")
    except:
        pass


# MPCR_MACRO_INPUT_PARAM(월간 성능/용량 보고서 Splunk 연동시 파라메터 데이터 관리) table 생성.
def create_mpcr_macro_input_param(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE MPCR_MACRO_INPUT_PARAM (
            MACRO_NAME VARCHAR(200) NOT NULL,
            PARM_INDEX INT NOT NULL,
            DATA_SEQ INT NOT NULL,
            DATA VARCHAR(500) NOT NULL,
            CONSTRAINT MPCR_HIST_PK PRIMARY KEY (MACRO_NAME, PARM_INDEX, DATA_SEQ)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[MPCR_MACRO_INPUT_PARAM]")


# MPCR_MACRO_INPUT_PARAM(월간 성능/용량 보고서 Splunk 연동시 파라메터 데이터 관리) table 삭제.
def drop_mpcr_macro_input_param(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE MPCR_MACRO_INPUT_PARAM CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[MPCR_MACRO_INPUT_PARAM]")
    except:
        pass
