# _*_ coding: utf-8 _*_

__author__ = 'kim kyung-hee'


# Task 수행 결과 이력[TASK_RUN_LIST] table 생성.
def create_task_run_list(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE TASK_RUN_LIST (
            TASK_RESULT_NO          INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,   -- Task 수행 결과 일련번호
            INSTANCE_NO             INT(20) UNSIGNED NOT NULL,                  -- Task Instance 번호
            NODE_ID                 VARCHAR(30) NOT NULL,                       -- Node ID
            EXEC_NO                 INT(5) UNSIGNED NOT NULL,                   -- 태스크 수행 번호
            TASK_ID                 VARCHAR(30),                                -- 점검 태스크 ID
            RUNNER_ID               VARCHAR(30),                                -- Task 수행 계정
            STATUS                  CHAR(1),                                    -- Task 수행 상태(R: 준비, C: 요청완료, S: 회신완료, F: 실패)
            START_DT                VARCHAR(14),                                -- 태스크 수행 시작 시간
            END_DT                  VARCHAR(14),                                -- 태스크 수행 종료 시간
            RESULT                  CHAR(1),                                    -- 실행결과(N: N/A, S: 성공, F: 실패)
            EXIT_CD                 INT(11) UNSIGNED ,                          -- 종료리턴코드(쉘스크립트의 최종 리턴값, 0이면 정상종료, 그 외엔 에러)
            RUN_RESULT              CHAR(1),                                    -- 수행점검최종결과(N: N/A, S: 성공, C: Check,확인필요)
            PRIMARY KEY(TASK_RESULT_NO),
            UNIQUE KEY(INSTANCE_NO, NODE_ID, EXEC_NO)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TASK_RUN_LIST]")


# Task 수행 결과 이력[ASK_RUN_LIST] table 삭제.
def drop_task_run_list(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE ASK_RUN_LIST CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[TASK_RUN_LIST]")
    except:
        pass


# Task 수행 결과 상세 이력 [TASK_RUN_LIST_DTL] table 생성.
def create_task_run_list_dtl(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE TASK_RUN_LIST_DTL (
            TASK_RESULT_NO          INT(20) UNSIGNED NOT NULL,          -- Task 수행 결과 일련번호
            DATA_TYP_CL_CD          VARCHAR(10) NOT NULL,               -- 데이터유형구분코드(Title, Result, Value)
            SEQ                     INT(11) UNSIGNED NOT NULL,          -- 데이터 일련번호
            DEPTH                   INT(5) UNSIGNED NOT NULL,           -- 항목 컬럼 번호
            ITM_VAL                 VARCHAR(4000),                      -- 항목값
            ITM_VAL_ETC             VARCHAR(500),                       -- 항목값_ETC
            PRIMARY KEY(TASK_RESULT_NO, DATA_TYP_CL_CD, SEQ, DEPTH),
            UNIQUE KEY(TASK_RESULT_NO, DATA_TYP_CL_CD, SEQ, DEPTH)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TASK_RUN_LIST_DTL]")


# Task 수행 결과 상세 이력[TASK_RUN_LIST_DTL] table 삭제.
def drop_task_run_list_dtl(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE TASK_RUN_LIST_DTL
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[TASK_RUN_LIST_DTL]")
    except:
        pass


# Ondemand 수행 이력 [ONDEMAND_RUN_HIST] table 생성.
def create_ondemand_run_hist(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE ONDEMAND_RUN_HIST (
            ONDEMAND_NO             INT(20) UNSIGNED NOT NULL AUTO_INCREMENT,   -- 온디맨드수행요청번호
            INSTANCE_NO             INT(20) UNSIGNED NOT NULL,                  -- Task Instance 번호
            NODE_ID                 VARCHAR(30) NOT NULL,                       -- Node ID
            RUNNER_ID               VARCHAR(30),                                -- 수행 계정
            REQ_DT                  VARCHAR(14),                                -- 수행 시작 시간
            TASK_RESULT_NO          INT(20) UNSIGNED NULL ,                     -- Task 수행 결과 일련번호
            STATUS                  CHAR(1),                                    -- 수행 상태(Running:R/Complete:C)
            PRIMARY KEY(ONDEMAND_NO),
            UNIQUE KEY(INSTANCE_NO, NODE_ID)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TASK_RUN_LIST_DTL]")


# Task 수행 결과 상세 이력[TASK_RUN_LIST_DTL] table 삭제.
def drop_ondemand_run_hist(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE ONDEMAND_RUN_HIST
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[ONDEMAND_RUN_HIST]")
    except:
        pass


# Function 별 태스크 관리 [TASK_MGMT] table 생성.
def create_task_mgmt(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE TASK_MGMT (
            TASK_ID                 VARCHAR(30) NOT NULL,       -- Task ID
            TITLE                   VARCHAR(256),               -- 대시보드에 표현할 타이틀
            VIEW_YN                 CHAR(1) NOT NULL,           -- 대시보드 화면 노출 여부
            WIDGET_ID               VARCHAR(4),                 -- 위젯 ID
            TASK_DESC               VARCHAR(500),               -- 설명 
            PRIMARY KEY(TASK_ID)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TASK_MGMT]")


# Function 별 태스크 관리 [TASK_MGMT] table 삭제.
def drop_task_mgmt(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE TASK_MGMT
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[TASK_MGMT]")
    except:
        pass


# 태스크 실행권한 관리 [TASK_AUTH] table 생성.
def create_task_auth(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE TASK_AUTH (
            TASK_ID                 VARCHAR(30) NOT NULL,       -- Task ID
            GROUP_CD_VAL            VARCHAR(36) NOT NULL,       -- 그룹코드값 명
            GROUP_CD_ID             VARCHAR(10) NOT NULL,       -- 그룹코드값
            PRIMARY KEY(TASK_ID, GROUP_CD_VAL)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TASK_AUTH]")


# Function 별 태스크 관리 [TASK_AUTH] table 삭제.
def drop_task_auth(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE TASK_AUTH
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[TASK_AUTH]")
    except:
        pass


# Tree 카테고리 관리 [TREE_CAT_MGMT] table 생성.
def create_tree_cat_mgmt(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE TREE_CAT_MGMT (
            CAT_ID         VARCHAR(50) NOT NULL,            -- 카테고리ID
            CAT_NM         VARCHAR(100) NOT NULL,           -- 카테고리명
            DEPTH          INT(5) UNSIGNED NOT NULL,        -- depth
            SEQ            INT(10) UNSIGNED NOT NULL,       -- 순번
            UPPER_CAT_ID   VARCHAR(50) NULL,                -- 상위 카테고리ID
            USE_YN         CHAR(1)     NOT NULL,            -- 사용여부
            PRIMARY KEY(CAT_ID)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TREE_CAT_MGMT]")


# Tree 카테고리 관리 [TASK_MGMT] table 삭제.
def drop_tree_cat_mgmt(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE TREE_CAT_MGMT
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[TREE_CAT_MGMT]")
    except:
        pass


# Tree 카테고리별 노드 관리 [TREE_NODE_MGMT] table 생성.
def create_tree_node_mgmt(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE TREE_NODE_MGMT (
            CAT_ID         VARCHAR(50) NOT NULL,          -- 카테고리ID
            NODE_ID        VARCHAR(50) NOT NULL,          -- Node ID  
            PRIMARY KEY(CAT_ID, NODE_ID)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[TREE_NODE_MGMT]")


# Tree 카테고리 관리 [TREE_NODE_MGMT] table 삭제.
def drop_tree_node_mgmt(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE TREE_NODE_MGMT
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[TREE_NODE_MGMT]")
    except:
        pass


# 노드 리스트 정보 관리 [NODE_LIST] table 생성.
def create_node_list(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE NODE_LIST (
            NODE_ID         VARCHAR(50) NOT NULL,          -- Node ID 
            AGENT_GUID      VARCHAR(50) NOT NULL,          -- Agent GUID
            AGENT_VER       VARCHAR(50) NOT NULL,          -- Agent Version
            OS_NAME         VARCHAR(10) NOT NULL,          -- OS Name   
            IP              VARCHAR(20) NOT NULL,          -- IP Address
            HOSTNAME        VARCHAR(50) NOT NULL,          -- Hostname
            STATUS          VARCHAR(1)  NOT NULL,          -- Agent Status
            HEARTBEAT_DT    VARCHAR(14) NOT NULL,          -- Heartbeat datetime
            CRT_DT          VARCHAR(14) NOT NULL,          -- Create datetime
            PRIMARY KEY(NODE_ID),
            UNIQUE KEY(NODE_ID, AGENT_GUID)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[NODE_LIST]")


# 노드 리스트 정보 [NODE_LIST] table 삭제.
def drop_node_list(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE NODE_LIST
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[NODE_LIST]")
    except:
        pass
