# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'


# 일반조사 이력[GENERAL_SURVEY_HIST] table 생성.
def create_general_survey_hist(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE GENERAL_SURVEY_HIST (
            SURVEY_ID VARCHAR(40) NOT NULL,
            SURVEY_NM VARCHAR(200) NOT NULL,
            SURVEY_STAT_CD VARCHAR(10) NOT NULL,
            SURVEY_DUE_DTM VARCHAR(14) NOT NULL,
            OWNR_ID VARCHAR(30) NOT NULL,
            SURVEY_CRE_DTM VARCHAR(14) NOT NULL,
            SURVEY_UPD_DTM VARCHAR(14) NOT NULL,
            SURVEY_FILE_NM VARCHAR(200) NOT NULL,
            SURVEY_FILE_DIR VARCHAR(500) NOT NULL,
            SURVEY_DESC VARCHAR(500),
            CONSTRAINT GENERAL_SURVEY_HIST_PK PRIMARY KEY (SURVEY_ID)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[GENERAL_SURVEY_HIST]")


# 일반조사 이력[GENERAL_SURVEY_HIST] table 삭제.
def drop_general_survey_hist(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE GENERAL_SURVEY_HIST CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[GENERAL_SURVEY_HIST]")
    except:
        pass


# 일반조사 이력[GENERAL_SURVEY_HIST] table 초기 데이터 적재
def init_general_survey_hist(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE GENERAL_SURVEY_HIST;
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO GENERAL_SURVEY_HIST (
            SURVEY_ID,
            SURVEY_NM,
            SURVEY_STAT_CD,
            SURVEY_DUE_DTM,
            OWNR_ID,
            SURVEY_CRE_DTM,
            SURVEY_UPD_DTM,
            SURVEY_FILE_NM,
            SURVEY_FILE_DIR,
            SURVEY_DESC
        ) VALUES (
            '60236d0d-2ecf-4bc2-9984-0f04fe118fe7',
            '캔미팅 참여조사',
            'STA0001',
            '20170103120000',
            'donghun_kim@sk.com',
            '201701011443307',
            '20170101205011',
            '60236d0d-2ecf-4bc2-9984-0f04fe118fe7_20170101205011.xls',
            '/home/cellar/dat/201701',
            '강인모 요청으로 생성'
        );
            """
            cursor.execute(insert_sql_1)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[GENERAL_SURVEY_HIST]")
    except:
        print("[Error] Insert Data[GENERAL_SURVEY_HIST]")


# 일반조사 이력 작성자[GENERAL_SURVEY_HIST_WRKR] table 생성.
def create_general_survey_hist_wrkr(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE GENERAL_SURVEY_HIST_WRKR (
            SURVEY_ID VARCHAR(40) NOT NULL,
            WRKR_SEQ INT(11) UNSIGNED NOT NULL,
            WRKR_ID VARCHAR(30) NOT NULL,
            WRK_STAT_CD VARCHAR(10) NOT NULL,
            WRK_UPD_DTM VARCHAR(14),
            WRKR_RQST_DESC VARCHAR(500),
            CONSTRAINT GENERAL_SURVEY_HIST_PK PRIMARY KEY (SURVEY_ID, WRKR_SEQ)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[GENERAL_SURVEY_HIST_WRKR]")


# 일반조사 이력 작성자[GENERAL_SURVEY_HIST_WRKR] table 삭제.
def drop_general_survey_hist_wrkr(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE GENERAL_SURVEY_HIST_WRKR CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[GENERAL_SURVEY_HIST_WRKR]")
    except:
        pass


# 일반조사 이력 작성자[GENERAL_SURVEY_HIST_WRKR] table 초기 데이터 적재
def init_general_survey_hist_wrkr(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE GENERAL_SURVEY_HIST_WRKR
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO GENERAL_SURVEY_HIST_WRKR (
            SURVEY_ID,
            WRKR_SEQ,
            WRKR_ID,
            WRK_STAT_CD,
            WRK_UPD_DTM,
            WRKR_RQST_DESC
        ) VALUES (
            '60236d0d-2ecf-4bc2-9984-0f04fe118fe7',
            1,
            'donghun_kim@sk.com',
            'WRK_S_0000',
            '20170101205011',
            'XX 부분 작성.'
        )
            """
            cursor.execute(insert_sql_1)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[GENERAL_SURVEY_HIST_WRKR]")
    except:
        print("[Error] Insert Data[GENERAL_SURVEY_HIST_WRKR]")


# 일반조사 출력항목[GENERAL_SURVEY_HIST_OUT_ITM] table 생성.
def create_general_survey_hist_out_itm(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE GENERAL_SURVEY_HIST_OUT_ITM (
            SURVEY_ID VARCHAR(40) NOT NULL,
            ITM_SEQ INT(11) UNSIGNED NOT NULL,
            ITM_ID VARCHAR(10) NOT NULL,
            CONSTRAINT GENERAL_SURVEY_HIST_PK PRIMARY KEY (SURVEY_ID, ITM_SEQ)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[GENERAL_SURVEY_HIST_OUT_ITM]")


# 일반조사 출력항목[GENERAL_SURVEY_HIST_OUT_ITM] table 삭제.
def drop_general_survey_hist_out_itm(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE GENERAL_SURVEY_HIST_OUT_ITM CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[GENERAL_SURVEY_HIST_OUT_ITM]")
    except:
        pass


# 일반조사 출력항목[GENERAL_SURVEY_HIST_OUT_ITM] table 초기 데이터 적재
def init_general_survey_hist_out_itm(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE GENERAL_SURVEY_HIST_OUT_ITM
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO GENERAL_SURVEY_HIST_OUT_ITM (
            SURVEY_ID,
            ITM_SEQ,
            ITM_ID
        ) VALUES (
            '60236d0d-2ecf-4bc2-9984-0f04fe118fe7',
            1,
            'ITM3000043'
        )
            """
            cursor.execute(insert_sql_1)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[GENERAL_SURVEY_HIST_OUT_ITM]")
    except:
        print("[Error] Insert Data[GENERAL_SURVEY_HIST_OUT_ITM]")


# 일반조사 데이터[GENERAL_SURVEY_DATA] table 생성.
def create_general_survey_data(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE GENERAL_SURVEY_DATA (
            DATA_TYP_CL_CD VARCHAR(10) NOT NULL,
            ITM_ID VARCHAR(10) NOT NULL,
            SURVEY_ID VARCHAR(40) NOT NULL,
            SEQ INT(11) UNSIGNED NOT NULL,
            ITM_VAL VARCHAR(500),
            ITM_VAL_ETC VARCHAR(500),
            CONSTRAINT GENERAL_SURVEY_HIST_PK PRIMARY KEY (DATA_TYP_CL_CD, ITM_ID, SURVEY_ID, SEQ)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[GENERAL_SURVEY_DATA]")


# 일반조사 데이터[GENERAL_SURVEY_DATA] table 삭제.
def drop_general_survey_data(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE GENERAL_SURVEY_DATA CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[GENERAL_SURVEY_DATA]")
    except:
        pass


# 일반조사 데이터[GENERAL_SURVEY_DATA] table 초기 데이터 적재
def init_general_survey_data(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE GENERAL_SURVEY_DATA;
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO GENERAL_SURVEY_DATA (
            DATA_TYP_CL_CD,
            ITM_ID,
            SURVEY_ID,
            SEQ,
            ITM_VAL
        ) VALUES (
            'ORG_I_0000',
            'ITM3000043',
            '60236d0d-2ecf-4bc2-9984-0f04fe118fe7',
            0,
            '테스트 데이터'
        );
            """
            cursor.execute(insert_sql_1)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[GENERAL_SURVEY_DATA]")
    except:
        print("[Error] Insert Data[GENERAL_SURVEY_DATA]")


# 일반조사 사용자 북마크[GENERAL_SURVEY_BOOK_MARK] table 생성.
def create_general_survey_book_mark(connection):
    with connection.cursor() as cursor:
        # Create a new table
        sql = '''
        CREATE TABLE GENERAL_SURVEY_BOOK_MARK (
            USR_ID VARCHAR(30) NOT NULL,
            BOOK_MARK_SEQ INT(11) UNSIGNED NOT NULL,
            SURVEY_ID VARCHAR(40) NOT NULL,
            CONSTRAINT GENERAL_SURVEY_HIST_PK PRIMARY KEY (USR_ID, BOOK_MARK_SEQ)
        ) DEFAULT CHARSET=utf8
        '''
        cursor.execute(sql)

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
    print("create table[GENERAL_SURVEY_BOOK_MARK]")


# 일반조사 사용자 북마크[GENERAL_SURVEY_BOOK_MARK] table 삭제.
def drop_general_survey_book_mark(connection):
    try:
        with connection.cursor() as cursor:
            # drop table
            sql = '''
            DROP TABLE GENERAL_SURVEY_BOOK_MARK CASCADE
            '''
            cursor.execute(sql)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("drop table[GENERAL_SURVEY_BOOK_MARK]")
    except:
        pass


# 일반조사 사용자 북마크[GENERAL_SURVEY_BOOK_MARK] table 초기 데이터 적재
def init_general_survey_book_mark(connection):
    try:
        with connection.cursor() as cursor:
            # truncate
            truncate_sql = """
        TRUNCATE TABLE GENERAL_SURVEY_BOOK_MARK
            """
            cursor.execute(truncate_sql)

            # Insert Data
            insert_sql_1 = """
        INSERT INTO GENERAL_SURVEY_BOOK_MARK (
            USR_ID,
            BOOK_MARK_SEQ,
            SURVEY_ID
        ) VALUES (
            'donghun_kim@sk.com',
            1,
            '60236d0d-2ecf-4bc2-9984-0f04fe118fe7'
        )
            """
            cursor.execute(insert_sql_1)

        # connection is not autocommit by default. So you must commit to save
        # your changes.
        connection.commit()
        print("Insert Data[GENERAL_SURVEY_BOOK_MARK]")
    except:
        print("[Error] Insert Data[GENERAL_SURVEY_BOOK_MARK]")
