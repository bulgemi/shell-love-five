# _*_ coding: utf-8 _*_

__author__ = 'kim dong-hun'

import sys
import os
import yaml
import codecs
import logging
import argparse
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

sys.path.append(os.path.dirname(os.path.abspath(os.path.dirname(__file__))))

from app.cipher.crypto_util import AESCipher


class ConfigInfo(object):
    database = None
    FetchSize = None
    logger = logging.getLogger()
    PoolSize = None

    def __init__(self, config_file, fetch_size, pool_size):
        config_info = yaml.load(codecs.open(config_file, "r", "euc-kr"))

        logging_info = config_info['Logging']

        self.logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter(logging_info['Format'])

        if logging_info['Path'] is None:
            log_file = "./{}".format('update_password.log')
        else:
            log_file = "{}/{}".format(logging_info['Path'], 'update_password.log')

        ch = logging.FileHandler(log_file)
        ch.setLevel(logging.DEBUG)
        ch.setFormatter(formatter)
        self.logger.addHandler(ch)

        self.FetchSize = fetch_size
        self.PoolSize = pool_size

        self.database = config_info['Database']


class Collector(object):
    conn = None
    logger = None
    pool_size = None

    query_user_info = """SELECT USR_ID, USR_PW """\
                      """FROM CELLAR_USER """\
                      """ORDER BY USR_ID """

    query_update_password = """UPDATE CELLAR_USER SET USR_PW = '{0}' """ \
                            """WHERE USR_ID = '{1}' """

    def __init__(self, address, port, db, user, password, pool_size, logger):
        db_uri = 'mysql+pymysql://{}:{}@{}:{}/{}'.format(user, password, address, port, db)

        self.engine = create_engine(db_uri, pool_size=pool_size, encoding='utf-8', convert_unicode=True)
        session = sessionmaker(bind=self.engine)
        self.session = session()
        self.logger = logger
        self.pool_size = pool_size

    def disconnect(self):
        self.session.close()

    def dump_query_user_info(self):
        return self.query_user_info

    def dump_query_update_password(self):
        return self.query_update_password

    def execute_query_user_info(self):
        statement = self.session.query('USR_ID', 'USR_PW')\
            .from_statement(self.query_user_info)

        self.logger.debug('statement=<%r>' % str(statement))

        return statement.all()

    def execute_query_update_password(self, usr_id, enc):
        try:
            self.session.execute(self.query_update_password.format(enc, usr_id))
            self.session.commit()
        except:
            self.session.rollback()
            return False
        return True


if __name__ == "__main__":
    reload(sys)
    sys.setdefaultencoding('utf-8')
    aes = AESCipher()

    result = True

    parser = argparse.ArgumentParser(description='Task Reminder Program.')

    parser.add_argument('-c', help='config file(full path)', required=True)
    args = parser.parse_args()

    config = ConfigInfo(args.c, 100, 5)
    collector = Collector(config.database['Host'], config.database['Port'], config.database['DB'],
                          config.database['User'], aes.decrypt(config.database['Password']),
                          config.PoolSize, config.logger)

    config.logger.debug("dump_query_user_info=<%r>" % collector.dump_query_user_info())

    user_info_list = collector.execute_query_user_info()

    for user_info in user_info_list:
        enc_password = aes.encrypt(user_info[1])
        config.logger.debug("user_info=<%r>, <%r>, <%r>"
                            % (user_info[0], user_info[1], enc_password))
        collector.execute_query_update_password(user_info[0], enc_password)

    collector.disconnect()
