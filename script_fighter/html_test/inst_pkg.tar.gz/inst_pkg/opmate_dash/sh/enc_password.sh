#!/bin/sh
source ~/.bashrc;
python $OPMATE_DASH/app/cipher/enc_password.py
