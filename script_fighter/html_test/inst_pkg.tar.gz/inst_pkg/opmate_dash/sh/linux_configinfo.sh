SerialNumber=`dmidecode -t system | grep "Serial Number:" | awk -F: '{print $2}' | sed 's/^ //g' | sed 's/ $//g' | awk '{ print $1 }' |  head -1`
sysName=`hostname`
id="${SerialNumber}\$\$${sysName}"
ProductName=`dmidecode -t system | grep "Product Name:" | awk -F: '{print $2}' | sed 's/^ //g'  | head -1`
Manufacturer=`dmidecode -t system | grep "Manufacturer:" | awk -F: '{print $2}' | sed 's/^ //g' | head -1`
numCPU=`cat /proc/cpuinfo | grep "physical id" | sort -u | wc -l`
ModelCPU=`cat /proc/cpuinfo | grep "model name" | awk -F: '{print $2}' | sed 's/^ //g' | head -1`
_numCorePerCPU=`cat /proc/cpuinfo | grep "core id" | sort -u | wc -l`
numCore=`expr ${numCPU} \* ${_numCorePerCPU}`
if [ ${numCPU} -eq 0 ]; then
        numCPU=`cat /proc/cpuinfo | grep "processor" | sort -u | wc -l`
	numCore=${numCPU}
fi
hrMemorySize=`free | grep "^Mem" | awk '{ print $2 }' | head -1`
hrDiskStorageCapacity=`df | awk '{if( $2 == "" ) { printf "%s   ",$1 } else {print $1"    ",$2,$3,$4,$5,$6}}' | awk '{ print $2 }' | grep "[0-9]" | grep -v "[a-zA-Z]" | awk 'BEGIN { Sum=0 } { Sum=Sum+$1 } END { print Sum}'`
sysDescr=`uname -a`
#_IP=`ifconfig | grep "inet addr" | grep -v "127.0.0.1" | awk -F: '{ print $2 }' | awk '{ print $1 }'`
#ipAdEntAddr=`for Line in $(echo ${_IP}); do echo -n "\"$Line\","; done  | sed 's/,$//g'`

echo "@@@type : OK - linux server dailycheck"
echo "@@@id : OK - ${id}"
echo "@@@agent : OK - OpMate linux agent"
echo "@@@SerialNumber : OK - ${SerialNumber}"
echo "@@@ProductName : OK - ${ProductName}"
echo "@@@Manufacturer : OK - ${Manufacturer}"
echo "@@@numCPU : CHECK - ${numCPU}"
echo "@@@ModelCPU : OK - ${ModelCPU}"
echo "@@@sysName : OK - ${sysName}"
echo "@@@numCore : OK - ${numCore}"
echo "@@@hrMemorySize : CHECK - ${hrMemorySize}"
echo "@@@hrDiskStorageCapacity : OK - ${hrDiskStorageCapacity}"
echo "@@@SysDescr : OK - ${sysDescr}"
