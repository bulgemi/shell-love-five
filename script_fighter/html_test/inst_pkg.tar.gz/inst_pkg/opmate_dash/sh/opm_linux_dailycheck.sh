#!/bin/sh
#####################################################################################################
## File name : . Auto_Install.sh
## Description : You can install automatically by looking at the Install menu and typing in the number you want.
##               This script contains the initial implementation requirements, such as SSR/Anycatcher/Ontune/Openssl
##               Also this script includes Linux checks.
## Information :
##
##=====================================================================================================
##  version   date       author      reason
##------------------------------------------------------------------------------------------------------
##  1.0    2017.12.2    S.W.KIM      First Created
##  2.0    2018.11.12   S.W.KIM      Add Function
##  3.0    2018.12.17   K.H.KIM      Edit Function
######################################################################################################
# ======<<<< Signal common processing logic (Start) >>>>==============================================
trap ' echo "$(date +${logdatefmt}) $0 signal(SIGINT ) captured" | tee -a ${logfnm}; exit 1;' SIGINT
trap ' echo "$(date +${logdatefmt}) $0 signal(SIGQUIT) captured" | tee -a ${logfnm}; exit 1;' SIGQUIT
trap ' echo "$(date +${logdatefmt}) $0 signal(SIGTERM) captured" | tee -a ${logfnm}; exit 1;' SIGTERM
# ======<<<< Signal common processing logic (End) >>>>================================================

# ======<<<< Important Global Variable Registration Area Marking Comment (Start) >>>>=================
# Log file name variable for storing script execution information:used in Signal common processing logic
#logfnm="execute information log full path name : ex) /applog/infra/os/osstdchk.sh.log"
logdatefmt="%Y%m%d-%H:%M:%S"   # date/time format variable for logging info :used in Signal common logic
export LANG=C
LOGPATH="/tmp"
HOST=`/bin/hostname`
IP=`\ifconfig -a | grep "inet " | grep "Bcast:" | awk '{print $2}' | awk -F: '{print $2}'| sed -n '1p'`
TODAY=`/bin/date +%Y%m%d`
DAY=`/bin/date +%d`
# ======<<<< Important Global Variable Registration Area Marking Comment (End) >>>>===================

tag_title="@@@"
op_tag_OK=" : OK"
op_tag_CHECK=" : CHECK"
op_tag_SKIP=" : OK"
tag_val=" - "

# ======<<<< Function Registration Area Marking Comment (Start) >>>>==================================
######################################################################################################
## function name : memcheck()
## description : Real Memory Check
## information : 
######################################################################################################

memcheck(){
echo $tag_title"Real Memory Check"$op_tag_OK$tag_val
echo "------------------------------------------------------------------" 
MEM_TOTAL=`free | grep ^Mem | awk '{print $2}'`
MEM_FREE1=`free | grep ^Mem | awk '{print $4}'`
MEM_FREE2=`free | grep ^-/+ | awk '{print $4}'`
MEM_NOMINAL=`echo "100-(100*$MEM_FREE1/$MEM_TOTAL)" | bc -l`
MEM_ACTUAL=`echo "100-(100*$MEM_FREE2/$MEM_TOTAL)" | bc -l`
echo NOMINAL=${MEM_NOMINAL:0:5}% ACTUAL=${MEM_ACTUAL:0:5}%
echo "------------------------------------------------------------------"
}

######################################################################################################
## function name : diskcheck()
## description : You can view disk information such as LVM, mount, multipath, and so on.
## information : 
######################################################################################################
diskscheck()
{
echo "------------------------------------------------------------------" 
echo $tag_title"Disk Check and Mount info"$op_tag_OK$tag_val
echo "------------------------------------------------------------------"
/sbin/fdisk -l 
echo "------------------------------------------------------------------" 
/bin/cat /proc/partitions 
echo "------------------------------------------------------------------" 
/sbin/pvs 
echo "------------------------------------------------------------------" 
/sbin/vgs 
echo "-----------------------------------------------------------------"
/sbin/lvs 
echo "-----------------------------------------------------------------"
/sbin/lvs -v 
echo "-----------------------------------------------------------------"
/sbin/lvs -v --segments
echo "-----------------------------------------------------------------"
echo "/sbin/multipath -ll" 
echo "-----------------------------------------------------------------" 
echo "/bin/cat /etc/multipath.conf" 
echo "-----------------------------------------------------------------" 
/bin/df -h     
echo "-----------------------------------------------------------------" 
/bin/df -i      
echo "-----------------------------------------------------------------"
/bin/mount     
echo "-----------------------------------------------------------------"
return 0
}


######################################################################################################
## function name : diskcheck()
## description : You can view disk information such as LVM, mount, multipath, and so on.
## information : 
######################################################################################################
networkscheck() 
{
echo "-----------------------------------------------------------------"
echo $tag_title"Network Check & Status"$op_tag_OK$tag_val
echo "-----------------------------------------------------------------"
/sbin/ifconfig -a 
echo "-----------------------------------------------------------------" 
/sbin/ifconfig -a | grep addr
echo "-----------------------------------------------------------------"
/sbin/ip addr list
echo "-----------------------------------------------------------------"
cat /proc/net/bonding/bond0
cat /proc/net/bonding/bond1
cat /proc/net/bonding/bond2 
cat /proc/net/bonding/bond3
cat /proc/net/bonding/bond4 
echo "-----------------------------------------------------------------" 
/sbin/ethtool eth0
/sbin/ethtool eth1 
/sbin/ethtool eth2 
/sbin/ethtool eth3 
/sbin/ethtool eth4 
/sbin/ethtool eth5
/sbin/ethtool eth6 
/sbin/ethtool eth7 
/sbin/ethtool eth8 
/sbin/ethtool eth9 
/sbin/ethtool eth10 
echo "------------------------------------------------------------" 
/bin/cat /etc/sysconfig/network 
/bin/cat /etc/sysconfig/network-scripts/ifcfg-*
echo "------------------------------------------------------------" 
echo " Network connectaion status" 
echo "------------------------------------------------------------" 
/bin/netstat -natpeu | grep ESTABLISHED 
echo "------------------------------------------------------------" 
/bin/netstat -natpeu | grep LISTEN      
echo "------------------------------------------------------------" 
}

######################################################################################################
## function name : cpuinfo()
## description : You can view cpu information
## information : 
######################################################################################################
cpusinfo() 
{
echo "------------------------------------------------------------"
echo $tag_title"CPU Model"$op_tag_OK$tag_val
echo "------------------------------------------------------------" 
/bin/cat /proc/cpuinfo | grep name 
echo "------------------------------------------------------------" 
echo "------------------------------------------------------------"
echo "#CPU load System(%), User(%)" 
echo "------------------------------------------------------------" 
top -b -n 1 | sed -ne '/Cpu/ s/.* \([0-9]*\.[0-9]*\)%us.* \([0-9]*\.[0-9]*\)%sy.*/User: \1%, System: \2%/p' 
echo "------------------------------------------------------------" 
return 0 
}

######################################################################################################
## function name : checksfilesystem()
## description : You can view filesystem information
## information : 
######################################################################################################
checksfilesystem()
{
echo "------------------------------------------------------------------" 
echo $tag_title"Check Filsystem status"$op_tag_OK$tag_val
echo "------------------------------------------------------------------"
for i in $(df -h | grep /dev | awk {'print $1'} | grep -v tmpfs) ;
  do echo $i; tune2fs -l $i; done
echo "------------------------------------------------------------------"
return 0 
}

######################################################################################################
## function name : checkdaemon()
## description : You can view daemon & preocess information
## information : 
######################################################################################################
checkdaemon()
{
echo "------------------------------------------------------------------" 
echo $tag_title"Check System Deamon & Process"$op_tag_OK$tag_val
echo "------------------------------------------------------------------"
/sbin/chkconfig --list | grep 3:on
echo "------------------------------------------------------------------" 
/usr/bin/pstree -a -n -p 
echo "------------------------------------------------------------------"
return 0 
}

######################################################################################################
## function name : checksystemlog()
## description : You can view systemlog information such as dmesg, var/log/message, var/log/cron
## information : 
######################################################################################################
checksystemlog()
{
echo "------------------------------------------------------------------"
echo $tag_title"Check SystemLog info"$op_tag_OK$tag_val
echo "------------------------------------------------------------------"
echo "# dmesg Log info"
echo "------------------------------------------------------------------"
/bin/dmesg | egrep -i -e error -e warning -e fail
echo "------------------------------------------------------------------"
echo "# Messages Log info"
echo "------------------------------------------------------------------"
/bin/cat /var/log/messages | egrep -i -e error -e warning -e fail
echo "------------------------------------------------------------------"
echo "# Crond Log info"
echo "------------------------------------------------------------------"
/bin/cat /var/log/cron | egrep -i -e error -e warning -e fail
echo "------------------------------------------------------------------"
return 0 
}
# ======<<<< Function Registration Area Marking Comment (End) >>>>====================================

# ======<<<< Main Logic Coding Area Marking Comment (Start) >>>=======================================
  echo "                                            "
  echo "============================================"
  echo -e "@@@HOSTNAME : CHECK - "$HOST
  echo "============================================"
  echo "                                            "
      memcheck 
      diskscheck 
      networkscheck 
      cpusinfo
      checksfilesystem 
      checkdaemon 
      checksystemlog 
# ======<<<< Main Logic Coding Area Marking Comment (End) >>>=========================================


