#!/bin/bash
###############################################################################################
## File name : HC_Check_Status.sh
## Description : Check system status / daily check items and generate normal / error results file. 
## Information : It is registered in crontab for automatic execution at a specific time every month. 
##          ex. (8:00 every day)  00 08 * * * /home/webwas/shl/dailychk/dailycheck.sh    1>/dev/null 2>&1
##        Usage : HC_Check_Status.sh [daily|pmcheck] [local]
##            daily : run daily check
##            pmcheck : run system status check
##            local : definitaion of display format. i
##                if without local option, display OPMATE parsing format.
##                if with local option, dispaly user freindly format.
##=======================================================================================
##  version   date     author    reason
##---------------------------------------------------------------------------------------
##  1.0    2018.10.27     RHN  First Created
###############################################################################################
# ======<<<< Signal common processing logic (Start) >>>>==============================================
trap ' echo "$(date +${logdatefmt}) $0 signal(SIGINT ) captured" | tee -a ${logfnm}; exit 1;' SIGINT
trap ' echo "$(date +${logdatefmt}) $0 signal(SIGQUIT) captured" | tee -a ${logfnm}; exit 1;' SIGQUIT
trap ' echo "$(date +${logdatefmt}) $0 signal(SIGTERM) captured" | tee -a ${logfnm}; exit 1;' SIGTERM 
# ======<<<< Signal common processing logic (End) >>>>================================================


# ======<<<< Important Global Variable Registration Area Marking Comment (Start) >>>>=================
# Log file name variable for storing script execution information:used in Signal common processing logic
# logfnm="execute information log full path name : ex) /applog/infra/os/osstdchk.sh.log"
logdatefmt="%Y%m%d-%H:%M:%S"   # date/time format variable for logging info :used in Signal common logic

# Path definitaion
MAINPATH="/SIT/scli/log/check"
TMPPATH="$MAINPATH/tmp"


TMPDIR="/skcc/dailycheck/tmp"
if [ ! -d ${TMPDIR} ];then
    mkdir -p ${TMPDIR}
    chmod 777 ${TMPDIR}
fi

if [ ! -d $TMPPATH ];then
    mkdir -p $TMPPATH
    chmod 777 $TMPPATH
fi

# Result tag
tag_OK="[ OK       ]"
tag_CHECK="[ CHECK    ]"
tag_skip="[ SKIP     ]"
tag_null="[ -------- ]"
tag_noti="[ NOTI     ]"

tag_title="@@@"
op_tag_OK=" : OK"
op_tag_CHECK=" : CHECK"
op_tag_SKIP=" : OK"
tag_val=" - "


# Customized Config
if [ -d "/root/system_check/" ]; then
    LAST_DAILY_CONFIG=`ls -rt /root/system_check/daily*.cfg | tail -1 2>&1 `
    if [ -f ${LAST_DAILY_CONFIG} ]; then
        MCONFIG=$LAST_DAILY_CONFIG
    fi
fi

MCONFIG="/skcc/SWADAgent/cfg/dailycheck.cfg"


# OS version
os_version=`uname -r`
OS5=`cat /etc/redhat-release | grep "release 5" | wc -l`
OS7=`cat /etc/redhat-release | grep "release 7" | wc -l`

os_v=`cat /etc/redhat-release | awk '{print $1}'`
os_r=`cat /etc/redhat-release | awk -F"release " '{print $2}' | awk '{print $1}'`"  "

# ======<<<< Important Global Variable Registration Area Marking Comment (End) >>>>===================


# ======<<<< Function Registration Area Marking Comment (Start) >>>>==================================
###########################################################################
##  Function Name : _uptime
##  Description : check os uptime
##  information : examples of output
##        - OPMATE : @@@Uptime : OK - 588days
##        - local : [ 588days  ] Uptime
###########################################################################
_uptime(){

    uptime=`uptime | awk '{print $3$4}' | awk -F"," '{print $1"        "}'`

    if [ -z "$1" ]; then
        echo $tag_title"Uptime"$op_tag_SKIP$tag_val$uptime
    elif [ $1 == "local" ]; then
        echo "[ ${uptime:0:7}  ] Uptime"
    fi
}



#os_v=`cat /etc/redhat-release | awk '{print $1}'`
#os_r=`cat /etc/redhat-release | awk -F"release " '{print $2}' | awk '{print $1}'`"  "

###########################################################################
##  Function Name : _osversion
##  Description : check os version 
##  information : examples of output
##              - OPMATE : @@@OS Version : OK - RHEL7.2
##              - local : [ RHEL7.2  ] OS Version
###########################################################################
_osversion(){
    if [ $os_v == "Red" ]; then
        if [ -z "$1" ]; then
            echo $tag_title"OS Version"$op_tag_SKIP$tag_val"RHEL"$os_r
        elif [ $1 == "local" ]; then
             echo "[ RHEL"${os_r:0:4}" ] OS Version"
        fi

    elif [ $os_v == "CentOS" ]; then
        if [ -z "$1" ]; then
            echo $tag_title"OS Version"$op_tag_SKIP$tag_val"CeOS"$os_r
        elif [ $1 == "local" ]; then
            echo "[ CeOS"${os_r:0:4}" ] OS Version"
        fi
    fi
}

###########################################################################
##  Function Name : _cpuutil
##  Description : check cpu utilization (# sar -p 1 1) 
##  information : examples of output
##              - OPMATE : @@@CPU Usage : OK - 5%
##              - local : [ 01%      ] CPU Usage
###########################################################################
# CPU Util
_cpuutil(){
    if [ -f /usr/bin/sar -o -f /bin/sar ]; then
        CPU_IDLE=`sar -p 1 1 | grep Aver | awk '{print $8}' | awk -F"." '{print $1}'`

        CPU_USAGE=`expr 100 - $CPU_IDLE`


        # get MAX CPU Usage Config
        if [ -f $MCONFIG ]; then
            if [ `cat $MCONFIG | grep "MAX_CPU_UTIL" | wc -l` -eq 0 ]; then
                MAX_CPU_UTIL=80
            else
                MAX_CPU_UTIL=`cat $MCONFIG | grep "MAX_CPU_UTIL" | awk '{ print $2 }' | head -1`
            fi

        else
            MAX_CPU_UTIL=80
        fi

        if [ -z "$1" ]; then
            if [ $CPU_USAGE -ge $MAX_CPU_UTIL ];then
                echo $tag_title"CPU Usage"$op_tag_CHECK$tag_val$CPU_USAGE"%"
            else
                echo $tag_title"CPU Usage"$op_tag_OK$tag_val$CPU_USAGE"%"
            fi

        elif [ $1 == "local" ]; then
            if [ $CPU_USAGE -lt 10 ]; then
                echo "[ 0$CPU_USAGE%      ] CPU Usage"
            else
                echo "[ $CPU_USAGE%      ] CPU Usage"
            fi
        fi
    else
        if [ -z "$1" ]; then
            echo $tag_title"CPU Usage"$op_tag_SKIP$tag_val"No sar"
        elif [ $1 == "local" ]; then
            echo "$tag_skip CPU Usage - No sar"
        fi
    fi
}

###########################################################################
##  Function Name : _memutil
##  Description : check memroy utilization (calculate with /proc/meminfo data) 
##  information : examples of output
##              - OPMATE : @@@CPU Usage : OK - 5%
##              - local : [ 01%      ] CPU Usage
###########################################################################
_memutil(){

    # get MAX Memory Usage Config
    if [ -f $MCONFIG ]; then
        if [ `cat $MCONFIG | grep "MAX_MEMORY_UTIL" | wc -l` -eq 0 ]; then
            MAX_MEM_UTIL=99
        else
            MAX_MEM_UTIL=`cat $MCONFIG | grep "MAX_MEMORY_UTIL" | awk '{ print $2 }' | head -1`
        fi
    else
        MAX_MEM_UTIL=99
    fi

    # get Memory Value from /proc/meminfo
    for MEM_LIST in `cat /proc/meminfo | awk '{print $2}'`
    do
        ARRAY_MEMLIST=("${ARRAY_MEMLIST[@]}" "`echo ${MEM_LIST}`")
    done

    # Memory Size Variables
    MEM_TSIZE=${ARRAY_MEMLIST[0]}
    MEM_FSIZE=${ARRAY_MEMLIST[1]}
    CACHE_SIZE=${ARRAY_MEMLIST[3]}

    #MEM_TSIZE=`cat /proc/meminfo | grep MemTotal | awk '{print $2}'`
    #MEM_FSIZE=`cat /proc/meminfo | grep MemFree | awk '{print $2}'`
    #CACHE_SIZE=`cat /proc/meminfo | grep Buffers | awk '{print $2}'`

    MEM_USIZE=`echo "((${MEM_TSIZE} - ${MEM_FSIZE} - ${CACHE_SIZE}) * 100) / ${MEM_TSIZE}" | bc`

    # Check Memory Usage over limit
    # Opmate
    if [ -z "$1" ]; then
        if [ $MEM_USIZE -ge $MAX_MEM_UTIL ];then
            echo $tag_title"Memory Usage"$op_tag_CHECK$tag_val$MEM_USIZE"%"
        else
            echo $tag_title"Memory Usage"$op_tag_OK$tag_val$MEM_USIZE"%"
        fi
    # Local
    elif [ $1 == "local" ]; then
        if [ $MEM_USIZE -lt 10 ]; then
            echo "[ 0$MEM_USIZE%      ] Memory Usage"
        else
            echo "[ $MEM_USIZE%      ] Memory Usage"
        fi
    fi


    # Dirty Page Usage 
    DIRTY_CRITICAL_RATIO=`cat /proc/sys/vm/dirty_ratio`

    DIRTY_SIZE=`cat /proc/meminfo | grep Dirty | awk '{print $2}'`

    if [ $CACHE_SIZE -eq 0 ]; then
        if [ -z "$1" ]; then
            echo $tag_title"Dirty Page Usage"$op_tag_SKIP$tag_val"Cache Size = 0MB"
        elif [ $1 == "local" ]; then
            echo "$tag_skip Dirty Page Usage : Cache Size = 0MB"
        fi
    else
        DIR_VAL=`echo "$DIRTY_SIZE * 100 / $CACHE_SIZE" | bc`
        DIR_PER=`echo "$DIR_VAL * 100 / $DIRTY_CRITICAL_RATIO" | bc`
    
        if [ $DIR_PER -gt 90 ]; then
            if [ -z "$1" ]; then
                # always OK when run dailycheck. tag = SKIP
                echo $tag_title"Dirty Page Usage"$op_tag_SKIP$tag_val$DIR_VAL" / "$DIRTY_CRITICAL_RATIO" = "$DIR_PER"% ; If consistently high, it could be occurred I/O issues."
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK (Optional) Dirty Page Usage ( "$DIR_VAL" / "$DIRTY_CRITICAL_RATIO" = "$DIR_PER"% ; If consistently high, it could be occurred I/O issues. )"
            fi
        else
            if [ -z "$1" ]; then
                echo $tag_title"Dirty Page Usage"$op_tag_OK$tag_val$DIR_VAL" / "$DIRTY_CRITICAL_RATIO" = "$DIR_PER"%"
            elif [ $1 == "local" ]; then
                echo "$tag_OK Dirty Page Usage ( "$DIR_VAL" / "$DIRTY_CRITICAL_RATIO" = "$DIR_PER"% )"
            fi
        fi
    fi

    # Swap

    # get MAX Swap Usage Config
    if [ -f $MCONFIG ]; then
        if [ `cat $MCONFIG | grep "MAX_SWAP_UTIL" | wc -l` -eq 0 ]; then
            MAX_SWAP_UTIL=30
        else
            MAX_SWAP_UTIL=`cat $MCONFIG | grep "MAX_SWAP_UTIL" | awk '{ print $2 }' | head -1`
        fi
    else
        MAX_SWAP_UTIL=30
    fi

    # get swap value
    SWAP_SIZE=`cat /proc/meminfo | grep SwapTotal | awk '{print $2}'`
    SWAP_FREE=`cat /proc/meminfo | grep SwapFree | awk '{print $2}'`
    SWAP_USEP=`echo "($SWAP_SIZE - $SWAP_FREE) * 100 / $SWAP_SIZE" | bc`

    if [ -z "$1" ]; then
        if [ $SWAP_USEP -ge $MAX_SWAP_UTIL ];then
            echo $tag_title"Swap Usage"$op_tag_CHECK$tag_val$SWAP_USEP"%"
        else
            echo $tag_title"Swap Usage"$op_tag_OK$tag_val$SWAP_USEP"%"
        fi
    elif [ $1 == "local" ]; then
        if [ $SWAP_USEP -lt 10 ]; then
            echo "[ 0$SWAP_USEP%      ] Swap Usage"
        else
            echo "[ $SWAP_USEP%      ] Swap Usage"
        fi
    fi
}

###########################################################################
##  Function Name : _multipath
##  Description : check multipath (1. device list - name, size / 2. numbers of device path)
##  information : examples of output
##              - OPMATE : 
##                @@@Check Multipath Device List : OK
##                @@@Check Multipath Status : OK
##                @@@Check Multipath Device List : CHECK -
##                -------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------
##                FILE106 (36a8ca7b10081cbafd46affbd00000188)  HUAWEI  ,XSG1    | FILE006 (36a8ca7b10081cbafd46affbd00000188)  HUAWEI  ,XSG1   
##                   6 FILE007                                                  |    7 FILE007
##                -------------------------------------------------------------------------------------------------------------------------------
##              - local : 
##                [ OK       ] Check Multipath Device List
##                [ CHECK    ] Check Multipath Device List
##                -------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------
##                FILE106 (36a8ca7b10081cbafd46affbd00000188)  HUAWEI  ,XSG1    | FILE006 (36a8ca7b10081cbafd46affbd00000188)  HUAWEI  ,XSG1   
##                6 FILE007                                                  |    7 FILE007
##                -------------------------------------------------------------------------------------------------------------------------------
##                [ OK       ] Check Multipath Status
###########################################################################
_multipath(){

    # if /sbin/multipath file exists,
    if [ -f /sbin/multipath ]; then

        # if no save date, skip check function
        if [ ! -f $MAINPATH/multipath_save.out ]; then
            
            if [ -z "$1" ]; then
                echo $tag_title"Check Multipath Device List"$op_tag_SKIP$tag_val"no save multipath file"
            elif [ $1 == "local" ]; then
                echo "$tag_skip Check Multipath Device List - no save multipath file"
            fi
			
        else
        # if save data exists,
    
            if [ `stat -c%s $MAINPATH/multipath_save.out` -eq 0 ]; then

                if [ -z "$1" ]; then
                    echo $tag_title"Check Multipath Device List"$op_tag_SKIP$tag_val"save multipath file size is zero"
                elif [ $1 == "local" ]; then
                    echo "$tag_skip Check Multipath Device List - save multipath file size is zero"
                fi

            else

                # definition of variables
                TEMP="$TMPPATH/mpath.tmp"
                L=0
                SAVE_PATH="$MAINPATH/mpath_save"
                OUTPUT_PATH="$MAINPATH/mpath_check"
                ALL_SAVE="$MAINPATH/mpath_save.log"
                ALL_SAVE_DEV="$MAINPATH/mpath_save_dev.log"
                SAVE_PCNT="$MAINPATH/mpath_save_cnt.log"
                ALL_CHECK=$MAINPATH/mpath_`date +%Y%m%d%H%M%S`.log
                ALL_CHECK_DEV=$MAINPATH/mpath_`date +%Y%m%d%H%M%S`_dev.log
                CHECK_PCNT=$MAINPATH/mpath_`date +%Y%m%d%H%M%S`_cnt.log
                MPATH_LIST=$MAINPATH/multipath_check.out                # # multipath -ll
                MPATH_DEV=$MAINPATH/multipath_dev.out                   # list of device name ; # multipath -ll | grep dm-
                
                
                # multipath device array - will sorted by device name
                if [ $OS5 -eq 1 ]; then 
                    declare -a mpath_array
                else    
                    declare -A mpath_array
                fi      
                
                
                
                # if no directory, make the directory
                if [ ! -d $OUTPUT_PATH ] ; then
                    mkdir -p $OUTPUT_PATH
                    chmod 755 $OUTPUT_PATH
                fi
                
                
                multipath -ll | grep -v `date +%b` > $MPATH_LIST
                
                cat -n $MPATH_LIST | grep "dm-" > $MPATH_DEV
                
                
                # make files of device name under $OUTPUT_PATH (ex. FILE001, DATA001)
                # because the result of # multipath -ll is not sorted by name
                
                i=0
                
                while read line
                do
                    mpath_array[$i,0]=`echo $line | awk '{print $1}'`
                    mpath_array[$i,1]=`echo $line | awk '{print $2}'`
                
                    i=`expr $i + 1`
                
                done < $MPATH_DEV
                
                
                for((j=0;j<$i;j++))
                do
                    k=`expr $j + 1`
                
                    if [ $j -lt `expr $i - 1` ]; then
                        NEXT=`expr ${mpath_array[$k,0]} - 1`
                        sed -n ${mpath_array[$j,0]},$NEXT"p" $MPATH_LIST > $OUTPUT_PATH/${mpath_array[$j,1]}
                    else
                        sed -n ${mpath_array[$j,0]},'$p' $MPATH_LIST > $OUTPUT_PATH/${mpath_array[$j,1]}
                    fi
                done
                
                
                # find before status, and make save data file
                if [ `ls -al $SAVE_PATH | wc -l` -eq 3 ];then
                    LAST_MPATH_SUMMARY=`ls -rt $MAINPATH/mpath_*.log | tail -3 | sed -n '1p' 2>&1 `
                    ALL_SAVE=$LAST_MPATH_SUMMARY
                else
                    cat $SAVE_PATH/* > $ALL_SAVE
                fi
                
                # before - device name, size
                cat $ALL_SAVE | sed 's/dm-[0-9][0-9][0-9]//g' | sed 's/dm-[0-9][0-9]//g' | sed 's/dm-[0-9]//g' | grep -v "\- " > $ALL_SAVE_DEV

                # before - device path count
                cd $SAVE_PATH; ls | xargs wc -l | grep -v total > $SAVE_PCNT
                
                # make current data file
                cat $OUTPUT_PATH/* > $ALL_CHECK
                
                # current - device name, size
                cat $ALL_CHECK | sed 's/dm-[0-9][0-9][0-9]//g' | sed 's/dm-[0-9][0-9]//g' | sed 's/dm-[0-9]//g' | grep -v "\- " > $ALL_CHECK_DEV

                # current - device path count
                cd $OUTPUT_PATH; ls | xargs wc -l | grep -v total > $CHECK_PCNT
                
                # diff save vs. current
                #M_STAT=`diff -y --suppress-common-lines $ALL_SAVE $ALL_CHECK | wc -l`
                
                M_STAT=`diff -y --suppress-common-lines $ALL_SAVE_DEV $ALL_CHECK_DEV | wc -l`
                M_STAT_CNT=`diff -y --suppress-common-lines $SAVE_PCNT $CHECK_PCNT | wc -l`

                if [ $M_STAT -gt 0 -o $M_STAT_CNT -gt 0 ]; then
                    if [ -z "$1" ]; then
                        echo $tag_title"Check Multipath Device List"$op_tag_CHECK$tag_val
                        echo "-------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
                        #diff -y --suppress-common-lines $ALL_SAVE $ALL_CHECK | tee -a $LOG
                        diff -y --suppress-common-lines $ALL_SAVE_DEV $ALL_CHECK_DEV  | tee -a $LOG
                        diff -y --suppress-common-lines $SAVE_PCNT $CHECK_PCNT  | tee -a $LOG
                        echo "-------------------------------------------------------------------------------------------------------------------------------"
                    elif [ $1 == "local" ]; then
                        echo "$tag_CHECK Check Multipath Device List"
                        echo "-------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
                        #diff -y --suppress-common-lines $ALL_SAVE $ALL_CHECK | tee -a $LOG
                        diff -y --suppress-common-lines $ALL_SAVE_DEV $ALL_CHECK_DEV  | tee -a $LOG
                        diff -y --suppress-common-lines $SAVE_PCNT $CHECK_PCNT  | tee -a $LOG
                        echo "-------------------------------------------------------------------------------------------------------------------------------"
                    fi
                else
                    if [ -z "$1" ]; then
                        echo $tag_title"Check Multipath Device List"$op_tag_OK
                    elif [ $1 == "local" ]; then
                        echo "$tag_OK Check Multipath Device List"
                    fi
                fi
                
                
                MSTAT=`cat $ALL_CHECK | egrep -v "dm-|size|active ready running|status=active|status=enabled" | wc -l`
                
                if [ $MSTAT -gt 0 ]; then
                    if [ -z "$1" ]; then
                        echo $tag_title"Check Multipath Status"$op_tag_CHECK$tag_val
                        echo "-------------------------------------------------------------------------------------------------------------------------------"
                        cat $ALL_CHECK | egrep -v "dm-|size|active ready running|status=active" | tee -a $LOG
                        echo "-------------------------------------------------------------------------------------------------------------------------------"
                    elif [ $1 == "local" ]; then
                        echo "$tag_CHECK Check Multipath Status"
                        echo "-------------------------------------------------------------------------------------------------------------------------------"
                        cat $ALL_CHECK | egrep -v "dm-|size|active ready running|status=active" | tee -a $LOG
                        echo "-------------------------------------------------------------------------------------------------------------------------------"
                    fi
                else
                    if [ -z "$1" ]; then
                        echo $tag_title"Check Multipath Status"$op_tag_OK
                    elif [ $1 == "local" ]; then
                        echo "$tag_OK Check Multipath Status"
                    fi
                fi
            fi    
        fi    # end if save data exists or not,
    else
    # if no /sbin/multipath file
        if [ -z "$1" ]; then
            echo $tag_title"Check Multipath Device List"$op_tag_SKIP$tag_val"No multipath"
        elif [ $1 == "local" ]; then
            echo "$tag_skip Check Multipath Device List - No multipath"
        fi
    fi
}

###########################################################################
##  Function Name : _network
##  Description : check network configure (IP, bonding-Active/Standby, bonding-LACP, MAC)
##  information : examples of output
##              - OPMATE : @@@Check Network Status : OK
##              - local : [ OK       ] Check Network Status
###########################################################################
_network(){

    SAVE_NW=$MAINPATH/nw_config_save.log
    CHK_NW=$MAINPATH/nw_config_`date +%Y%m%d%H%M%S`.log
    IF_LIST=$MAINPATH/iflist_check.out
    #CHK_NW_LACP=$MAINPATH/nw_config_lacp.log
    #CHK_LACP_ID=$MAINPATH/nw_config_lacp_id.log
    SAVE_MAC=$MAINPATH/nw_mac_save.log
    CHK_MAC=$MAINPATH/nw_mac_`date +%Y%m%d%H%M%S`.log


    # IP
    ip -f inet -o addr > $CHK_NW
    
   
    #/usr/sbin/ip -f inet -o addr | /usr/bin/grep -v "lo " | /usr/bin/awk '{print "/usr/bin/cat /proc/net/bonding/"$2}' | /usr/bin/grep -v "\." | /usr/bin/uniq > $IF_LIST


    # make bonding interface list
    grep -i "master=" /etc/sysconfig/network-scripts/ifcfg-* | grep -v "#" | awk -F"=" '{print "cat /proc/net/bonding/"$2}' | sort -u > $IF_LIST
    
    while read line
    do
        MODE=`$line | grep Mode | sed 's/IEEE 802.3ad//g' | awk '{print $3}'`
        LACP_FILE=$MAINPATH/`echo $line | awk -F/ '{print $5}'`.lacp
        BOND_FILE=$MAINPATH/`echo $line | awk -F/ '{print $5}'`.bond

        #touch $LACP_FILE
        touch $BOND_FILE

        if [ $MODE == "fault-tolerance" ]; then
            $line | grep -v "Currently Active Slave" > $BOND_FILE
        elif [ $MODE == "Dynamic" ]; then
            $line > $LACP_FILE
        else
            $line >> $CHK_NW
        fi
    done < $IF_LIST

    # HW Addr
    cd $MAINPATH; ls *.bond_save | xargs grep "HW addr" | sed 's/_save//g' | sort > $SAVE_MAC
    cd $MAINPATH; ls *.bond | xargs grep "HW addr" | sort > $CHK_MAC

    # LACP

    LACP_CHK=0

    if [ `find $MAINPATH -name "*.lacp" | wc -l` -gt 0 ]; then
        AGGID_CNT=`cd $MAINPATH; ls *.lacp | awk '{print "grep ^Aggregator "$1" | grep ID"}' | sh | sort -u | wc -l`
        IF_CNT=`cd $MAINPATH; ls -al *.lacp | wc -l`
    
    
        # Agrregation ID
        if [ $AGGID_CNT -ne $IF_CNT ]; then
            LACP_CHK=1
        fi
    
        cd $MAINPATH; ls *.lacp_save | xargs grep "HW addr" | sed 's/_save//g' | sort >> $SAVE_MAC
        cd $MAINPATH; ls *.lacp | xargs grep "HW addr" | sort >> $CHK_MAC
    fi


    MAC_STAT=`diff -y --suppress-common-lines $SAVE_MAC $CHK_MAC | wc -l`

    # find lastest saved data
    LAST_NW_SUMMARY=`ls -rt $MAINPATH/nw_config_*.log | tail -2 | sed -n '1p' 2>&1 `
    
    if [ ! -f $SAVE_NW ]; then
        SAVE_NW=$LAST_NW_SUMMARY
    fi
    
    
    N_STAT=`diff -y --suppress-common-lines $SAVE_NW $CHK_NW | wc -l`
    
    # result
    if [ $N_STAT -gt 0 -o $MAC_STAT -gt 0 ]; then
    #if [ $N_STAT -gt 0 -o $LACP_CHK -eq 1 -o $MAC_STAT -gt 0 ]; then

        if [ -z "$1" ]; then
            echo $tag_title"Check Network Status"$op_tag_CHECK$tag_val
            echo "-------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
            diff -y --suppress-common-lines $SAVE_NW $CHK_NW | tee -a $LOG
            diff -y --suppress-common-lines $SAVE_MAC $CHK_MAC | tee -a $LOG
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            #cd $MAINPATH; ls *.lacp | xargs grep "^Aggregator ID" | uniq
            #echo "-------------------------------------------------------------------------------------------------------------------------------"

        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check Network Status"
            echo "-------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
            diff -y --suppress-common-lines $SAVE_NW $CHK_NW | tee -a $LOG
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            #cd $MAINPATH; ls *.lacp | xargs grep "^Aggregator ID" | uniq
            #echo "-------------------------------------------------------------------------------------------------------------------------------"
        fi

    else

        if [ -z "$1" ]; then
            echo $tag_title"Check Network Status"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check Network Status"
        fi
    fi

    if [ $LACP_CHK -eq 1 ]; then

        if [ -z "$1" ]; then
            echo $tag_title"Check Network Status (LACP)"$op_tag_CHECK$tag_val
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            cd $MAINPATH; ls *.lacp | xargs grep "^Aggregator ID" | uniq
            echo "-------------------------------------------------------------------------------------------------------------------------------"
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check Network Status (LACP)"
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            cd $MAINPATH; ls *.lacp | xargs grep "^Aggregator ID" | uniq
            echo "-------------------------------------------------------------------------------------------------------------------------------"
        fi

    else

        if [ -z "$1" ]; then
            echo $tag_title"Check Network Status (LACP)"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check Network Status (LACP)"
        fi

    fi
    
}


###########################################################################
##  Function Name : _network_bonding
##  Description : check network bonding configure (double check)
##                - check except bond0 interface (even though change bonding interface name, bond0 is still existed by down status)
##                - if virture machine, skip check logic
##  information : examples of output
##              - OPMATE : @@@Check bonding status : OK
##              - local : [ OK       ] Check bonding status
###########################################################################
_network_bonding(){

    rm -rf $MAINPATH/bonding.err

    VMCHECK=`dmidecode -s system-product-name | egrep "Virtual Machine|VMware Virtual Platform|KVM" | wc -l`
    
    if [ $VMCHECK -eq 1 ]; then
        if [ -z "$1" ]; then
            echo $tag_title"Check bonding status"$op_tag_SKIP$tag_val"No bonding interface (Virtual Machine)"
        elif [ $1 == "local" ]; then
            echo "$tag_skip Check bonding status - No bonding interface (Virtual Machine)"
        fi
    else

        if [[ -d /proc/net/bonding ]]; then
            BC=`ls -1 /proc/net/bonding|grep -v bond0`
            TC=0
        
            for i in $BC; do
                if [[ `echo $i | grep bond |wc -l` -eq 1 ]]; then  
                    if [[ `cat /proc/net/bonding/$i | egrep -v "Down Delay" | egrep -i "unknown|down" | wc -l` -ne 0 ]]; then
                        TC=1
                        echo "Check this bonding interface : [ "$i" ] " >> $MAINPATH/bonding.err
                        cat /proc/net/bonding/$i >> $MAINPATH/bonding.err
                    fi   
                fi
            done
                
                
            if [[ $TC -eq 0 ]]; then
                if [ -z "$1" ]; then
                    echo $tag_title"Check bonding status"$op_tag_OK
                elif [ $1 == "local" ]; then
                    echo "$tag_OK Check bonding status"
                fi
                
            else
                
                if [ -z "$1" ]; then
                    echo $tag_title"Check bonding status"$op_tag_CHECK$tag_val
                    echo "-------------------------------------------------------------------------------------------------------------------------------"
                    cat $MAINPATH/bonding.err
                    echo "-------------------------------------------------------------------------------------------------------------------------------"
                elif [ $1 == "local" ]; then
                    echo "$tag_CHECK Check bonding status"
                    echo "-------------------------------------------------------------------------------------------------------------------------------"
                    cat $MAINPATH/bonding.err 
                    echo "-------------------------------------------------------------------------------------------------------------------------------"
                fi
                
            fi
        else
            if [ -z "$1" ]; then
                echo $tag_title"Check bonding status"$op_tag_CHECK$tag_val"No bonding interface"
            elif [ $1 == "local" ]; then
                echo "$tag_skip Check bonding status - No bonding interface"
            fi

        fi
            
    fi

}


###########################################################################
##  Function Name : _ping
##  Description : check ping to default gateway
##  information : examples of output
##              - OPMATE : @@@Check ping to gateway : OK
##              - local : [ OK       ] Check ping to gateway
###########################################################################
_ping(){
    if [[ -f /sbin/route ]]; then 
        DGW=`/sbin/route |grep -i default |awk '{print $2}'`
        PT=`ping  -c 3 -W 5 $DGW |grep packets | grep " 0%" | wc -l`
        PT_check=`ping  -c 3 -W 5 $DGW |grep packets | grep "%" | wc -l`
 
        if [[ ${PT_check} -eq 0 ]]; then
 
            if [ -z "$1" ]; then
                echo $tag_title"Check ping to gateway"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check ping to gateway"
            fi
 
        else
            if [[ ${PT} -ne 0 ]]; then
   
                if [ -z "$1" ]; then
                    echo $tag_title"Check ping to gateway"$op_tag_OK
                elif [ $1 == "local" ]; then
                    echo "$tag_OK Check ping to gateway"
                fi
   
            else
   
                if [ -z "$1" ]; then
                    echo $tag_title"Check ping to gateway"$op_tag_CHECK
                elif [ $1 == "local" ]; then
                    echo "$tag_CHECK Check ping to gateway"
                fi
   
            fi
        fi
    fi
}



###########################################################################
##  Function Name : _infiniband
##  Description : check rachb infiniband status (only SWING system. do not check except rachb interface)
##                if satisfied 3 conditions, status is ok.
##                  - systemctl status irqbalance-swing.service -> active
##                  - systemctl status openibd -> active
##                  - rachb -> Currently Active Slave -> ib2
##  information : examples of output
##              - OPMATE : @@@Check ping to gateway : OK
##              - local : [ OK       ] Check ping to gateway
###########################################################################
_infiniband(){
    if [ `grep ib $MAINPATH/nw_config_save.log | wc -l` -gt 0 ];then
        CHK1=`systemctl status irqbalance-swing.service | grep "active (running)" | wc -l`
        CHK2=`systemctl status openibd | grep "active (exited)" | wc -l`
        CHK3=`cat /proc/net/bonding/rachb | grep "Currently Active Slave" | awk '{print $4}'`
    
        if [ $CHK1 -eq 1 -a $CHK2 -eq 1 -a $CHK3 == "ib2" ]; then
                
    
            if [ -z "$1" ]; then
                echo $tag_title"Check Infiniband Status"$op_tag_OK
            elif [ $1 == "local" ]; then
                echo "$tag_OK Check Infiniband Status"
            fi
       
        else
                
    
            if [ -z "$1" ]; then
                echo $tag_title"Check Infiniband Status"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check Infiniband Status"
            fi
      
        fi
    else
           
        if [ -z "$1" ]; then
            echo $tag_title"Check Infiniband Status"$op_tag_SKIP$tag_val"No infiniband interface"
        elif [ $1 == "local" ]; then
            echo "$tag_skip Check Infiniband Status - No infiniband interface"
        fi
   
    fi
}


###########################################################################
##  Function Name : _netstat
##  Description : check numbers of network session by status and reassembles failed count.
##                state list : ESTABLISHED SYN_SENT SYN_RECV FIN_WAIT1 FIN_WAIT2 TIME_WAIT CLOSE CLOSE_WAIT LAST_ACK LISTEN CLOSING UNKNOWN
##  information : examples of output
##              - OPMATE : @@@Number of $STAT Sessions : XXXXXXX
##                         @@@Check Network Reassembles Failed : OK
##              - local : [ XXXXXXX  ] Number of $STAT Sessions
##                        [ OK       ] Check Network Reassembles Failed
###########################################################################
_netstat(){
    STAT_LIST="ESTABLISHED SYN_SENT SYN_RECV FIN_WAIT1 FIN_WAIT2 TIME_WAIT CLOSE CLOSE_WAIT LAST_ACK LISTEN CLOSING UNKNOWN"
    for STAT in $STAT_LIST
    do
        STAT_CNT=`netstat -na | awk '$6 ~ /^'"$STAT"'$/ {print $0}' | wc -l`
        if [ $STAT_CNT -gt 0 ]; then
            STAT_CNT=$STAT_CNT"       "
            
            if [ -z "$1" ]; then
                echo $tag_title"Number of $STAT Sessions"$op_tag_SKIP$tag_val${STAT_CNT:0:7}
            elif [ $1 == "local" ]; then
                echo "[ ${STAT_CNT:0:7}  ] Number of $STAT Sessions"
            fi
        
        fi
    done
    
    if [ `netstat -s | grep -i 'reassembles failed' | wc -l` -gt 0 ]; then

        RFAIL=`netstat -s | grep -i 'reassembles failed' | awk '{print $1}'`"       "

        if [ -z "$1" ]; then
            echo $tag_title"Check Network Reassembles Failed"$op_tag_CHECK$tag_val${RFAIL:0:7}
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check Network Reassembles Failed - "${RFAIL:0:7}
        fi

    else

        if [ -z "$1" ]; then
            echo $tag_title"Check Network Reassembles Failed"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check Network Reassembles Failed"
        fi


    fi
}

###########################################################################
##  Function Name : _ethool
##  Description : Check ethool error count (RX ERROR, TX ERROR)
##  information : examples of output
##              - OPMATE : 
##                  @@@Check ethool ERROR count : CHECK -
##                  -------------------------------------------------------------------------------------------------------------------------------
##                  Kernel Interface table
##                  Iface      MTU    RX-OK RX-ERR RX-DRP RX-OVR    TX-OK TX-ERR TX-DRP TX-OVR Flg
##                  em2       1500 11836610277   1129      1 1129   10431224143      0      0      0 BMsRU
##                  Kernel Interface table
##                  Iface      MTU    RX-OK RX-ERR RX-DRP RX-OVR    TX-OK TX-ERR TX-DRP TX-OVR Flg
##                  service   1500 11891265454   1129 54647548 1129   10431232469      0      0      0 BMmRU
##                  -------------------------------------------------------------------------------------------------------------------------------
##              - local : 
##                  [ CHECK    ] Check ethool ERROR count
##                  -------------------------------------------------------------------------------------------------------------------------------
##                  Kernel Interface table
##                  Iface      MTU    RX-OK RX-ERR RX-DRP RX-OVR    TX-OK TX-ERR TX-DRP TX-OVR Flg
##                  em2       1500 11836610619   1129      1 1129   10431224484      0      0      0 BMsRU
##                  Kernel Interface table
##                  Iface      MTU    RX-OK RX-ERR RX-DRP RX-OVR    TX-OK TX-ERR TX-DRP TX-OVR Flg
##                  service   1500 11891265798   1129 54647551 1129   10431232810      0      0      0 BMmRU
##                  -------------------------------------------------------------------------------------------------------------------------------
###########################################################################
_ethool(){
    ETH_LIST=`ip addr | grep -w mtu | cut -d ":" -f 2 | egrep -v 'lo|inet|virbr|sit' | grep -v "@"`
    ERR_CNT=0
    
    if [ -f $MAINPATH/ethool.err ]; then
        rm -rf $MAINPATH/ethool.err
    fi
    
    for LIST in $ETH_LIST
    do
        ETH_LINK=`ethtool $LIST | egrep 'Link detected' | awk '{print $3}'`
 
        if [ $ETH_LINK == "yes" ]; then
 
            if [ `netstat -n -I=$LIST | grep Met | wc -l` -eq 0 ]; then
                ETH_RES=`netstat -n -I=$LIST | awk '{print $4" "$8}' | grep "0 0" | wc -l`
            else
                ETH_RES=`netstat -n -I=$LIST | awk '{print $5" "$9}' | grep "0 0" | wc -l`
            fi
      
            if [ $ETH_RES -eq 0 ]; then
                netstat -n -I=$LIST >> $MAINPATH/ethool.err
                ERR_CNT=`expr $ERR_CNT + 1`
            fi
        fi
    done
    
    
    if [ $ERR_CNT -gt 0 ]; then

        if [ -z "$1" ]; then
            echo $tag_title"Check ethool ERROR count"$op_tag_CHECK$tag_val
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            cat $MAINPATH/ethool.err
            echo "-------------------------------------------------------------------------------------------------------------------------------"
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check ethool ERROR count"
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            cat $MAINPATH/ethool.err
            echo "-------------------------------------------------------------------------------------------------------------------------------"
        fi            

    else

        if [ -z "$1" ]; then
            echo $tag_title"Check ethool ERROR count"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check ethool ERROR count"
        fi

    fi
}


###########################################################################
##  Function Name : _cluster
##  Description : Check Cluster Status
##  information : examples of output
##              - OPMATE : @@@Check Redhat Cluster : OK
##              - local : [ SKIP     ] Check Redhat Cluster - No Cluster
###########################################################################
_cluster(){

    CLU=0

    if [ -f /sbin/pcs ]; then
        pcs cluster status > $MAINPATH/pcs.out 2>&1
        CLU=1
    elif [ -f /usr/sbin/clustat ]; then
        #clustat -l > $MAINPATH/clustat.out 2>&1
        clustat -l > $MAINPATH/pcs.out 2>&1
        CLU=1
    fi
    
    if [ -f $MAINPATH/cluster -o $CLU -eq 1 ]; then
    
        if [ `cat $MAINPATH/pcs.out | grep 'Cluster Status:' | wc -l` -eq 1 ]; then
            HNAME=`hostname`
            SPLITNAME=${HNAME#skt-}
            
            if [ `pcs cluster status | egrep "$HNAME|$SPLITNAME" | tail -1 | awk '$2 ~ Online' | wc -l` -eq 1 ]; then

                if [ -z "$1" ]; then
                    echo $tag_title"Check Redhat Cluster"$op_tag_OK
                elif [ $1 == "local" ]; then
                    echo "$tag_OK Check Redhat Cluster"
                fi

            #elif [ `pcs cluster status | grep skt | tail -1 | awk '$2 ~ Online' | wc -l` -eq 1 ]; then
            #    echo "$tag_OK Check Redhat Cluster"
            #elif [ `pcs cluster status | grep  | tail -1 | awk '$2 ~ Online' | wc -l` -eq 1 ]; then
            #    echo "$tag_OK Check Redhat Cluster"
            else

                if [ -z "$1" ]; then
                    echo $tag_title"Check Redhat Cluster"$op_tag_CHECK$tag_val
                elif [ $1 == "local" ]; then
                    echo "$tag_CHECK Check Redhat Cluster"
                fi

                echo "-------------------------------------------------------------------------------------------------------------------------------"
                cat $MAINPATH/pcs.out
                echo "-------------------------------------------------------------------------------------------------------------------------------"

                #pcs cluster status
            fi
        
        elif [ `cat $MAINPATH/pcs.out | grep -i Error | wc -l` -gt 0 ]; then

            if [ -z "$1" ]; then
                echo $tag_title"Check Redhat Cluster"$op_tag_CHECK$tag_val
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check Redhat Cluster"
            fi

            echo "-------------------------------------------------------------------------------------------------------------------------------"
            cat $MAINPATH/pcs.out
            echo "-------------------------------------------------------------------------------------------------------------------------------"
        else

            if [ -z "$1" ]; then
                echo $tag_title"Check Redhat Cluster"$op_tag_SKIP$tag_val"No Cluster Setting"
            elif [ $1 == "local" ]; then
                echo "$tag_skip Check Redhat Cluster - No Cluster"
            fi


        fi

    else

        if [ -z "$1" ]; then
            echo $tag_title"Check Redhat Cluster"$op_tag_SKIP$tag_val"No Cluster Setting"
        elif [ $1 == "local" ]; then
            echo "$tag_skip Check Redhat Cluster - No Cluster"
        fi

    fi
}


###########################################################################
##  Function Name : _fsutil
##  Description : Check filesystem used size over 90% 
##  information : examples of output
##              - OPMATE : 
##                  @@@Check Filesystem Used% : CHECK -
##                  -------------------------------------------------------------------------------------------------------------------------------
##                  100% /tmp/test
##                  -------------------------------------------------------------------------------------------------------------------------------
##              - local :
##                  [ CHECK    ] Check Filesystem Used%
##                  -------------------------------------------------------------------------------------------------------------------------------
##                  100% /tmp/test
##                  -------------------------------------------------------------------------------------------------------------------------------
###########################################################################
_fsutil(){
    #if [ $OS5 -eq 1 ]; then
    
    #FS_VALUE="10"
    
    #TMPDIR="/SIT/scli/log/check"
    
    #df -hP | grep -v Filesystem | grep -v Mounted | grep -i -v "sapdata" | awk '{ print $5, $6 }' > ${TMPDIR}/tmp_FileSystem1
    
    #rm -f ${TMPDIR}/tmp_FileSystem2
    #cat ${TMPDIR}/tmp_FileSystem1 | awk '{ print $1, $2 }' | while read FSC1 FSC2; do
    #        FSC3=`echo ${FSC1} | awk -F% '{ print $1}'`
    #        if [[ ${FSC3} -gt ${FS_VALUE} ]]; then
    #                echo "${FSC2}:${FSC1} " >> ${TMPDIR}/tmp_FileSystem2
    #        fi
    #done
    #if [[ ! -s ${TMPDIR}/tmp_FileSystem2 ]]; then
    #        CHK_YN="Y"
    #        #OUTPUT="### FileSystem Usage: OK"
    #       echo "$tag_OK Check Filesystem Used%"
    #else
    #        CHK_YN="N"
    #        #OUTPUT="### FileSystem Usage: FAIL ("`cat ${TMPDIR}/tmp_FileSystem2`")"
    #       echo "$tag_CHECK Check Filesystem Used%"
    #       echo "-------------------------------------------------------------------------------------------------------------------------------"
    #       cat ${TMPDIR}/tmp_FileSystem2
    #       echo "-------------------------------------------------------------------------------------------------------------------------------"
    #fi
    
    
    #else
    
    
    
    TEMP=$TMPDIR/df.tmp
    
    df -Ph | egrep -v "tmpfs|Use%" | awk '{print $5" "$6}' > $TEMP
    
    FS_NUM=`cat $TEMP | wc -l`
    N=0
    M=0
    
    while read line
    do
        USED=`echo $line | awk -F% '{print $1}'`
  
        if [ $USED -gt 90 ]; then
            if [ $M -eq 0 ]; then
     
                if [ -z "$1" ]; then
                    echo $tag_title"Check Filesystem Used%"$op_tag_CHECK$tag_val
                    echo "-------------------------------------------------------------------------------------------------------------------------------"
        
                elif [ $1 == "local" ]; then
                    echo "$tag_CHECK Check Filesystem Used%"
                    echo "-------------------------------------------------------------------------------------------------------------------------------"
                fi
     
            fi
     
            echo $line
     
            M=`expr $M + 1`
        else
            N=`expr $N + 1`
   
            if [ $N -eq $FS_NUM ]; then
   
                if [ -z "$1" ]; then
                    echo $tag_title"Check Filesystem Used%"$op_tag_OK
        
                elif [ $1 == "local" ]; then
                    echo "$tag_OK Check Filesystem Used%"
                fi
            fi
        fi
    done < $TEMP
    
    if [ $M -ne 0 -a `expr $M + $N` -eq $FS_NUM ]; then
        echo "-------------------------------------------------------------------------------------------------------------------------------"
    fi
    
    #fi
}


###########################################################################
##  Function Name : _fsinode
##  Description : Check filesystem used inode over 80% 
##  information : examples of output
##              - OPMATE : 
##                  @@@Check Filesystem inode Used% : CHECK -
##                  -------------------------------------------------------------------------------------------------------------------------------
##                  91%  /
##                  91%  /dev
##                  -------------------------------------------------------------------------------------------------------------------------------
##              - local :
##                  [ CHECK    ] Check Filesystem inode Used%
##                  -------------------------------------------------------------------------------------------------------------------------------
##                  91%  /
##                  91%  /dev
##                  -------------------------------------------------------------------------------------------------------------------------------
###########################################################################
_fsinode(){
    #FSI=`df -Pi 2>/dev/null | grep -v -i "skt-hnas" | grep -v -i "USCAN-" | grep -v Mounted | awk '{print $5}' | egrep '([8-9][0-9]%|100%)' | wc -l`
    FSI=`df -Pi 2>/dev/null | grep -v Mounted | awk '{print $5}' | egrep '([8-9][0-9]%|100%)' | wc -l`
    if [[ $FSI -eq 0 ]]; then
            
        if [ -z "$1" ]; then
            echo $tag_title"Check Filesystem inode Used%"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check Filesystem inode Used%"
        fi
        
    else

        if [ -z "$1" ]; then
            echo $tag_title"Check Filesystem inode Used%"$op_tag_CHECK$tag_val
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            #DF_P=`df -Pi | grep -v -i "skt-hnas" | grep -v -i "USCAN-" | grep -v Mounted | awk '{print $5 "  " $6}' | egrep '([8-9][0-9]%|100%)'`
            df -Pi | grep -v Mounted | awk '{print $5 "  " $6}' | egrep '([8-9][0-9]%|100%)'
            echo "-------------------------------------------------------------------------------------------------------------------------------"
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check Filesystem inode Used%"
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            #DF_P=`df -Pi | grep -v -i "skt-hnas" | grep -v -i "USCAN-" | grep -v Mounted | awk '{print $5 "  " $6}' | egrep '([8-9][0-9]%|100%)'`
            df -Pi | grep -v Mounted | awk '{print $5 "  " $6}' | egrep '([8-9][0-9]%|100%)'
            echo "-------------------------------------------------------------------------------------------------------------------------------"
        fi

    fi
}


###########################################################################
##  Function Name : _cntproc
##  Description : Count result of lsof / ps -ef / ps -eL command (open files, running process, running thread)
##  information : examples of output
##              - OPMATE : 
##                  @@@Number of Open Files : OK - Not installed lsof
##                  @@@Number of Total Processes : OK - 748
##                  @@@Number of Total Threads : OK - 3584
##              - local :
##                  [ SKIP     ] Nubmer of Open Files - Not installed lsof
##                  [ 748      ] Number of Total Processes
##                  [ 3584     ] Number of Total Threads
###########################################################################
_cntproc(){
    # check wheather lsof package is installed
    if [ `rpm -qa | grep lsof | wc -l` -gt 1 ]; then
        OPEN_FILE=`/usr/sbin/lsof | wc -l 2>&1`
  
        # check digits of lsof
        if [ ${#OPEN_FILE} -gt 7 ]; then

            if [ -z "$1" ]; then
                echo $tag_title"Number of Open Files"$op_tag_CHECK$tag_val"Over 9999999 Files Open"
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Number of Open Files - Over 9999999 Files Open"
            fi

        else
            OPEN_FILE=$OPEN_FILE"       "

            if [ -z "$1" ]; then
                echo $tag_title"Number of Open Files"$op_tag_OK$tag_val${OPEN_FILE:0:7}
            elif [ $1 == "local" ]; then
                echo "[ ${OPEN_FILE:0:7}  ] Number of Open Files "
            fi

        fi
    else

        if [ -z "$1" ]; then
            echo $tag_title"Number of Open Files"$op_tag_SKIP$tag_val"Not installed lsof"
        elif [ $1 == "local" ]; then
            echo "$tag_skip Nubmer of Open Files - Not installed lsof"
        fi
    fi
    
    # check ps -ef
    RUN_PROC=`ps -ef | wc -l`
    
    if [ ${#RUN_PROC} -gt 7 ]; then
        
        if [ -z "$1" ]; then
            echo $tag_title"Number of Total Processes"$op_tag_CHECK$tag_val"Over 9999999 Processes Running"
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Number of Total Processes - Over 9999999 Processes Running"
        fi

    else
        RUN_PROC=$RUN_PROC"       "        

        if [ -z "$1" ]; then
            echo $tag_title"Number of Total Processes"$op_tag_OK$tag_val${RUN_PROC:0:7}
        elif [ $1 == "local" ]; then
            echo "[ ${RUN_PROC:0:7}  ] Number of Total Processes"
        fi

    fi
    
    RUN_THREAD=`ps -eL | wc -l`
    
    if [ ${#RUN_THREAD} -gt 7 ]; then
            
        if [ -z "$1" ]; then
            echo $tag_title"Number of Total Threads"$op_tag_CHECK$tag_val"Over 9999999 Threads Running"
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Number of Total Threads - Over 9999999 Threads Running"
        fi

    else
        RUN_THREAD=$RUN_THREAD"       "
            
        if [ -z "$1" ]; then
            echo $tag_title"Number of Total Threads"$op_tag_OK$tag_val${RUN_THREAD:0:7}
        elif [ $1 == "local" ]; then
            echo "[ ${RUN_THREAD:0:7}  ] Number of Total Threads"
        fi

    fi
}



###########################################################################
##  Function Name : _osproc
##  Description : Check OS default process is running
##  information : examples of output
##              - OPMATE : 
##                  @@@Check rsyslogd : OK
##                  @@@Check systemd-udevd : OK
##                  @@@Check systemd-logind : OK
##                  @@@Check systemd-journald : OK
##                  @@@Check crond : OK
##                  @@@Check ntpd : OK
##                  @@@Check multipathd : OK
##              - local :
##                  [ OK       ] Check rsyslogd
##                  [ OK       ] Check systemd-udevd
##                  [ OK       ] Check systemd-logind
##                  [ OK       ] Check systemd-journald
##                  [ OK       ] Check crond
##                  [ OK       ] Check ntpd
##                  [ OK       ] Check multipathd
##              - Linux 5 : syslogd, xinetd, crond, ntpd, multipathd
##              - Linux 6 : rsyslogd, xinetd, crond, ntpd, multipathd
##              - Linux 7 : rsyslogd, systemd-udevd, systemd-logind, systemd-journald, crond, ntpd, multipathd
###########################################################################
_osproc(){

    # syslogd
    if [ $OS5 -eq 1 ]; then
        if [ `ps -ef | grep syslogd | grep -v grep | wc -l` -gt 0 ]; then

            if [ -z "$1" ]; then
                echo $tag_title"Check syslogd"$op_tag_OK
            elif [ $1 == "local" ]; then
                echo "$tag_OK Check syslogd"
            fi

        else

            if [ -z "$1" ]; then
                echo $tag_title"Check syslogd"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check syslogd"
            fi

        fi
    else
        if [ `ps -ef | grep rsyslogd | wc -l` -gt 1 ]; then

            if [ -z "$1" ]; then
                echo $tag_title"Check rsyslogd"$op_tag_OK
            elif [ $1 == "local" ]; then
                echo "$tag_OK Check rsyslogd"
            fi

        else
                
            if [ -z "$1" ]; then
                echo $tag_title"Check rsyslogd"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check rsyslogd"
            fi

        fi
    fi
        
    
    # if os version is linux 7 - systemd
    if [ $OS7 -eq 1 ]; then
        if [ `ps -ef | grep systemd-udevd | wc -l` -gt 1 ]; then
                
            if [ -z "$1" ]; then
                echo $tag_title"Check systemd-udevd"$op_tag_OK
            elif [ $1 == "local" ]; then
                echo "$tag_OK Check systemd-udevd"
            fi

        else
                
            if [ -z "$1" ]; then
                echo $tag_title"Check systemd-udevd"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check systemd-udevd"
            fi
        fi
    
        if [ `ps -ef | grep systemd-logind | wc -l` -gt 1 ]; then
                
            if [ -z "$1" ]; then
                echo $tag_title"Check systemd-logind"$op_tag_OK
            elif [ $1 == "local" ]; then
                echo "$tag_OK Check systemd-logind"
            fi

        else
                
            if [ -z "$1" ]; then
                echo $tag_title"Check systemd-logind"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check systemd-logind"
            fi
        fi
    
        if [ `ps -ef | grep systemd-journald | wc -l` -gt 1 ]; then
                
            if [ -z "$1" ]; then
                echo $tag_title"Check systemd-journald"$op_tag_OK
            elif [ $1 == "local" ]; then
                echo "$tag_OK Check systemd-journald"
            fi

        else
                
            if [ -z "$1" ]; then
                echo $tag_title"Check systemd-journald"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check systemd-journald"
            fi

        fi
    else
        if [ `ps -ef | grep xinetd | wc -l` -gt 1 ]; then
                
            if [ -z "$1" ]; then
                echo $tag_title"Check sxinetd"$op_tag_OK
            elif [ $1 == "local" ]; then
                echo "$tag_OK Check xinetd"
            fi

        else
                
            if [ -z "$1" ]; then
                echo $tag_title"Check sxinetd"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check xinetd"
            fi

        fi
    fi



    
    if [ `ps -ef | grep crond | grep -v grep | wc -l` -gt 0 ]; then
        
        if [ -z "$1" ]; then
            echo $tag_title"Check crond"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check crond"
        fi

    else
        
        if [ -z "$1" ]; then
            echo $tag_title"Check crond"$op_tag_CHECK
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check crond"
        fi

    fi


    if [ `ps -ef | grep ntpd | grep -v grep | wc -l` -gt 0 ]; then
            
        if [ -z "$1" ]; then
            echo $tag_title"Check ntpd"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check ntpd"
        fi

    else
            
        if [ -z "$1" ]; then
            echo $tag_title"Check ntpd"$op_tag_CHECK
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check ntpd"
        fi
    fi
    

    if [ -f /sbin/multipathd ]; then
        if [ `ps -ef | grep multipathd | grep -v grep | wc -l` -gt 0 ]; then
                
            if [ -z "$1" ]; then
                echo $tag_title"Check multipathd"$op_tag_OK
            elif [ $1 == "local" ]; then
                echo "$tag_OK Check multipathd"
            fi

        else
                
            if [ -z "$1" ]; then
                echo $tag_title"Check multipathd"$op_tag_CHECK
            elif [ $1 == "local" ]; then
                echo "$tag_CHECK Check multipathd"
            fi
        fi 
        
    else
        
        if [ -z "$1" ]; then
            echo $tag_title"Check multipathd"$op_tag_SKIP$tag_val"No multipath"
        elif [ $1 == "local" ]; then
            echo "$tag_skip Check multipathd - No multipath"
        fi
    fi

}


###########################################################################
##  Function Name : _infsw
##  Description : Check infra software
##  information : examples of output
##              - OPMATE : 
##                  @@@Check vxpbx_exchanged process : OK
##                  @@@Check netbackup process : OK
##                  @@@Check Ontune / AnyCatcher process : OK
##              - local :
##                  [ OK       ] Check vxpbx_exchanged process
##                  [ OK       ] Check netbackup process
##                  [ OK       ] Check Ontune / AnyCatcher process
##              - Linux 7 : NetBackup, Ontune, AnyCatcher
##              - other Linux : Ontune, AnyCatcher
###########################################################################
_infsw(){
    if [ $OS7 -eq 1 ]; then
    # if Linux 7, check systemd service (NetBackup)

        Service_List="vxpbx_exchanged netbackup"

        for service in ${Service_List}
        do
            # check service list
            if [ `systemctl list-unit-files | grep ${service} | grep enabled | wc -l` -eq 1 ]; then

                # if service exists, check service status
                if [ `systemctl status ${service}.service | grep 'Active: active' | wc -l` -eq 1 ] && [ `systemctl status ${service}.service | egrep -i 'fail|crit|panic|emerg' | wc -l` -eq 0 ]; then
                    
                    if [ -z "$1" ]; then
                        echo $tag_title"Check ${service} process"$op_tag_OK
                    elif [ $1 == "local" ]; then
                        echo "$tag_OK Check ${service} process"
                    fi

                else
                    
                    if [ -z "$1" ]; then
                        echo $tag_title"Check ${service} process"$op_tag_CHECK
                    elif [ $1 == "local" ]; then
                        echo "$tag_CHECK Check ${service} process"
                    fi

                    #systemctl restart ${service}.service
                    #systemctl status ${service}.service
                fi
            else
            # if no service in list-unit-files
                                       
                if [ -z "$1" ]; then
                    echo $tag_title"Check ${service} process"$op_tag_CHECK$tag_val"Not installed"
                elif [ $1 == "local" ]; then
                    echo "$tag_CHECK Check ${service} process - Not installed"
                fi                
            fi
        done
    fi
    
    # if not Linux 7, check only monitoring S/W
    if [ `ps -ef | grep ontune | grep -v grep | wc -l` -eq 2 -o `ps -ef | grep ACEM | grep -v grep | wc -l` -eq 2 ]; then
        
        if [ -z "$1" ]; then
            echo $tag_title"Check Ontune / AnyCatcher process"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check Ontune / AnyCatcher process"
        fi

    else
       
        if [ -z "$1" ]; then
            echo $tag_title"Check Ontune / AnyCatcher process"$op_tag_CHECK
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check Ontune / AnyCatcher process"
        fi

        #service ontunev4 start
    fi
    
}


###########################################################################
##  Function Name : _bootlog
##  Description : Check /var/log/boot.log except OK / INFO
##  information : examples of output
##              - OPMATE : 
##                  @@@Check /var/log/boot.log : OK
##              - local :
##                  [ OK       ] Check /var/log/boot.log
###########################################################################
_bootlog(){

    # exception list
    # ABRT = Automatic Bug Reporting Tool
    # SSR = SKT Security
    EXC="ABRT|SSR SuperAgent"

    # except bug
    BUG="Dependency failed for Network Manager Wait Online"
    L_CNT=`grep "\[" /var/log/boot.log | grep -v "         " | egrep -v "Welcome| OK | INFO " | egrep -v "$EXC" | egrep -v "$BUG" | wc -l`
    
    if [ $L_CNT -gt 0 ]; then

        if [ -z "$1" ]; then
            echo $tag_title"Check /var/log/boot.log"$op_tag_CHECK$tag_val
        elif [ $1 == "local" ]; then
            echo "$tag_CHECK Check /var/log/boot.log"
        fi
        
        echo "-------------------------------------------------------------------------------------------------------------------------------"
        grep "\[" /var/log/boot.log | grep "[a-zA-Z0-9]" | grep -v "         " | egrep -v "Welcome| OK | INFO " | egrep -v "$EXC" | egrep -v "$BUG" | sed 's/\[1;3[0-9]m//g' | sed 's/\[0m//g' > $TMPDIR/tmp
        cat $TMPDIR/tmp
        echo "-------------------------------------------------------------------------------------------------------------------------------"

    else
        
        if [ -z "$1" ]; then
            echo $tag_title"Check /var/log/boot.log"$op_tag_OK
        elif [ $1 == "local" ]; then
            echo "$tag_OK Check /var/log/boot.log"
        fi

    fi

}


###########################################################################
##  Function Name : _msglog
##  Description : Check /var/log/messages
##  information : examples of output
##              - OPMATE : 
##                  @@@Check /var/log/messages : OK
##              - local :
##                  [ OK       ] Check /var/log/messages
###########################################################################
_msglog(){
    TLOG=$TMPDIR/mlog
    LLOG=$TMPDIR/lastlog
    MLOG=/var/log/messages
    
    cat /dev/null > $LLOG
    
    SWG=`grep "\[\%syslogseverity\%\]" /etc/rsyslog.conf | wc -l`


    EXC=":info|:notice|ACPI: |power_meter ACPI000D\:00|kvm\: disabled by bios|Unable to read SFP data|systemd-tmpfiles:warning|SSR|'lp' unknown|anaconda|oragrid|read CTR while initializing i8042|IOC Init cmd success|INIT adapter done|ABRT|StartIpmiRmqThread|IpmiRmqThread: Entry|Initialize data structures successful|Oracle|ipmi_|no server suitable for synchronization found|multipathd|pam_tally\(crond:account\): unknown option|Start Save Status by SAVE script|gnome|Flags: TI-RPC"
    DBM_EXC="password|authentication|dbadmin|synchronized|terperature|Machine|\/org\/freedesktop\/ConsoleKit\/Session|below trip temperature|pulseaudio|ACPI Exception: AE_AML_BUFFER_LIMIT, Evaluating _PMM|Method parse/execution failed|SMBus or IPMI write requires Buffer of length|pam_faillock|sendmail|kernel: \[<|pam_succeed_if|kernel: INFO"
    BUG="Proceeding anyway|device appeared twice with different sysfs paths|Network Manager Wait Online|path already in pathvec|~ action is deprecated|mei_me|inotify_add_watch|the BIOS has corrupted hw-PMU resources|ACPI\(VGA0\) defines _DOD but not _DOS|ACPI BIOS Warning \(bug\): Invalid length for FADT"
    HA="\/dev\/vgha|swingapp|svc_lvm01|crmd\["

    
    # check Swing templete
    if [ $SWG -eq 1 ]; then
    
        
        STR_LOG=`cat -n $MLOG | grep "http://www.rsyslog.com\"] start" | awk '{print $1}' | tail -1`
        
        if [ -z "$STR_LOG" ]; then
            STR_LOG=`cat -n $MLOG | grep "Start Save Status by SAVE script" | awk '{print $1}' | tail -1`
            if [ -z "$STR_LOG" ]; then
                STR_LOG=1
            fi
        elif [ $STR_LOG -lt `cat -n $MLOG | grep "Start Save Status by SAVE script" | awk '{print $1}' | tail -1` ]; then
            STR_LOG=`cat -n $MLOG | grep "Start Save Status by SAVE script" | awk '{print $1}' | tail -1`
        fi
        
        sed -n ${STR_LOG},'$p' $MLOG | egrep -v "$EXC" | egrep -v "$BUG" | egrep -v "$HA" | egrep -v "DBM_EXC" | grep -Ev '\.[0-9]+{5}' > $TLOG
        
        while read line
        do
            CHK1=`echo $line | grep "kernel:warning" | wc -l`
            if [ $CHK1 -eq 1 ]; then
                CHK2=`echo $line | grep -vi debug | grep -i bug | wc -l`
                if [ $CHK2 -eq 1 ]; then
                    echo $line >> $LLOG
                fi
            else
                CHK3=`echo $line | egrep "Cache battery missing|Cache disabled" | wc -l`
                CHK4=`grep "Cache enabled" $MLOG | wc -l`
     
                if [ $CHK3 -eq 1 -a $CHK4 -eq 1 ]; then
                    continue
                fi
     
                echo $line >> $LLOG
            fi
        done < $TLOG
        
    else
        #non swing templete

        LOGFILE_LIST=/var/log/messages

        LOGDATE=`date`
        CURDATE=`date +%b\ %e\ %H\:%M -d "${LOGDATE}" | cut -c 1-17`
        CURBFDATE=`date +%b\ %e\ %H\:%M -d 'yesterday'| cut -c 1-11`
        CHKDATE=`echo "${CURDATE}" | cut -c 1-6`
        CHKBFDATE=`echo "${CURBFDATE}" | cut -c 1-6`
        
        OS_IN="blocked|error|fail|vertica|disabl|hpsa|Fatal"
        OS_EX2="PME# disabled|SELinux:  Disabled at runtime.|is initialized|Disabled Privacy Extensions| EEE is disabled|failover mode detected|Write cache: disabled, read cache: enabled, doesn't support DPO or FUA|scsi0 : hpsa"
        
        for log in $LOGFILE_LIST
        do
            if [ -e $log ] && [ -s $log ]; then
                egrep -E "^$CHKBFDATE|^$CHKDATE" $log | egrep -i "$OS_IN" | egrep -v "$OS_EX2" | egrep -v "$EXC" | egrep -v "$BUG" | egrep -v "$HA" | egrep -v "DBM_EXC" | while read -r line
                do
                    echo $line
                done
            fi
        done

    fi

    RES=`cat $LLOG | wc -l`
    
    if [ $RES -eq 0 ]; then
        echo "$tag_OK Check /var/log/messages"
    else
        echo "$tag_CHECK Check /var/log/messages"
        echo "-------------------------------------------------------------------------------------------------------------------------------"
        cat $LLOG
        echo "-------------------------------------------------------------------------------------------------------------------------------"
    fi

}


###########################################################################
##  Function Name : _dmesg
##  Description : Check dmesg or /var/log/dmesg
##  information : examples of output
##              - OPMATE : 
##                  @@@Check /var/log/kernel (dmesg) during 1 day (Audit) : OK
##              - local :
##                  [ OK       ] Check /var/log/kernel (dmesg) during 1 day (Audit)
###########################################################################
_dmesg(){
    if [ -f /var/log/kernel ] ; then
        TODAY=`date +%Y-%m-%d`
        YESDAY=`TZ=KST+15 date +%Y-%m-%d`
        CUR_TIME=`date "+%H:%M:%S"`
        SEAR_INCLUDE=":emerg|:crit|:alert|NIC Link is Down|NIC Link is Up|LOOP DOWN|LOOP UP|ISP reset|Abort command issued|error: Operation"
        SEAR_EXCLUDE="type=[0-9]* audit|audit_printk_skb:|gnome-session: \(|audit: |bus-daemon: Failed to close file descriptor: Could not close fd|device appeared twice with different sysfs paths |LOOP UP|NIC Link is Up"
     
        LOG=`cat /var/log/kernel-$(date +%Y%m%d) /var/log/kernel 2> /dev/null | awk '$from>"'$YESDAY' '$CUR_TIME'" && $to<"'$TODAY' '$CUR_TIME'"' from='$1 " " $2' to='$1 " " $2'| egrep "$SEAR_INCLUDE"| egrep -v "$SEAR_EXCLUDE" | wc -l`
    
        if [ $LOG -gt 0 ] ; then
            echo "$tag_CHECK Check /var/log/kernel (dmesg) during 1 day (Audit)"
            echo "-------------------------------------------------------------------------------------------------------------------------------"
            cat /var/log/kernel-$(date +%Y%m%d) /var/log/kernel 2> /dev/null | awk '$from>"'$YESDAY' '$CUR_TIME'" && $to<"'$TODAY' '$CUR_TIME'"' from='$1 " " $2' to='$1 " " $2' | egrep "$SEAR_INCLUDE"| egrep -v "$SEAR_EXCLUDE" | tail -30
            echo "-------------------------------------------------------------------------------------------------------------------------------"
        else
            echo "$tag_OK Check /var/log/kernel (dmesg) during 1 day (Audit)"
        fi
    else
        echo "$tag_skip Check /var/log/kernel (dmesg) during 1 day (Audit) - No log file"
    fi
}


###########################################################################
##  Function Name : _hwlog
##  Description : Check H/W Log
##  information : examples of output
##              - OPMATE : 
##                  @@@Check H/W Log - HP : OK
##              - local :
##                  [ OK       ] Check H/W Log - HP
###########################################################################
_hwlog(){
    if [[ `ls -1 /sbin/hplog 2>/dev/null | wc -l` -ne 0 ]]; then
        if [[ `dmidecode | grep "Serial Number" | grep -i "VMWARE" | wc -l` -eq 0 ]]; then
    
            TDY=`date +%m/%d/%Y`
            LOG=`hplog -v | grep $TDY`
    
            if [[ `echo $LOG | wc -w` -eq 0 ]]; then
                echo "$tag_OK Check H/W Log - HP (Audit)"
            else
                echo "$tag_CHECK Check H/W Log - HP (Audit)"
                echo "-------------------------------------------------------------------------------------------------------------------------------"
                echo $LOG
                echo "-------------------------------------------------------------------------------------------------------------------------------"
            fi
        fi
    elif [[ `ls -1 /opt/dell/srvadmin/sbin/omreport 2>/dev/null | wc -l` -ne 0 ]]; then
        if [[ `dmidecode | grep "Serial Number" | grep -i "VMWARE" | wc -l` -eq 0 ]]; then
    
        TDY=`date +%m/%d/%Y`
        LOG=`/opt/dell/srvadmin/sbin/omreport system esmlog | grep 'Health : Ok'`
    
            if [ `/opt/dell/srvadmin/sbin/omreport system esmlog | grep "Error! No Embedded System Management (ESM) log found on this system." | wc -l` -eq 1 ]; then
                echo "$tag_OK Check H/W Log - Dell (Audit)"
            else
                if [[ `echo $LOG | wc -w` -eq 0 ]]; then
                    echo "$tag_CHECK Check H/W Log - Dell (Audit)"
                    echo "-------------------------------------------------------------------------------------------------------------------------------"
                    echo $LOG
                    echo "-------------------------------------------------------------------------------------------------------------------------------"
                else
                    echo "$tag_OK Check H/W Log - Dell (Audit)"
                fi
            fi
        fi
    else
        echo "$tag_skip Check H/W Log - No H/W Toolkit"
    fi
}


###########################################################################
##  Function Name : _ntp
##  Description : Check ntp connection status
##  information : examples of output
##              - OPMATE : 
##                  @@@Check NTP Status - date/Sync Status/offset/jitter
##                  -------------------------------------------------------------------------------------------------------------------------------
##                       remote           refid      st t when poll reach   delay   offset  jitter
##                  ==============================================================================
##                  +172.31.8.37     10.12.2.203      3 u  918 1024  377    1.695    0.507   0.148
##                  *172.31.24.71    10.12.2.203      3 u 1032 1024  377    1.777    0.588   0.114
##                  +150.206.10.51   172.31.8.37      4 u  793 1024  377    0.195    0.359   0.060
##                  -------------------------------------------------------------------------------------------------------------------------------
##              - local :
##                  [ -------- ] Check NTP Status - date/Sync Status/offset/jitter
##                  -------------------------------------------------------------------------------------------------------------------------------
##                       remote           refid      st t when poll reach   delay   offset  jitter
##                  ==============================================================================
##                  +172.31.8.37     10.12.2.203      3 u  918 1024  377    1.695    0.507   0.148
##                  *172.31.24.71    10.12.2.203      3 u 1032 1024  377    1.777    0.588   0.114
##                  +150.206.10.51   172.31.8.37      4 u  793 1024  377    0.195    0.359   0.060
##                  -------------------------------------------------------------------------------------------------------------------------------
###########################################################################
_ntp(){
    echo "$tag_null Check NTP Status - date/Sync Status/offset/jitter"
    echo "-------------------------------------------------------------------------------------------------------------------------------"
    date
    ntpq -p
    echo "-------------------------------------------------------------------------------------------------------------------------------"
}



###########################################################################
##  Function Name : _os_summ
##  Description : Check OS & H/W status and compare save status
##  information : examples of output
##              - OPMATE : 
##                  @@@Check OS & HW Configuration - BIOS/System/CPU/MEM/OS(Version,Kernel)/KDUMP/Disk/SYSCTLS/FC/Multipath Conf/OS File/FS : CHECK
##                  -------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
##                      Date: 09/13/2016                                          |    Date: 10/25/2017
##                      BIOS Rev: 2.30                                            |    BIOS Rev: 2.52
##                      FW Rev:   2.50                                            |    FW Rev:   2.61
##                      Taint-check: 12289  (see https://access.redhat.com/soluti |    Taint-check: 12288  (see https://access.redhat.com/soluti
##                         0  PROPRIETARY_MODULE: Proprietary module has been loa <
##                      tainted =  "12289"  (see https://access.redhat.com/soluti |    tainted =  "12288"  (see https://access.redhat.com/soluti
##                         0  PROPRIETARY_MODULE: Proprietary module has been loa <
##                  -------------------------------------------------------------------------------------------------------------------------------
##              - local :
##                  [ CHECK    ] Check OS & HW Configuration - BIOS/System/CPU/MEM/OS(Version,Kernel)/KDUMP/Disk/SYSCTLS/FC/Multipath Conf/OS File/FS
##                  -------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
##                      Date: 09/13/2016                                          |    Date: 10/25/2017
##                      BIOS Rev: 2.30                                            |    BIOS Rev: 2.52
##                      FW Rev:   2.50                                            |    FW Rev:   2.61
##                      Taint-check: 12289  (see https://access.redhat.com/soluti |    Taint-check: 12288  (see https://access.redhat.com/soluti
##                         0  PROPRIETARY_MODULE: Proprietary module has been loa <
##                      tainted =  "12289"  (see https://access.redhat.com/soluti |    tainted =  "12288"  (see https://access.redhat.com/soluti
##                         0  PROPRIETARY_MODULE: Proprietary module has been loa <
##                  -------------------------------------------------------------------------------------------------------------------------------
###########################################################################
_os_summ(){
    OS_HW_SUMMARY=$MAINPATH/os_hw_summary_`date +%Y%m%d%H%M%S`.log
    SAVE_OS_HW_SUMMARY=$MAINPATH/os_hw_summary_save.log
    SYSD_ANZ=$MAINPATH/systemd-analyze_`date +%Y%m%d%H%M%S`.log
    
    LAST_OS_HW_SUMMARY=`ls -rt $MAINPATH/os_hw_summary_*.log | tail -1 2>&1 `
    
    if [ -f /bin/xsos ];then
    
        if [ ${os_version:0:10} == 3.10.0-327 ] ; then
            #EXCLUDE='Sys time|Boot time|Uptime|LoadAvg|\/proc\/stat|procs_running:|Utilization since boot|steal [0-9]*%|file-nr|inode-nr| sd|entropy_avail|Available free space'
            EXCLUDE='Sys time|Boot time|Uptime|LoadAvg|\/proc\/stat|procs_running:|Utilization since boot|steal [0-9]*%|file-nr|inode-nr| sd|entropy_avail|Available free space|random.boot'
            #export LANG=ko_KR.UTF-8;xsos -bokcdtlgisx | egrep -v "$EXCLUDE" >> $OS_HW_SUMMARY
            export LANG=ko_KR.UTF-8;xsos -bokcdlsx 2>&1 | egrep -v "$EXCLUDE" >> $OS_HW_SUMMARY
            #systemd-analyze >> $OS_HW_SUMMARY
            systemd-analyze > $SYSD_ANZ
        
            systemctl --failed >> $OS_HW_SUMMARY
        else
            #EXCLUDE='Sys time|Boot time|Uptime|LoadAvg|\/proc\/stat|procs_running:|Utilization since boot|steal [0-9]*%|file-nr|inode-nr| sd|entropy_avail|Available free space'
            EXCLUDE='Sys time|Boot time|Uptime|LoadAvg|\/proc\/stat|procs_running:|Utilization since boot|steal [0-9]*%|file-nr|inode-nr| sd|entropy_avail|Available free space|random.boot'
            #export LANG=ko_KR.UTF-8;xsos -bokcdtlgisx | egrep -v "$EXCLUDE" >> $OS_HW_SUMMARY
            export LANG=ko_KR.UTF-8;xsos -bokcdlsx 2>&1 | egrep -v "$EXCLUDE" >> $OS_HW_SUMMARY
        fi
    
    fi
    
    if [ `rpm -qa | grep sysfsutil | wc -l` -gt 0 ]; then
        systool -c fc_host -vv 2>&1 | egrep 'port_id |port_name |port_state |speed ' >> $OS_HW_SUMMARY
    fi
    
    #multipathd show config 2> /dev/null >> $OS_HW_SUMMARY
    
    CHECK_FILE_LIST="/etc/firewalld
    /etc/lvm/backup
    /etc/multipath/bindings
    /etc/pam.d
    /etc/security/limits.d
    /etc/sysconfig/network-scripts
    /etc/systemd
    /etc/udev/rules.d
    /var/spool/cron/root
    /boot/grub2/grub.cfg
    /etc/chrony.conf
    /etc/cron.d/sysstat
    /etc/default/grub
    /etc/exports
    /etc/fstab
    /etc/hostname
    /etc/hosts
    /etc/kdump.conf
    /etc/login.defs
    /etc/lvm/lvm.conf
    /etc/machine-id
    /etc/machine-info
    /etc/modprobe.d/ipv6.conf
    /etc/modprobe.d/mlx4.conf
    /etc/multipath/multipath.conf
    /etc/nsswitch.conf
    /etc/ntp.conf
    /etc/rc.local
    /etc/resolv.conf
    /etc/rsyslog.conf
    /etc/security/limits.conf
    /etc/selinux/config
    /etc/ssh/ssh_config
    /etc/ssh/sshd_config
    /etc/sysconfig/grub
    /etc/sysconfig/ip6tables-config
    /etc/sysconfig/iptables-config
    /etc/sysconfig/iptables.save
    /etc/sysconfig/selinux
    /etc/sysctl.conf
    /etc/sysctl.d
    /etc/tuned/active_profile
    /etc/tuned/bootcmdline
    /etc/tuned/tuned-main.conf
    /etc/vsftpd/ftpusers
    /etc/vsftpd/user_list
    /etc/vsftpd/vsftpd.conf
    /etc/yum.conf
    /etc/yum.repos.d/local.repo
    /etc/yum.repos.d/redhat.repo
    /sbin/ifup-local
    /lib/ocf/resource.d/
    "
    for LIST in $CHECK_FILE_LIST
    do
        #if [ -d $LIST ] ; then
        #    find $LIST -type f | xargs grep -H -v ^#
        #elif [ -f $LIST ] ; then
        #    find $LIST | xargs grep -H -v ^#
        #fi

        #cp $LIST $MAINPATH"/SaveFiles/"$LIST
        echo ""

    done  >> $OS_HW_SUMMARY
    
    df -h | grep -v tmpfs | awk '{print $1" "$6}' | sort -u >> $OS_HW_SUMMARY
    
    if [ ! -f $SAVE_OS_HW_SUMMARY ]; then
        SAVE_OS_HW_SUMMARY=$LAST_OS_HW_SUMMARY
    fi
    
    if [ `rpm -qa | grep multipath | wc -l` -gt 0 ]; then
        multipathd show config 2> /dev/null >> $OS_HW_SUMMARY
    fi
    
    OS_STAT=`diff -y --suppress-common-lines $SAVE_OS_HW_SUMMARY $OS_HW_SUMMARY | wc -l`
    
    
    if [ $OS_STAT -gt 0 ]; then
        echo "$tag_CHECK  Check OS & HW Configuration - BIOS/System/CPU/MEM/OS(Version,Kernel)/KDUMP/Disk/SYSCTLS/FC/Multipath Conf/OS File/FS"
        echo "-------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
        diff -y --suppress-common-lines $SAVE_OS_HW_SUMMARY $OS_HW_SUMMARY | tee -a $LOG
        echo "-------------------------------------------------------------------------------------------------------------------------------"
    else
        echo "$tag_OK Check OS & HW Configuration - BIOS, System, CPU, Memory, OS (Hostname, Version, YUM, Kernel), KDUMP CONFIG, Disk, SYSCTLS" 
    fi
    
    #if [ -f $LAST_OS_HW_SUMMARY ] ; then    
    #        OS_STAT=`diff -y --suppress-common-lines $LAST_OS_HW_SUMMARY $OS_HW_SUMMARY | wc -l`
    #
    #        if [ $OS_STAT -gt 0 ]; then
    #                echo "[ CHECK ] Check OS & HW Configuration (vs LAST) - BIOS, System, CPU, Memory, OS (Hostname, Version, YUM, Kernel), KDUMP CONFIG, Disk, SYSCTLS"
    #                echo "-------------------------- [ LAST ] --------------------------|---------------------------- [ CHECK ] -------------------------"
    #                diff -y --suppress-common-lines $LAST_OS_HW_SUMMARY $OS_HW_SUMMARY | tee -a $LOG
    #                echo "-------------------------------------------------------------------------------------------------------------------------------"
    #        else
    #                echo "[ OK    ] Check OS & HW Configuration (vs LAST) - BIOS, System, CPU, Memory, OS (Hostname, Version, YUM, Kernel), KDUMP CONFIG, Disk, SYSCTLS"
    #        fi
    #fi
}

###########################################################################
##  Function Name : _run_proc
##  Description : Check running process and count numbers of processes
##  information : examples of output
##              - OPMATE : 
##                  @@@Check OS & HW Configuration - BIOS/System/CPU/MEM/OS(Version,Kernel)/KDUMP/Disk/SYSCTLS/FC/Multipath Conf/OS File/FS : CHECK
##                  -------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
##                        1 imweb    LLAWP                        <
##                        5 imweb    httpd                        <
##                        3 imweb    rotatelogs                   <
##                        2 portal   java                         <
##                  -------------------------------------------------------------------------------------------------------------------------------
##              - local :
##                  [ CHECK    ] Check OS & HW Configuration - BIOS/System/CPU/MEM/OS(Version,Kernel)/KDUMP/Disk/SYSCTLS/FC/Multipath Conf/OS File/FS
##                  -------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
##                        1 imweb    LLAWP                        <
##                        5 imweb    httpd                        <
##                        3 imweb    rotatelogs	                  <
##                        2 portal   java                         <
##                  -------------------------------------------------------------------------------------------------------------------------------
###########################################################################
_run_proc(){
    LOG=$MAINPATH/check_process_`date +%Y%m%d%H%M%S`.log

    PROCESS_SUMMARY=$MAINPATH/process_summary_`date +%Y%m%d%H%M%S`.log
    SAVE_PROCESS_SUMMARY=$MAINPATH/process_summary_save.log
    FULL_PROCESS_LOG=$MAINPATH/full_process_`date +%Y%m%d%H%M%S`.log
    
    EXCLUDE_ACCOUNT='^(root|nobody|USER|dbus|libstor+|ntp|polkitd|rpc|rpcuser|skccadm|[a-z]{3}[0-9]{3}+|[a-z]{3}d[a-z][0-9]{1}+|[a-z]{3}b[0-9]{2})$'
    EXCLUDE_COMMAND='vim|vi|bash|sh|sendmail|iostat|mpstat|sqlplus|vmstat|top|sar|ps|uniq|sort|mv|cp|scp|rsync|wc|netstat|grep|awk|sed|find|sleep|tail|head'
    
    LAST_PROCESS_SUMMARY=`ls -rt $MAINPATH/process_summary_*.log | tail -1 2>&1 `
    ps -eo user,comm | awk '$1 !~ /'"$EXCLUDE_ACCOUNT"'/ && $2 !~ /'"$EXCLUDE_COMMAND"'/' | sed 's/ ora.*$/ oracle/g' |  sed 's/ asm.*$/ asm/g' | sed 's/tmax.*$/tmax/g' | sort | uniq -c > $PROCESS_SUMMARY
    
    if [ ! -f $SAVE_PROCESS_SUMMARY ]; then
        SAVE_PROCESS_SUMMARY=$LAST_PROCESS_SUMMARY
    fi
    
    if [ ! -f $SAVE_PROCESS_SUMMARY ]; then
        SAVE_PROCESS_SUMMARY=$LAST_PROCESS_SUMMARY
    fi
    
    P_STAT=`diff -y --suppress-common-lines $SAVE_PROCESS_SUMMARY $PROCESS_SUMMARY | wc -l`
    
    if [ $P_STAT -gt 0 ]; then
        echo "$tag_CHECK Check Process Count"
        echo "-------------------------- [ SAVE ] --------------------------|---------------------------- [ CHECK ] -------------------------"
        diff -y --suppress-common-lines $SAVE_PROCESS_SUMMARY $PROCESS_SUMMARY | tee -a $LOG
        echo "-------------------------------------------------------------------------------------------------------------------------------"
    else
        echo "$tag_OK Check Process Count"
    fi
    
    
    #if [ -f $LAST_PROCESS_SUMMARY ] ; then
    #        P_STAT=`diff -y --suppress-common-lines $LAST_PROCESS_SUMMARY $PROCESS_SUMMARY | wc -l`
    #
    #        if [ $P_STAT -gt 0 ]; then
    #                echo "[ CHECK ] Check Process Count (vs LAST)"
    #               echo "-------------------------- [ LAST ] --------------------------|---------------------------- [ CHECK ] -------------------------"
    #               diff -y --suppress-common-lines $LAST_PROCESS_SUMMARY $PROCESS_SUMMARY | tee -a $LOG
    #               echo "-------------------------------------------------------------------------------------------------------------------------------"
    #        else
    #                echo "[ OK    ] Check Process Count (vs LAST)"
    #        fi
    #fi
    
    ps -ef > ${FULL_PROCESS_LOG}
}


###########################################################################
##  Function Name : _chk_cubeone
##  Description : If cubeone process was running when save, notify to check cubeone process
##  information : examples of output
##              - OPMATE : @@@Check Cubeone Agent : CHECK
##              - local : [ NOTI     ] Check Cubeone Agent
###########################################################################
_chk_cubeone(){

    if [ `grep cube $MAINPATH/full_process_save.log | wc -l` -gt 0 ]; then
        echo "$tag_noti Check Cubeone Agent"
    fi
}
# ======<<<< Function Registration Area Marking Comment (End) >>>>===================================


# ======<<<< Main Logic Coding Area Marking Comment (Start) >>>=======================================	
#_main(){
#    if [ "$1" != "daily" -a "$1" != "pmcheck" ]; then
#        echo "Wrong Argument 1 : daily or pmcheck"
#        exit 1
#    elif [ "$2" != "" -a "$2" != "local" ]; then
#        echo "Wrong Argument 2 : NULL or local"
#        exit 1
#    fi

#    if [ $1 == "daily" ]; then
        #_uptime $2
        #_osversion $2
        _cpuutil $2
        _memutil $2
        _multipath $2
        #_network $2
        _network_bonding $2
        _ping $2
        _infiniband $2
        #_netstat $2
        #_ethool $2
        _cluster $2
        _fsutil $2
        _fsinode $2
        _cntproc $2
        _osproc $2
        #_infsw $2
        #_bootlog $2
        _msglog $2
        _dmesg $2
        _hwlog $2
        #_ntp $2
        #_os_summ $2
        #_run_proc $2
        #_chk_cubeone $2
#    elif [ $1 == "pmcheck" ]; then
#        _uptime $2
#        _osversion $2
#        _cpuutil $2
#        _memutil $2
#        _multipath $2
#        _network $2
#        _network_bonding $2
#        _ping $2
#        _infiniband $2
#        _netstat $2
#        _ethool $2
#        _cluster $2
#        _fsutil $2
#        _fsinode $2
#        _cntproc $2
#        _osproc $2
#        _infsw $2
#        _bootlog $2
#        _msglog $2
#        _dmesg $2
#        _hwlog $2
#        _ntp $2
##        _os_summ $2
#        _run_proc $2
#        _chk_cubeone $2
#    fi
#}


#_main $1 $2
# ======<<<< Main Logic Coding Area Marking Comment (End) >>>=========================================

