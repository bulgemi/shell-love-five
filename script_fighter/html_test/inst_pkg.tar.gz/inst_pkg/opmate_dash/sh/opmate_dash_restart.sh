#!/bin/sh

ps -ef |grep gunicorn |grep manage:app |grep -v grep |awk '{print $2}' |xargs kill;

cd $OPMATE_DASH_HOME;
nohup gunicorn -D -w16 -t 300 -b 127.0.0.1:5000 manage:app;

