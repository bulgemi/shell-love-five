#!/bin/sh
source ~/.bashrc;
python $OPMATE_DASH_HOME/app/reminder/reminder.py -c $OPMATE_DASH_HOME/app/config/cellar.yml;
python $OPMATE_DASH_HOME/app/reminder/general_survey_reminder.py -c $OPMATE_DASH_HOME/app/config/cellar.yml;
