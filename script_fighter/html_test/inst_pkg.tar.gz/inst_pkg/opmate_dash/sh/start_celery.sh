#!/bin/sh
cd $OPMATE_DASH;
#celery -A manage.celery beat -f $OPMATE_DASH/celery_beat.log --logfile=LOGFILE --loglevel=DEBUG &
#celery -A manage.celery worker -f $OPMATE_DASH/celery.log --logfile=LOGFILE --loglevel=DEBUG &
celery -A manage.celery beat --loglevel=DEBUG &
celery -A manage.celery worker --loglevel=DEBUG &
flower -A manage.celery --port=5555 &

