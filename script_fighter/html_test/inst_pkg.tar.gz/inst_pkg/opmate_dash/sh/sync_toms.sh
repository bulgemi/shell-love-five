#!/bin/sh
source ~/.bashrc;
python $OPMATE_DASH_HOME/app/dataloader/dataloader.py -c $OPMATE_DASH_HOME/app/config/dataloader.yml;
