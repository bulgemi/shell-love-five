########################################################################################################################## 
## 
## File name: wincheck_daily
## Description: Script to check system daily.
## Information:
##
##========================================================================================================================
## version  date         author                 reason
##------------------------------------------------------------------------------------------------------------------------
## 1.0      2018.10.16   K.K.H, S.H.C, P.H.J    First created.
## 1.1      2018.11.14   K.K.H                  Modified format of output and removed unnecessary functions
##########################################################################################################################
# ==================<<<< Important Global Variable Registration Area Marking Comment (Start)>>>>>=========================
$Script:outputfile = '.\output_dailycheck.txt'
# ==================<<<< Important Global Variable Registration Area Marking Comment (End)>>>>>===========================
# ==================<<<< Function Registration Area Marking Comment (Start)>>>>>==========================================
##########################################################################################################################
## Function name: Sub_print($object,$state,$detail)
## Description: Print execution results
## Information:
## - When the function is called, each of the 3 variables receives its own values. The 3 variables are $object, $state and $detail.
##  a. $object is the item to check, which is similar to the function name.
##  b. $state is the check result, which is either ok or check.
##  c. $detail is a detailed execution result, and is only printed if $state is checked.
##########################################################################################################################
Function Sub_print($object,$state,$detail)
{
    # Print in Output file
    write-host '@@@'$object' : '$state' - '    
    $detail
}
##########################################################################################################################
## Function name: Check-Uptime
## Description: Check system uptime
## Information: The uptime check creteria is 1 year. Less than 1 year is normal and the result is displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-Uptime
{
    $object = 'Uptime'
    $os = Get-Wmiobject win32_operatingsystem
    $uptime = (Get-Date) - ($os.ConvertToDateTime($os.lastbootuptime))
    $days=$uptime.Days
    $hours=$uptime.Hours
    $minutes=$uptime.Minutes
    if($Uptime.Days -lt 730){
        $state = 'OK'
        $detail =  "$days days, $hours hours, $minutes minutes"   
    } else{
        $state = 'CHECK'
        $detail =  "$days days, $hours hours, $minutes minutes"
    }
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Check-GWping
## Description: Check response time by ping test to the default gateway
## Information: The GWping check creteria is 5 ms. Less than 5 ms is normal and the result is displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-GWping
{
    $object = 'Gateway Ping'
    $gw = (Get-WmiObject Win32_networkAdapterConfiguration | ?{$_.DefaultIPGateway}).DefaultIPGateway
    $cmd = "ping $gw"
    [array]$ping = cmd.exe /c $cmd
    [array]$split = $ping[10] -split("=")
    $result = $split[3].Trim(" ")
    $result = $result.Trim("ms")
    if ($result -lt 5)
    {
        $state = 'OK'
        #$detail =  $ping[10]
        $detail =  $ping[10].Trim(" ")
    }
    else
    {   
        $state = 'CHECK'
        $detail =  $ping[10].Trim(" ")
    }
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Check-DNS
## Description: Check DNS is normal working
## Information: Check that the IP from NSlookup test to the test domain is the same as the actual IP.
##              If they are the same, "OK" is displayed. Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-DNS
{
    $object = 'DNS'
    $domain = "www.sktelecom.com"  #TEST 도메인
    $IP = "203.236.1.62" #비교할 IP
    $result=[System.Net.Dns]::Gethostaddresses("$domain") | select-object IPAddressToString -expandproperty IPAddressTostring  #NSLOOK 수행 결과
    # Check that the IP($result) from NSlookup test to the test domain is the same as the actual IP($IP)
    if($result -eq $IP ){
        $state = 'OK'
        $detail = "["+ $domain+" -> "+$IP+"]"
    } else {
        $state = 'CHECK'
        $detail =  "Check DNS is Failed"
    }
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Check-MonService
## Description: Check whether AnyCatcher or Ontune is started. 
## Information: If either of them is running, "OK" is displayed. Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-MonService
{
    $object = 'Monitoring'
    $ont = Get-WmiObject -Class Win32_Service -Filter "name='OnTuneAgentService'"
    $acem = Get-WmiObject -Class Win32_Service -Filter "Name='ACEMAgentSVC'"
    $OntStat = $ont.State
    $AcemStat =$acem.State
    if($OntStat -eq "Running" ){
        $state = 'OK'
        $detail = "Ontune Agent is Running"
    }elseif($AcemStat -eq "Running"){
        $state = 'OK'
        $detail = "AnyCatcher Agent is Running"  
    } else {
        $state = 'CHECK'
        $detail = "Monitoring Agent is NOT Running"
    }
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Check-MemoryUsage
## Description: Check memory utilization and usage top 10 processes.
## Information: The memory usage check creteria is 90%. Less than 90% is normal and the result is displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##  - Check the usage top 10 process by calling Get-Memtop10.
##########################################################################################################################
Function Check-MemoryUsage
{
    $OFS = "`r`n"   
    $object = 'Memory Usage'
    $ComputerMemory = Get-WmiObject -Class win32_operatingsystem -ErrorAction Stop
    $Memory = ((($ComputerMemory.TotalVisibleMemorySize - $ComputerMemory.FreePhysicalMemory)*100)/$ComputerMemory.TotalVisibleMemorySize)
    $RoundMemory = [math]::Round($Memory, 2)
    $memtop10 = Get-MEMtop10
    if($RoundMemory -lt 90 ){
        $state = 'OK'
        $detail = "Memory Usage : $RoundMemory%"+$OFS+ $memtop10
    } else {
        $state = 'CHECK'
        $detail = "Memory Usage : $RoundMemory%"+$OFS+ $memtop10
        Write-Host
    }
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Get-MEMtop10
## Description: Get memory usage top 10 processes.
## Information:
##########################################################################################################################
Function Get-MEMtop10
{
    $result = get-process | sort-object -property workingset -descending | select-object -first 10 |format-table -autosize @{name='ProcessID';Expression={($_.id)}},@{name='ProcessName';Expression={($_.name)}},@{name='WorkingSet(K)';Expression={($_.WS/1024)}},@{name='Virtual(K)';Expression={($_.VM/1024)}},@{name='Handles';Expression={($_.handles)}} | Out-String
     
    #$result = get-process | select-object @{name='ProcessID';Expression={($_.id)}},@{name='ProcessName';Expression={($_.name)}},@{name='WorkingSet(K)';Expression={($_.WS/1024)}},@{name='Virtual(K)';Expression={($_.VM/1024)}},@{name='Handles';Expression={($_.handles)}} |
    #sort-object -property workingset -descending |
    #Select-Object -First 10 | format-table -autosize | Out-String
    return $result
}
##########################################################################################################################
## Function name: Check-PagingFile
## Description: Check PageingFile utilization.
## Information: The PagingFile usage check creteria is 90%. Less than 90% is normal and the result is displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-PagingFile
{
    $object = 'PagingFIle Usage'
    $paging = Get-Counter -Counter "\Paging File(_total)\% Usage"
    $usage = ($paging.readings.split(":"))[-1]
    $RoundUsage = [math]::Round($usage,2)
    if($RoundUsaget -lt 90){
        $state = 'OK'
        $detail = "PaingFile Usage : $RoundUsage%"
         
    } else {
        $state = 'CHECK'
        $detail = "PagingFile Usage : $RoundUsage%"
    }
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Get-CPUtop10
## Description: Get CPU usage top 10 processes.
## Information:
##########################################################################################################################
Function Get-CPUtop10
{
  
    $CounterSamples = Get-Counter '\Process(*)\ID Process','\Process(*)\% Processor Time' | Select-Object -Expand CounterSamples
    $result = $CounterSamples | Group-Object { Split-Path $_.Path } | Where-Object {$_.Group[1].InstanceName -notmatch "^Idle|_Total"} | Sort-Object -Property {$_.Group[1].CookedValue} -Descending | Select-Object -First 10 | Format-Table -autosize @{Name=" ProcessID ";Expression={$_.Group[0].CookedValue}},@{Name=" ProcessName ";Expression={$_.Group[1].InstanceName}},@{Name=" CPU % ";Expression={[System.Math]::Round($_.Group[1].CookedValue/$env:NUMBER_OF_PROCESSORS,4)}} |Out-String
    return $result
}
##########################################################################################################################
## Function name: Check-CPUUsage
## Description: Check CPU utilization and usage top 10 processes.
## Information: The CPU usage check creteria is 90%. Less than 90% is normal and the result is displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##  - Check the usage top 10 process by calling Get-CPUtop10.
##########################################################################################################################
Function Check-CPUUsage
{
    $OFS = "`r`n"
    $object = 'CPU Usage'
    $proc = Get-Counter -Counter "\Processor(_Total)\% Processor Time" -SampleInterval 1
    $cpu = ($proc.readings.split(":"))[-1]
    $RoundCPU = [math]::Round($cpu,2)
    $cputop10 = Get-CPUtop10
    if($RoundCPU -lt 90){
        $state = 'OK'
        $detail = "CPU Usage : $RoundCPU%" +$OFS+$cputop10
    } else {
        $state = 'CHECK'
        $detail = "CPU Usage : $RoundCPU%" +$OFS+$cputop10
    }
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Check-DiskUsage
## Description: Check all local disks utilization.
## Information: The Disk utilization check creteria is 90%. Less than 90% is normal and the result is displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-DiskUsage
{
    $object = 'Disk Usage'
    $drives=Get-WmiObject Win32_LogicalDisk -ComputerName localhost -Filter "DriveType=3"
    $OFS = "`r`n"
    $t="Drive"+"`t"+"Free(GB)"+"`t"+"Total(GB)"+"`t"+"Usage(%)"
    $l="-----"+"`t"+"--------"+"`t"+"--------"+"`t"+"------"
    foreach ($drive in $drives)
    {
        $drivename=$drive.DeviceID
        $freespace=[decimal]("{0:N0}" -f($drive.FreeSpace/1GB))
        $totalspace=[decimal]("{0:N0}" -f($drive.Size/1GB))
        $usedspace=$totalspace - $freespace
        $usage=[decimal]("{0:N0}" -f(($usedspace) / ($totalspace)*100))
        if($usage -lt 95){
            $state = 'OK'
        }else{       
            $state = 'CHECK'
        }
        $output="  "+$drivename+ "`t  " +$freespace+"`t`t "+$totalspace +"`t`t "+$usage+$OFS
        $usagetree=$usagetree+$output
         
    }
    $detail =$t+$OFS+$l+$OFS+ $usagetree
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Check-Eventlog
## Description: Check critical, error event logs that occured from 1 day ago to now, except event logs that were excluded.
## Information: Because of increased memory usage during execution, only 10 recent events are collected.
##########################################################################################################################
Function Check-Eventlog
{
    $object = 'Eventlog'
    $CheckEvengLogResult = New-Object System.Collections.ArrayList
    $yesterday = (Get-Date).AddDays(-1)
     
    # event logs that were excluded.
    $events = @(10,7000,7023,7030,10010,137,19,40,12,21,1)
    $os = Get-Wmiobject win32_operatingsystem
     
    if( $os.caption.Contains("2008 Enterprise") -or $os.caption.Contains("2008 Standard"))
    {
        $ErrWarn4App = Get-EventLog -LogName System -EntryType Critical, Error -Newest 10 -After $yesterday | Where-Object {$events -notcontains $_.EventID} | Select-Object TimeGenerated, EntryType, Source, EventID, Message
    }
    else {
        $ErrWarn4App = Get-WinEvent -FilterHashTable @{LogName='System'; Level=1,2; StartTime=$yesterday} -ErrorAction SilentlyContinue | Select-Object TimeCreated,LogName,ProviderName,Id,LevelDisplayName,Message -first 10 | Where-Object {$events -NotContains $_.id}
    }
         
    if(!$ErrWarn4App)
    {
        $state = 'OK'
        $detail = "There is no critical error."
    } Else {
        $state = 'CHECK'
        $detail = $ErrWarn4App | Sort TimeCreated,ProviderName| Out-String 
    }
    sub_print $object $state $detail
}
##########################################################################################################################
## Function name: Check-NTPStatus
## Description: Check whether NTP time sync.
## Information: If both function CheckNTPServiceIsRunning and CheckNTPServerAndTime are ok, it is normal and displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-NTPStatus
{
        
    try
    {
        CheckNTPServiceIsRunning
           
         
        CheckNTPServerAndTime -ErrorAction Stop
        
    }
    catch
    {
        $ErrorEvents += ('[Get] [Start service] [Exception] {0}' -f $_.Exception.Message)
    }
}
##########################################################################################################################
## Function name: CheckNTPServiceIsRunning
## Description: Check whether W32Time services is running. If not running, start the service.
## Information:
##########################################################################################################################
Function CheckNTPServiceIsRunning
{
    # Start W32Time service
    if ((Get-Service -Name W32Time).Status -eq 'Running')
    {
        # Write-Host"[OK] The NTP service is running."
    }
    else
    {
        # Write-Host"[NOTOK] The NTP service is stopped."
        Write-Verbose -Message '[Get] [Start service] [Verbose] Start service: W32Time (Windows Time)'
        Start-Service -Name W32Time
    }
}
##########################################################################################################################
## Function name: Check-Service
## Description: Check for stopped services that are set to Auto-Started, except for services that were excluded.
## Information: Nothing is normal, and displayed as "ok". Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-Service {
    $object = 'Service Status'
    $Auto_Stopped_Service = Get-WmiObject Win32_Service -ComputerName . |`
                            Where-Object {($_.startmode -like "*auto*") -and `
                            ($_.state -notlike "*running*") -and `
                            ($_.DisplayName -ne "Microsoft .NET Framework NGEN v4.0.30319_X86") -and `
                            ($_.DisplayName -ne "NetBackup Bare Metal Restore Boot Server") -and `
                            ($_.DisplayName -ne "Software Protection") -and `
                            ($_.DisplayName -ne "Microsoft .NET Framework NGEN v4.0.30319_X64")}|`
                            select DisplayName,Name,StartMode,State| ft -AutoSize | Out-String
                             
    If(!$Auto_Stopped_Service){
        $state = 'OK'
        $detail
    } else{
         
        $state = 'Check'
        $detail = $Auto_Stopped_Service
     
    }
         
    sub_print $object $state $detail
            
}
##########################################################################################################################
## Function name: Check-Cluster
## Description: Check cluster is present, if cluster exists function Check-ClusterResource, Check-ClusterNetwork, and Check-ClusterNode execute.
## Information: If the execution results of all funtions is "ok", it is normal and displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##########################################################################################################################
Function Check-Cluster{
    Import-Module FailoverClusters -ErrorVariable Count_Error -ErrorAction SilentlyContinue
     
    $object = 'Cluster Status'
    $OFS = "`r`n"
    IF($Count_Error.Count -ne 0){
         
        $state =  'OK'
        $detail = "There is no cluster"
     
    } ELSE {
   
        $Result_Check_ClusterResource = Check-ClusterResource
        $Result_ClusterResource_Success = $Result_Check_ClusterResource.Success
        $Result_ClusterResource_Message = $Result_Check_ClusterResource.message
        $Result_ClusterResource_detail = $Result_Check_ClusterResource.detail
         
        $Result_Check_ClusterNetwork = Check-ClusterNetwork
        $Result_ClusterNetwork_Success = $Result_Check_ClusterNetwork.Success
        $Result_ClusterNetwork_Message = $Result_Check_ClusterNetwork.message
        $Result_ClusterNetwork_detail = $Result_Check_ClusterNetwork.detail
         
        $Result_Check_ClusterNode = Check-ClusterNode
        $Result_ClusterNode_Success = $Result_Check_ClusterNode.Success
        $Result_ClusterNode_Message = $Result_Check_ClusterNode.message
        $Result_ClusterNode_detail = $Result_Check_ClusterNode.detail
         
        IF($Result_ClusterResource_Success -like "true" -and $Result_ClusterNetwork_Success -like "true" -and $Result_ClusterNode_Success -like "true"){
         
            $state = "OK"
             
        } else{
             
            $state =  "Check"
            $detail = $Result_ClusterNode_Detail + $ofs + $Result_ClusterNetwork_Detail + $ofs + $Result_ClusterResource_Detail
             
        }
    }
    sub_print $object $state $detail
     
}
##########################################################################################################################
## Function name: Check-ClusterResource([String] $return_resource)
## Description: Check cluster resource status
## Information: If all cluster resource status are online, it is normal and displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##  - The exectution result and message are returned to $return_resource in hashtable form.
##########################################################################################################################
Function Check-ClusterResource([String] $return_resource) {
    $Check_ClusterResource_NotOnline = Get-ClusterResource | Where-Object {$_.state -ne "online"} | format-table -autosize | Out-String
    [hashtable] $return_resource = @{}
     
    IF(!$Check_ClusterResource_NotOnline) {
        $return_resource.Success = $true
        $return_resource.Message = "All cluster resources are online."
        return $return_resource
         
    } else{      
        $return_resource.Success = $false
        $return_resource.Message = "Not all cluster resources are online."
        $return_resource.detail = $Check_ClusterResource_NotOnline
        return $return_resource
             
    }
         
}
##########################################################################################################################
## Function name: Check-ClusterNetwork($return_network)
## Description: Check cluster network status
## Information: If all cluster network status are online, it is normal and displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##  - The exectution result and message are returned to $return_network in hashtable form.
##########################################################################################################################
Function Check-ClusterNetwork($return_network) {
    $Check_ClusterNetwork_NotOnline = Get-ClusterNetwork | Where-Object {$_.state -ne "online"} | format-table -autosize | Out-String 
    [hashtable] $return_network = @{}
     
    IF(!$Check_ClusterResource_NotOnline) {
        $return_network.Success = $true
        $return_network.Message = "Every cluster network is online"
        return $return_network
         
    } else{
        $return_network.Success = $false
        $return_network.Message = "Not every cluster network is online"
        $return_network.detail = $Check_ClusterNetwork_NotOnline
        return $return_network
    }
}
##########################################################################################################################
## Function name: Check-ClusterNode($return_node)
## Description: Check cluster network status
## Information: If all cluster note status are up, it is normal and displayed as "ok".
##              Otherwise, it is marked as "check" and needs confirmation.
##  - The exectution result and message are returned to $return_node in hashtable form.
##########################################################################################################################
Function Check-ClusterNode([String] $return_node) {
    $Check_ClusterNode_NotOnline = Get-ClusterNode | Where-Object {$_.state -ne "up"} | format-table -autosize @{name='Node Name';Expression={($_.Name)}},@{name='State';Expression={($_.State)}} | Out-String     
    [hashtable] $return_node = @{}
     
    IF(!$Check_ClusterNode_NotOnline) {
        $return_node.Success = $true
        $return_node.Message = "All cluster nodes are up"
        return $return_node
         
    } else{
        $return_node.Success = $false
        $return_node.Message = "Not all cluster nodes are up"
        $return_node.detail = $Check_ClusterNode_NotOnline
        return $return_node
             
    }
}
##########################################################################################################################
## Function name: Delete-TXT
## Description: If there is a text file with the same name as the file that is created when the script runs, this funtion deletes this text.
## Information:
##########################################################################################################################
Function Delete-TXT {
    If(Test-Path $outputfile){
        $outputfile
        Remove-Item $outputfile -ErrorAction SilentlyContinue
    }
}
##########################################################################################################################
## Function name: Get-IP
## Description: Listing all IP address of the server.
## Information:
##########################################################################################################################
Function Get-IP
{
    $object = 'Check IP Address'
    [array]$iplist=Get-WmiObject win32_networkadapterconfiguration -filter 'ipenabled = "True" AND DHCPEnabled = "FALSE"'| findstr IPAddress
     
    $i=0
    foreach($ip in $iplist)
    {
        $iplist[$i] = ($ip -split "{")[1]
         
        if ($iplist[$i].Contains(','))
        {
            $iplist[$i] = ($iplist[$i] -split ",")[0]
        }
         
        $iplist[$i] = ($iplist[$i] -split "}")[0]
        $ipstring = $ipstring + $iplist[$i] + ", "
        $i++
    }
    $ipstring = $ipstring.Remove($ipstring.Length-2)
    if(!$ipstring)
    {
        $state = 'CHECK'
        $detail =  "Check IP address"
    }else
    {
        $state = 'OK'
        $detail =  $ipstring
    }
    sub_print $object $state $detail
}
     
##########################################################################################################################
## Function name: Get-OS
## Description: Get OS version.
## Information:
##########################################################################################################################
Function Get-OS
{
    $object = 'Check OS'
    $os = Get-Wmiobject win32_operatingsystem
     
    if(!$os)
    {
        $state = 'CHECK'
        $detail =  "Check OS Version"
    }else
    {
        $state = 'OK'
        $detail =  $os.caption
    }
    sub_print $object $state $detail
}
# ==================<<<< Function Registration Area Marking Comment (End)>>>>>==========================================
# ==================<<<< Main Logic Area Marking Comment (Start)>>>>>=====================================================
Delete-TXT
Get-IP
Get-OS
Check-Uptime
#Check-GWping
Check-DNS
Check-NTPStatus
Check-MonService
Check-CPUUsage
Check-MemoryUsage
Check-PagingFile
Check-DiskUsage
#Check-Eventlog
#Check-Service
Check-Cluster
# ==================<<<< Main Logic Area Marking Comment (End)>>>>>=====================================================
