# _*_ coding: utf-8 _*_

import unittest
# import time
# from datetime import datetime
from flask import current_app
# cellar
from app import db, create_app


class TaskOpmwTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app_context = self.app.app_context()
        # self.app_context().push()

    def tearDown(self):
        db.session.remove()
        # self.app_context().pop()

    def test_opmate_node_list(self):
        from app.opmw.dashboard.dao import get_agent_info
        result = get_agent_info.get_agent_list()
        current_app.logger.debug("result: <%r>" % result)
