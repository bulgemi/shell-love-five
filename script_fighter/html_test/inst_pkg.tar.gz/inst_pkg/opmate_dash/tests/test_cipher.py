# _*_ coding: utf-8 _*_
import unittest
# cellar
from app import create_app, db


class CipherTestCase(unittest.TestCase):
    """
    암호화 모듈 기능 점검
    """
    def setUp(self):
        self.app = create_app()
        self.app_context = self.app.app_context()
        # self.app_context().push()

    def tearDown(self):
        db.session.remove()
        # self.app_context().pop()

    def test_01_crypto_util_enc(self):
        from app.cipher.crypto_util import AESCipher

        aes = AESCipher()
        message = "kim dong-hun"

        enc_message = aes.encrypt(message)

        print("message=<%r>, enc_message=<%r>, dec_message=<%r>"
              % (message, enc_message, aes.decrypt(enc_message)))

        if enc_message is not None:
            self.assertTrue(True)
        else:
            self.assertTrue(False, msg='암호화 실패')

    def test_02_crypto_util_enc(self):
        from app.cipher.crypto_util import AESCipher

        aes = AESCipher()
        message = u"김동훈"
        enc_message = aes.encrypt(message)

        print("message=<%r>, enc_message=<%r>, dec_message=<%r>"
              % (message, enc_message, aes.decrypt(enc_message)))

        if enc_message is not None:
            self.assertTrue(True)
        else:
            self.assertTrue(False, msg='암호화 실패')

    def test_03_crypto_util_enc(self):
        from app.cipher.crypto_util import AESCipher

        aes = AESCipher()
        message = "kim dong-hun!@#$%^&*()_+"
        enc_message = aes.encrypt(message)

        print("message=<%r>, enc_message=<%r>, dec_message=<%r>"
              % (message, enc_message, aes.decrypt(enc_message)))

        if enc_message is not None:
            self.assertTrue(True)
        else:
            self.assertTrue(False, msg='암호화 실패')

    def test_04_crypto_util_enc(self):
        from app.cipher.crypto_util import AESCipher

        aes = AESCipher()
        message = u"김!@#$%동^&*(훈)_+"
        enc_message = aes.encrypt(message)

        print("message=<%r>, enc_message=<%r>, dec_message=<%r>"
              % (message, enc_message, aes.decrypt(enc_message)))

        if enc_message is not None:
            self.assertTrue(True)
        else:
            self.assertTrue(False, msg='암호화 실패')
