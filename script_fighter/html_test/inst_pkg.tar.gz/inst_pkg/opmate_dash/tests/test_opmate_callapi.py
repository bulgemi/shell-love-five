import unittest
# import time
# from datetime import datetime
from flask import current_app
# cellar
from app import db, create_app


class TaskOpmwTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app_context = self.app.app_context()
        # self.app_context().push()

    def tearDown(self):
        db.session.remove()
        # self.app_context().pop()

    def test_dashboard_restapi_login_result(self):
        from app.opmw.api import call_api
        call_api.opmate_login()

    # def test_dashboard_restapi_viewrunall_result(self):
    #     from app.opmw.api import call_api
    #     call_api.opmate_task_viewrunall('kym_task01')

    # def test_dashboard_restapi_rerun_result(self):
    #     from app.opmw.api import call_api
    #     call_api.opmate_task_rerun(8434, 'P117504NT')
    # #
    # def test_dashboard_restapi_viewrun_result(self):
    #     from app.opmw.api import call_api
    #     call_api.opmate_task_viewrun(8434, 'P117504NT')

    # def test_dashboard_insert_ondemand_run_hist_result(self):
    #
    #     from app.opmw.api import ondemand_run_hist_save, ondemand_run_hist_edit
    #     result, ondemand_no = ondemand_run_hist_save.save_ondemand_run_hist(2555, 'skt_agent03', 'youngme_kim')
    #
    #     if result :
    #         ondemand_run_hist_edit.update_ondemand_run_hist(ondemand_no, 2)

    # def test_dashboard_restapi_rerun_result(self):
    #     from app import get_login_session_info
    #     from app.taskqueue import task_opmw_ondemand
    #     from time import sleep
    #
    #     task_id = 'db_dailycheck'
    #     instance_no = 10263
    #     node_id = 'skt_agent01'
    #
    #     # task_id = 'opmw_check'
    #     # instance_no = 7280
    #     # node_id = 'skt_agent01'
    #
    #     ret = task_opmw_ondemand.run_job(task_id, instance_no, node_id,
    #                                      get_login_session_info('USR_ID'))
    #     current_app.logger.debug("call run_job queue = <%r><%r><%r><%r><%r>" % (
    #     ret, task_id, instance_no, node_id, get_login_session_info('USR_ID')))


    def test_dashboard_restapi_viewrun_result(self):
        from app.opmw.api import call_api
        from app.opmw.fileio.result_file_div import get_viewrun_result_list, save_viewrun_result_file, delete_viewrun_result_file
        from app.opmw.fileio.result_file_parsing import dailycheck_result_parsing
        from app.opmw.dao.insert_task_run_list import save_dailycheck_result_list_dtl, save_task_run_list
        from app.opmw.dao.get_task_run_list import get_run_list_max_result_no
        from app.opmw.dailycheck.dailycheck_api import check_dailycheck_result_okyn
        from app import get_login_session_info
        from app.taskqueue import task_opmw_ondemand
        from time import sleep

        task_id = 'linux_dailycheck'
        instance_no = 16754
        node_id = 'skt_agent01'
        runner_id = 'opmate'
        # task_id = 'opmw_check'
        # instance_no = 7280
        # node_id = 'skt_agent01'

        run_insert_rst, task_result_no = save_task_run_list(task_id, instance_no, node_id, runner_id)

        if run_insert_rst:
            view_rst, viewrun_result = call_api.opmate_task_viewrun(instance_no, node_id)

        # view_rst, viewrun_result = call_api.opmate_task_viewrun('opmw_check', 7280, 'skt_agent01')
        current_app.logger.debug("viewrun opmate_task_viewrun <view_rst:%r><viewrun_result:%r>" % (view_rst,viewrun_result))

        if view_rst:
            viewrun_result_list = get_viewrun_result_list(viewrun_result)
            for idx in range(0, len(viewrun_result_list)):
                if viewrun_result_list[idx]['status'] == 'Complete':
                    # 5. Task run node file create
                    save_viewrun_result_file(viewrun_result_list[idx])

                    # 6. Task run node result file parsing
                    result_list = dailycheck_result_parsing(viewrun_result_list[idx]['filepath'])

                    # 7.Task run node result DB Insert (TASK_RUN_LIST_DTL table)
                    save_result = save_dailycheck_result_list_dtl(result_list, task_result_no)

                    if save_result:
                        # check_result = check_dailycheck_result_okyn(task_result_no)
                        check_result = check_dailycheck_result_okyn(task_result_no, viewrun_result_list[idx])

                        # 9. result file delete
                        if check_result:
                            delete_viewrun_result_file(viewrun_result_list[idx]['filepath'])
                else:
                    current_app.logger.debug(
                        "viewrun <status:%r> ....... retry........." % (viewrun_result_list[idx]['status']))
        else:
            current_app.logger.debug("rerun fail <task_id:%r> <instance_no:%r> <node_id:%r> <runner_id:%r>" % (task_id, instance_no, node_id, runner_id))

