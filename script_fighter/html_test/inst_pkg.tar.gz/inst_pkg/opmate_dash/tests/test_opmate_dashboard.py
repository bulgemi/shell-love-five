import unittest
# import time
# from datetime import datetime
from flask import current_app
# cellar
from app import db, create_app

class TaskOpmwTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app_context = self.app.app_context()
        # self.app_context().push()

    def tearDown(self):
        db.session.remove()
        # self.app_context().pop()

    def test_dailycheck_get_task_run_list(self):
        from app.opmw.dao import get_task_run_list_data
        task_result_list = get_task_run_list_data.get_task_run_list()
        print("select result_list=<%r>" % task_result_list)

    def test_dailycheck_result_parsing_n_save(self):
        from app.opmw.fileio import result_file_parsing
        from app.opmw.dao import insert_task_run_list_data, get_task_run_list_data, delete_task_run_list
        result_list_1 = result_file_parsing.dailycheck_result_parsing('sample_dailycheck_stdout.txt')
        print("parsing result_list_1=<%r>" % result_list_1)
        max_dtl_task_result_no_1 = get_task_run_list_data.get_run_list_dtl_max_result_no()
        print("save max_dtl_task_result_no_1=<%r>" % str(max_dtl_task_result_no_1+1))
        save_result_1 = insert_task_run_list_data.dailycheck_result_list_save(result_list_1, max_dtl_task_result_no_1+1)
        print("save_result_1=<%r>" % save_result_1)
        delete_result_1 = delete_task_run_list.delete_task_run_list_dtl(max_dtl_task_result_no_1+1)
        print("delete_result_1=<%r>" % delete_result_1)
        result_list_2 = result_file_parsing.dailycheck_result_parsing('sample_mwcheck_stdout.txt')
        print("parsing result_list_2=<%r>" % result_list_2)
        max_dtl_task_result_no_2 = get_task_run_list_data.get_run_list_dtl_max_result_no()
        print("save max_dtl_task_result_no_2=<%r>" % str(max_dtl_task_result_no_2 + 1))
        save_result_2 = insert_task_run_list_data.dailycheck_result_list_save(result_list_2, max_dtl_task_result_no_2 + 1)
        print("save_result_2=<%r>" % save_result_2)
        delete_result_2 = delete_task_run_list.delete_task_run_list_dtl(max_dtl_task_result_no_2+1)
        print("delete_result_2=<%r>" % delete_result_2)

    def test_dailycheck_get_task_run_list_dtl(self):
        from app.opmw.dao import get_task_run_list_data
        dtl_max_task_result_no = get_task_run_list_data.get_run_list_dtl_max_result_no()
        print("dtl_max_task_result_no=<%r>" % int(dtl_max_task_result_no))
        dtl_max_seq = get_task_run_list_data.get_run_list_dtl_max_seq(dtl_max_task_result_no)
        print("dtl_max_seq=<%r>" % int(dtl_max_seq))
        task_result_list_dtl = get_task_run_list_data.get_task_run_list_dtl(dtl_max_task_result_no)
        print("task_result_list_dtl=<%r>" % task_result_list_dtl)


