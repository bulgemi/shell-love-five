import unittest
# import time
# from datetime import datetime
from flask import current_app
# cellar
from app import db, create_app


class TaskOpmwTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app_context = self.app.app_context()
        # self.app_context().push()

    def tearDown(self):
        db.session.remove()
        # self.app_context().pop()

    # def test_toms_mig_hist_result(self):
    #
    #     from app.opmw.dashboard.dao import get_toms_mig_hist
    #     result = get_toms_mig_hist.get_toms_mig_hist_data()
    #
    #     if result is not None:
    #         print(result)

    def test_get_instance_no_max_result(self):
        #from app.opmw.dashboard.dao import get_task_run_info
        # exec_no = get_task_run_info.get_instance_no_maxval('kkh_check')
        # result = get_task_run_info.get_task_id_list()
        # result2 = get_task_run_info.get_task_run_count('linux_dailydheck', 1)
        # print("@@@@@@@@@@@@ MAX EXEC_NO is : [%r] @@@@@" % exec_no)
        #
        # for i in result:
        #     print("@@@@@@@@@@@@ FUNC_CL_CD : [%r %r] @@@@@" % i)
        #
        # print(result2)
        from app.opmw.dashboard import dashboard_render
        result = dashboard_render.count_dailycheck_result()
        print(result)
