import unittest
# import time
# from datetime import datetime
from flask import current_app
# cellar
from app import db, create_app


class TaskOpmwTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app()
        self.app_context = self.app.app_context()
        # self.app_context().push()

    def tearDown(self):
        db.session.remove()
        # self.app_context().pop()

    # def test_toms_mig_hist_result(self):
    #
    #     from app.opmw.dashboard.dao import get_toms_mig_hist
    #     result = get_toms_mig_hist.get_toms_mig_hist_data()
    #
    #     if result is not None:
    #         print(result)

    # def test_run_job(self):
    #     from app.taskqueue import task_opmw_ondemand
    #     task_opmw_ondemand.run_job("mw_dailycheck", 8290, "skt_agent03", "youngme_kim@sk.com")

    def test_run_daily_job(self):
        from app.taskqueue import task_opmw_daily
        task_opmw_daily.run_job()

    # def test_get_task_id_list(self):
    #     from app.taskqueue.dao import get_task_mgmt_info
    #     result = get_task_mgmt_info.get_task_id_list()
    #     current_app.logger.debug("result: <%r>" % result)
    #     # result: <[(u'db_dailycheck',), (u'linux_dailycheck',), (u'mw_dailycheck',), (u'win_dailycheck',)]>
